<!--
Sync Impact Report (temporary review material; remove before committing)
Version change: Unversioned scaffold -> 1.0.0 (initial adoption)
Modified principles: Unfilled principle slots replaced by ten concrete principles.
Added principles: I. Requirements-First Development; II. Architecture and Design;
  III. Domain Correctness; IV. API Engineering; V. Data Integrity;
  VI. Testing and Verification; VII. Observability; VIII. AI Engineering;
  IX. Assessment Scope; X. Documentation.
Added sections: Engineering Constraints; Development Workflow and Quality Gates;
  concrete Governance rules.
Removed sections: None; template example comments and placeholders removed.
Follow-up TODOs: None.
Input normalization: "Booking eckit-conmust" interpreted as "Booking MUST";
  ".NET Core Framework 10 Version" normalized to ".NET 10".
Ratification: 2026-10-09 records initial adoption of the previously unfilled scaffold.
Dependent templates and commands: Unchanged; they read the constitution at runtime.
-->
# Keyloop Unified Service Scheduler Constitution

## Core Principles

### I. Requirements-First Development

Functionality MUST be traceable to the assessment requirements. Ambiguous requirements MUST
have documented assumptions. Optional enhancements MUST be identified separately from mandatory
functionality so reviewers can assess required scope and completion independently.

### II. Architecture and Design

The system MUST use a modular monolith on .NET 10 and pragmatic Clean Architecture. API,
Application, Domain, and Infrastructure concerns MUST be separated. SOLID principles and
dependency inversion MUST be applied where they improve maintainability; their use MUST have
a concrete justification. Patterns and abstractions without a demonstrated need MUST NOT be
introduced. This keeps the assessment implementation understandable and maintainable.

### III. Domain Correctness

Every booking MUST require a qualified technician and an available service bay. Both resources
MUST cover the entire appointment duration. Conflicting confirmed bookings MUST never be
allowed. An availability check alone MUST NOT be treated as a guarantee of booking correctness.
The appointment and both resource assignments MUST be persisted atomically, so partial bookings
and conflicts cannot be introduced between checking availability and committing the booking.

### IV. API Engineering

APIs MUST follow REST conventions, validate all user inputs, and use HTTP status codes
appropriate to each outcome. Errors MUST use standardized Problem Details responses.
OpenAPI documentation MUST describe the exposed API contracts so consumers and reviewers can
exercise the backend consistently.

### V. Data Integrity

The system MUST use relational database constraints wherever they can enforce applicable
integrity rules. Transaction boundaries MUST be explicit. Concurrent requests MUST be handled
safely, including requests processed by different application instances. In-memory locks MUST
NOT be assumed to coordinate across instances. Concurrency safety MUST NOT be claimed without
tests that exercise the relevant booking conflicts and persistence behavior.

### VI. Testing and Verification

Automated unit and integration tests MUST verify the implementation. Coverage MUST include
successful bookings, validation failures, unavailable resources, overlapping appointments,
and concurrent bookings. Failing tests MUST NOT be suppressed or removed merely to pass
validation. Test results MUST be recorded accurately, including failures and checks that were
not run, so completion claims are supported by evidence.

### VII. Observability

The system MUST use structured logging and include correlation IDs to connect related
operations. Important booking operations MUST be instrumented, including booking attempts
and their outcomes. Customer-sensitive information MUST NOT be logged unnecessarily; any
such logging MUST have a documented operational need.

### VIII. AI Engineering

AI-generated code MUST be treated as untrusted until reviewed and verified. Implementation
MUST proceed in small, reviewable increments. Significant architectural decisions MUST be
explained. AI collaboration and corrections MUST be recorded. Verification results MUST NOT
be fabricated, and unexecuted checks MUST NOT be reported as successful.

### IX. Assessment Scope

The backend MUST fully implement the mandatory assessment requirements. The frontend MUST
be mocked through OpenAPI, HTTP requests, and tests. Correctness and clear documentation MUST
take priority over optional enhancements. Kubernetes, Kafka, distributed messaging, and
authentication infrastructure MUST NOT be introduced without a documented, demonstrated need.

### X. Documentation

A System Design Document MUST be maintained. Assumptions and architectural decisions MUST
be documented. README build, run, and test instructions MUST remain reproducible. Key trade-offs
and limitations MUST be explained so reviewers can understand the implementation and the
boundaries of its guarantees.

## Engineering Constraints

The architecture baseline is a .NET 10 modular monolith with separated API, Application,
Domain, and Infrastructure concerns and relational persistence. Design artifacts MUST explain
how qualification, full-duration resource availability, atomic persistence, and concurrent
booking conflict prevention are enforced.

Assessment deliverables MUST include the complete required backend, OpenAPI documentation,
HTTP request examples or fixtures, automated tests, a System Design Document, and reproducible
README instructions. Optional work MUST remain separately identified and MUST NOT displace
mandatory functionality or its verification.

## Development Workflow and Quality Gates

Before implementation, each change MUST identify its requirement or documented engineering
need, relevant assumptions, and applicable constitutional constraints. Significant design
decisions and additional complexity MUST include their rationale.

Each change MUST be reviewable and MUST undergo review for domain correctness, API contracts,
transaction boundaries, concurrency behavior, observability, and documentation as applicable.
AI-assisted changes MUST record the collaboration, review, and corrections.

Before a change is declared complete, relevant automated tests MUST be executed and their
results recorded. Booking changes MUST verify affected success, validation, unavailability,
overlap, and concurrency scenarios. Any failed or unexecuted required check MUST be disclosed
and MUST prevent an unsupported claim of completion or concurrency safety. Documentation
affected by a change MUST be updated with that change.

## Governance

This constitution governs project specifications, plans, implementation, and review. Conflicting
project guidance MUST be aligned with it. Every change review MUST verify compliance with
the applicable principles and quality gates. A noncompliant change MUST be corrected or
preceded by an approved constitutional amendment.

Amendments MUST document the proposed change, its rationale, affected principles, and any
required migration or follow-up work. Amendments MUST receive project maintainer approval
before adoption. The constitution version and last-amended date MUST be updated when an
amendment is adopted; the original ratification date MUST be preserved.

Versions MUST follow semantic versioning: MAJOR for incompatible principle removals or
redefinitions, MINOR for new principles or sections or materially expanded guidance, and PATCH
for clarifications and non-semantic corrections. This first adoption is version 1.0.0.

Amendment reviews MUST assess the effect on dependent specifications, plans, tasks, and
guidance and record any necessary follow-up. The temporary Sync Impact Report MUST be removed
before the amended constitution is committed; it is review material, not governance content.

**Version**: 1.0.0 | **Ratified**: 2026-10-09 | **Last Amended**: 2026-10-09
