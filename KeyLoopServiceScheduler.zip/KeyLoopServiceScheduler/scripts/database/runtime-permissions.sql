-- Run with migration/administrative credentials after applying migrations.
-- Provision the external login separately (integrated identity or secret-managed SQL login).
-- Replace SchedulerRuntimeUser with the mapped database user; never use this role for migrations/seeding.
IF DATABASE_PRINCIPAL_ID(N'SchedulerRuntimeRole') IS NULL
    CREATE ROLE [SchedulerRuntimeRole] AUTHORIZATION [dbo];
GO
GRANT SELECT ON OBJECT::dbo.Customer TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.Vehicle TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.Dealership TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.ServiceType TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.Technician TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.TechnicianQualification TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.ServiceBay TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.DealershipOperatingWindow TO SchedulerRuntimeRole;
GRANT SELECT ON OBJECT::dbo.TechnicianWorkingWindow TO SchedulerRuntimeRole;
GRANT SELECT, INSERT ON OBJECT::dbo.Appointment TO SchedulerRuntimeRole;
GO
-- ALTER ROLE [SchedulerRuntimeRole] ADD MEMBER [SchedulerRuntimeUser];
-- A database user already belongs to public, the planned sp_getapplock database principal.
-- No db_owner/db_ddladmin/db_datawriter membership, schema privileges, or reference writes.
-- Runtime credentials must have no wider grants through other memberships.
