﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [Customer] (
        [Id] bigint NOT NULL,
        [DisplayName] nvarchar(200) NULL,
        CONSTRAINT [PK_Customer] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Customer_Id_Positive] CHECK ([Id] > 0)
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [Dealership] (
        [Id] bigint NOT NULL,
        [Name] nvarchar(200) NOT NULL,
        [TimeZoneId] nvarchar(100) NOT NULL,
        CONSTRAINT [PK_Dealership] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Dealership_Id_Positive] CHECK ([Id] > 0)
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [ServiceType] (
        [Id] bigint NOT NULL,
        [Name] nvarchar(100) NOT NULL,
        [DurationMinutes] int NOT NULL,
        CONSTRAINT [PK_ServiceType] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_ServiceType_Duration_Positive] CHECK ([DurationMinutes] > 0),
        CONSTRAINT [CK_ServiceType_Id_Positive] CHECK ([Id] > 0)
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [Vehicle] (
        [Id] bigint NOT NULL,
        [CustomerId] bigint NOT NULL,
        [Description] nvarchar(200) NULL,
        CONSTRAINT [PK_Vehicle] PRIMARY KEY ([Id]),
        CONSTRAINT [AK_Vehicle_Id_CustomerId] UNIQUE ([Id], [CustomerId]),
        CONSTRAINT [CK_Vehicle_Id_Positive] CHECK ([Id] > 0),
        CONSTRAINT [FK_Vehicle_Customer_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customer] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [DealershipOperatingWindow] (
        [Id] bigint NOT NULL,
        [DealershipId] bigint NOT NULL,
        [LocalStart] datetime2(7) NOT NULL,
        [LocalEnd] datetime2(7) NOT NULL,
        CONSTRAINT [PK_DealershipOperatingWindow] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_DealershipOperatingWindow_Bounds] CHECK ([LocalEnd] > [LocalStart]),
        CONSTRAINT [CK_DealershipOperatingWindow_Id_Positive] CHECK ([Id] > 0),
        CONSTRAINT [FK_DealershipOperatingWindow_Dealership_DealershipId] FOREIGN KEY ([DealershipId]) REFERENCES [Dealership] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [ServiceBay] (
        [Id] bigint NOT NULL,
        [DealershipId] bigint NOT NULL,
        [Name] nvarchar(100) NULL,
        CONSTRAINT [PK_ServiceBay] PRIMARY KEY ([Id]),
        CONSTRAINT [AK_ServiceBay_Id_DealershipId] UNIQUE ([Id], [DealershipId]),
        CONSTRAINT [CK_ServiceBay_Id_Positive] CHECK ([Id] > 0),
        CONSTRAINT [FK_ServiceBay_Dealership_DealershipId] FOREIGN KEY ([DealershipId]) REFERENCES [Dealership] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [Technician] (
        [Id] bigint NOT NULL,
        [DealershipId] bigint NOT NULL,
        [DisplayName] nvarchar(200) NULL,
        CONSTRAINT [PK_Technician] PRIMARY KEY ([Id]),
        CONSTRAINT [AK_Technician_Id_DealershipId] UNIQUE ([Id], [DealershipId]),
        CONSTRAINT [CK_Technician_Id_Positive] CHECK ([Id] > 0),
        CONSTRAINT [FK_Technician_Dealership_DealershipId] FOREIGN KEY ([DealershipId]) REFERENCES [Dealership] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [TechnicianQualification] (
        [TechnicianId] bigint NOT NULL,
        [ServiceTypeId] bigint NOT NULL,
        CONSTRAINT [PK_TechnicianQualification] PRIMARY KEY ([TechnicianId], [ServiceTypeId]),
        CONSTRAINT [FK_TechnicianQualification_ServiceType_ServiceTypeId] FOREIGN KEY ([ServiceTypeId]) REFERENCES [ServiceType] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_TechnicianQualification_Technician_TechnicianId] FOREIGN KEY ([TechnicianId]) REFERENCES [Technician] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [TechnicianWorkingWindow] (
        [Id] bigint NOT NULL,
        [TechnicianId] bigint NOT NULL,
        [LocalStart] datetime2(7) NOT NULL,
        [LocalEnd] datetime2(7) NOT NULL,
        CONSTRAINT [PK_TechnicianWorkingWindow] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_TechnicianWorkingWindow_Bounds] CHECK ([LocalEnd] > [LocalStart]),
        CONSTRAINT [CK_TechnicianWorkingWindow_Id_Positive] CHECK ([Id] > 0),
        CONSTRAINT [FK_TechnicianWorkingWindow_Technician_TechnicianId] FOREIGN KEY ([TechnicianId]) REFERENCES [Technician] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE TABLE [Appointment] (
        [Id] uniqueidentifier NOT NULL,
        [CustomerId] bigint NOT NULL,
        [VehicleId] bigint NOT NULL,
        [DealershipId] bigint NOT NULL,
        [ServiceTypeId] bigint NOT NULL,
        [TechnicianId] bigint NOT NULL,
        [ServiceBayId] bigint NOT NULL,
        [StartUtc] datetimeoffset(7) NOT NULL,
        [EndUtc] datetimeoffset(7) NOT NULL,
        [DurationMinutes] int NOT NULL,
        [Status] varchar(16) NOT NULL,
        [RequestKey] varchar(128) COLLATE Latin1_General_100_BIN2 NULL,
        [CreatedUtc] datetimeoffset(7) NOT NULL,
        CONSTRAINT [PK_Appointment] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Appointment_Duration] CHECK ([DurationMinutes] > 0),
        CONSTRAINT [CK_Appointment_DurationEnd] CHECK ([EndUtc] = DATEADD(minute, [DurationMinutes], [StartUtc])),
        CONSTRAINT [CK_Appointment_Interval] CHECK ([EndUtc] > [StartUtc]),
        CONSTRAINT [CK_Appointment_RequestKey] CHECK ([RequestKey] IS NULL OR (DATALENGTH([RequestKey]) BETWEEN 1 AND 128 AND [RequestKey] NOT LIKE '%[^!-~]%')),
        CONSTRAINT [CK_Appointment_Status] CHECK ([Status] COLLATE Latin1_General_100_BIN2 = 'Confirmed' AND DATALENGTH([Status]) = 9),
        CONSTRAINT [CK_Appointment_Utc] CHECK (DATEPART(TZOFFSET, [StartUtc]) = 0 AND DATEPART(TZOFFSET, [EndUtc]) = 0 AND DATEPART(TZOFFSET, [CreatedUtc]) = 0),
        CONSTRAINT [FK_Appointment_Customer_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customer] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_Dealership_DealershipId] FOREIGN KEY ([DealershipId]) REFERENCES [Dealership] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_ServiceBay_ServiceBayId_DealershipId] FOREIGN KEY ([ServiceBayId], [DealershipId]) REFERENCES [ServiceBay] ([Id], [DealershipId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_ServiceType_ServiceTypeId] FOREIGN KEY ([ServiceTypeId]) REFERENCES [ServiceType] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_TechnicianQualification_TechnicianId_ServiceTypeId] FOREIGN KEY ([TechnicianId], [ServiceTypeId]) REFERENCES [TechnicianQualification] ([TechnicianId], [ServiceTypeId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_Technician_TechnicianId_DealershipId] FOREIGN KEY ([TechnicianId], [DealershipId]) REFERENCES [Technician] ([Id], [DealershipId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Appointment_Vehicle_VehicleId_CustomerId] FOREIGN KEY ([VehicleId], [CustomerId]) REFERENCES [Vehicle] ([Id], [CustomerId]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_CustomerId] ON [Appointment] ([CustomerId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_ServiceBayId_DealershipId] ON [Appointment] ([ServiceBayId], [DealershipId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    EXEC(N'CREATE INDEX [IX_Appointment_ServiceBayId_StartUtc] ON [Appointment] ([ServiceBayId], [StartUtc]) INCLUDE ([EndUtc], [Status]) WHERE [Status] = ''Confirmed''');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_ServiceTypeId] ON [Appointment] ([ServiceTypeId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_TechnicianId_DealershipId] ON [Appointment] ([TechnicianId], [DealershipId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_TechnicianId_ServiceTypeId] ON [Appointment] ([TechnicianId], [ServiceTypeId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    EXEC(N'CREATE INDEX [IX_Appointment_TechnicianId_StartUtc] ON [Appointment] ([TechnicianId], [StartUtc]) INCLUDE ([EndUtc], [Status]) WHERE [Status] = ''Confirmed''');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Appointment_VehicleId_CustomerId] ON [Appointment] ([VehicleId], [CustomerId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_Appointment_Dealer_RequestKey] ON [Appointment] ([DealershipId], [RequestKey]) WHERE [RequestKey] IS NOT NULL');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_DealershipOperatingWindow_DealershipId_LocalStart] ON [DealershipOperatingWindow] ([DealershipId], [LocalStart]) INCLUDE ([LocalEnd]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_ServiceBay_DealershipId_Id] ON [ServiceBay] ([DealershipId], [Id]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Technician_DealershipId_Id] ON [Technician] ([DealershipId], [Id]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_TechnicianQualification_ServiceTypeId_TechnicianId] ON [TechnicianQualification] ([ServiceTypeId], [TechnicianId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_TechnicianWorkingWindow_TechnicianId_LocalStart] ON [TechnicianWorkingWindow] ([TechnicianId], [LocalStart]) INCLUDE ([LocalEnd]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    CREATE INDEX [IX_Vehicle_CustomerId] ON [Vehicle] ([CustomerId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261009121741_InitialScheduler'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261009121741_InitialScheduler', N'10.0.12');
END;

COMMIT;
GO

