using KeyLoopServiceScheduler.LoadHarness;

var output = args.Length > 0 ? args[0] : "artifacts/performance";
var history = args.Length > 1 ? int.Parse(args[1], System.Globalization.CultureInfo.InvariantCulture) : 100_000;
if (history is < 1 or > 1_000_000) throw new ArgumentOutOfRangeException(nameof(history));
await LoadScenario.RunAsync(output, history);
