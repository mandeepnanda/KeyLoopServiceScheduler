namespace KeyLoopServiceScheduler.LoadHarness;

/// <summary>Each distributed booking consumes one distinct, fully seeded hour; capacity never wraps.</summary>
public static class LoadProfile
{
    public const int Days = 3650;
    public const int HoursPerDay = 8;
    public const int BookingCapacity = Days * HoursPerDay * 2;
    public static readonly DateTime BaseDate = new(2030, 1, 7);

    public static (long Dealer, DateTimeOffset Start) BookingSlot(long ordinal, bool hot)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(ordinal);
        if (!hot && ordinal >= BookingCapacity)
            throw new InvalidOperationException("Distributed booking capacity exhausted; stop the profile rather than reuse occupied slots.");
        var dealer = hot ? 1L : ordinal % 2 + 1;
        var dealerSlot = hot ? 0 : ordinal / 2;
        var local = BaseDate.AddDays(dealerSlot / HoursPerDay).AddHours(9 + dealerSlot % HoursPerDay);
        var zone = TimeZoneInfo.FindSystemTimeZoneById(dealer == 1 ? "Asia/Kolkata" : "America/New_York");
        return (dealer, new DateTimeOffset(TimeZoneInfo.ConvertTimeToUtc(local, zone)));
    }
}
