using System.Collections.Concurrent;
using System.Data;
using System.Diagnostics;
using System.Net.Http.Json;
using System.Text.Json;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using KeyLoopServiceScheduler.ProcessTests.Fixtures;
using Microsoft.Data.SqlClient;

namespace KeyLoopServiceScheduler.LoadHarness;

public static class LoadScenario
{
    public static async Task RunAsync(string output, int historyRows = 100_000)
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("SCHEDULER_TEST_CONNECTION")))
            throw new InvalidOperationException("Performance verification requires an isolated SQL test connection. Mock mode is not supported.");
        Directory.CreateDirectory(output);
        foreach (var hot in new[] { false, true }) for (var repetition = 1; repetition <= 3; repetition++)
        {
            var fixture = new ApiProcessFixture();
            try
            {
                var runName = $"{(hot ? "hot" : "distributed")}-{repetition}-{Guid.NewGuid():N}";
                await fixture.InitializeAsync(database => PrepareAsync(database, historyRows), Path.Combine(output, runName));
                var samples = new ConcurrentBag<Sample>();
                long bookingSequence = -1;
                long warmupBookingAttempts = 0;
                async Task Phase(TimeSpan duration, bool measure)
                {
                    using var budget = new CancellationTokenSource(duration);
                    await Task.WhenAll(Enumerable.Range(0, 10).Select(async caller =>
                    {
                        var random = new Random(12345 + caller);
                        var client = caller % 2 == 0 ? fixture.First : fixture.Second;
                        while (!budget.IsCancellationRequested)
                        {
                            var choice = random.Next(100);
                            var operation = choice < 60 ? "availability" : choice < 85 ? "retrieval" : "booking";
                            var ordinal = operation == "booking" ? Interlocked.Increment(ref bookingSequence) : random.Next(LoadProfile.BookingCapacity);
                            if (!measure && operation == "booking") Interlocked.Increment(ref warmupBookingAttempts);
                            var (dealer, start) = LoadProfile.BookingSlot(ordinal, hot);
                            var watch = Stopwatch.StartNew();
                            int status;
                            try
                            {
                                using var response = operation switch
                                {
                                    "availability" => await client.GetAsync($"/api/v1/availability?dealershipId={dealer}&serviceTypeId=1&startTime={Uri.EscapeDataString(start.ToString("O"))}"),
                                    "retrieval" => await client.GetAsync("/api/v1/appointments/11111111-1111-1111-1111-111111111111"),
                                    _ => await client.PostAsJsonAsync("/api/v1/appointments", new { customerId = 1, vehicleId = 1, dealershipId = dealer, serviceTypeId = 1, startTime = start })
                                };
                                status = (int)response.StatusCode;
                                await response.Content.ReadAsByteArrayAsync();
                            }
                            catch (HttpRequestException) { status = 0; }
                            catch (TaskCanceledException) { status = 0; }
                            if (measure) samples.Add(new(operation, status, watch.Elapsed.TotalMilliseconds));
                        }
                    }));
                }
                await Phase(TimeSpan.FromSeconds(30), false);
                var measurementStartUtc = DateTime.UtcNow;
                var measurement = Stopwatch.StartNew();
                await Phase(TimeSpan.FromSeconds(120), true);
                measurement.Stop();
                var measurementEndUtc = DateTime.UtcNow;
                // SDK batch export runs outside the transaction. Allow its 200 ms worker to drain.
                await Task.Delay(TimeSpan.FromSeconds(1));
                var timings = LoadTimingReport.Read(fixture.LoadCaptureFiles, measurementStartUtc, measurementEndUtc);
                var bookingSamples = samples.Where(sample => sample.Operation == "booking").ToArray();
                var capturedBookings = timings.SingleOrDefault(timing => timing.Operation == "booking")?.Count ?? 0;
                var captureComplete = capturedBookings == bookingSamples.Length && timings.Any(timing => timing.Operation == "booking.transaction") &&
                    timings.Any(timing => timing.Operation == "booking.lock.wait") && timings.Any(timing => timing.Operation.StartsWith("booking.db.", StringComparison.Ordinal));
                var invariants = await InspectAsync(fixture.Database);
                if (invariants != 0) throw new InvalidOperationException("Performance run found overlapping/partial confirmations or duplicate bindings.");
                var report = new
                {
                    scenario = hot ? "hot-dealer" : "distributed-slots",
                    repetition,
                    randomSeed = 12345,
                    callers = 10,
                    requestedMix = "60% availability / 25% retrieval / 15% create",
                    warmupSeconds = 30,
                    measurementSeconds = measurement.Elapsed.TotalSeconds,
                    historyRows,
                    apiProcesses = 2,
                    framework = Environment.Version.ToString(),
                    os = Environment.OSVersion.ToString(),
                    processors = Environment.ProcessorCount,
                    machineMemoryBytes = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes,
                    sqlEnvironment = await SqlEnvironmentAsync(fixture.Database),
                    zeroInvariantViolations = true,
                    requestsPerSecond = samples.Count / measurement.Elapsed.TotalSeconds,
                    warmupBookingAttempts,
                    warmupBookingsRetained = true,
                    bookingSlotPolicy = hot ? "Shared interval intentionally reused" : "Distinct dealer/hour slots shared across warmup and measurement, never wrapped",
                    bookingSlotCapacity = LoadProfile.BookingCapacity,
                    bookingSuccessRate = Rate(bookingSamples, sample => sample.Status == 201),
                    bookingConflictRate = Rate(bookingSamples, sample => sample.Status == 409),
                    bookingTechnicalFailureRate = Rate(bookingSamples, sample => sample.Status == 0 || sample.Status >= 500),
                    timingCaptureRootCoverageEstablished = captureComplete,
                    timingCaptureFiles = fixture.LoadCaptureFiles,
                    timingCaptureLimit = "Bounded batch capture can drop individual spans on saturation or process failure; matching root counts do not certify every child span. Missing booking roots fail this profile. DB timings measure adapter operations, not SQL logical reads.",
                    timings,
                    results = samples.GroupBy(sample => (sample.Operation, sample.Status)).Select(group => new
                    {
                        operation = group.Key.Operation,
                        status = group.Key.Status,
                        count = group.Count(),
                        p50Ms = Percentile(group, .50),
                        p95Ms = Percentile(group, .95),
                        p99Ms = Percentile(group, .99)
                    })
                };
                await File.WriteAllTextAsync(Path.Combine(output, runName + ".json"), JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
                if (!captureComplete) throw new InvalidOperationException("Incomplete API timing capture; inspect the report and capture files before claiming measured performance.");
                if (!hot && bookingSamples.Any(sample => sample.Status != 201))
                    throw new InvalidOperationException("Low-collision booking profile returned a rejection or technical failure; inspect its recorded outcomes.");
            }
            finally { await fixture.DisposeAsync(); }
        }
    }
    private static double Percentile(IEnumerable<Sample> group, double percentile)
    { var values = group.Select(sample => sample.ElapsedMs).Order().ToArray(); return values[Math.Clamp((int)Math.Ceiling(values.Length * percentile) - 1, 0, values.Length - 1)]; }
    private sealed record Sample(string Operation, int Status, double ElapsedMs);
    private static double Rate(Sample[] samples, Func<Sample, bool> predicate) => samples.Length == 0 ? 0 : (double)samples.Count(predicate) / samples.Length;
    private static async Task<object> SqlEnvironmentAsync(SqlDatabaseFixture database)
    {
        await using var connection = new SqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        await using var command = new SqlCommand("SELECT CONVERT(nvarchar(128),SERVERPROPERTY('ProductVersion')), CONVERT(nvarchar(128),SERVERPROPERTY('Edition')), compatibility_level FROM sys.databases WHERE name=DB_NAME()", connection);
        await using var reader = await command.ExecuteReaderAsync();
        await reader.ReadAsync();
        return new { version = reader.GetString(0), edition = reader.GetString(1), compatibilityLevel = reader.GetByte(2), commandTimeoutSeconds = 5, connectionPool = "SqlClient default; separate pool per process", sqlHardware = "Disclose SQL-host CPU/memory/storage separately when SQL is remote." };
    }
    private static async Task PrepareAsync(SqlDatabaseFixture database, int historyRows)
    {
        // Administrative fixture writes complete before either API process starts.
        await using var context = database.CreateContext();
        long window = 10000;
        for (var day = 0; day < LoadProfile.Days; day++)
        {
            var start = LoadProfile.BaseDate.AddDays(day).AddHours(9);
            foreach (var dealer in new[] { 1L, 2L }) context.DealershipOperatingWindows.Add(new(++window, dealer, start, start.AddHours(8)));
            foreach (var technician in new[] { 1L, 2L, 3L }) context.TechnicianWorkingWindows.Add(new(++window, technician, start, start.AddHours(8)));
        }
        await context.SaveChangesAsync();
        using var table = new DataTable();
        foreach (var (name, type) in new (string, Type)[] { ("Id", typeof(Guid)), ("CustomerId", typeof(long)), ("VehicleId", typeof(long)),
            ("DealershipId", typeof(long)), ("ServiceTypeId", typeof(long)), ("TechnicianId", typeof(long)), ("ServiceBayId", typeof(long)),
            ("StartUtc", typeof(DateTimeOffset)), ("EndUtc", typeof(DateTimeOffset)), ("DurationMinutes", typeof(int)), ("Status", typeof(string)), ("CreatedUtc", typeof(DateTimeOffset)) }) table.Columns.Add(name, type);
        await using var connection = new SqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        using var copy = new SqlBulkCopy(connection, SqlBulkCopyOptions.CheckConstraints, null) { DestinationTableName = "Appointment", BatchSize = 1000, BulkCopyTimeout = 120 };
        foreach (DataColumn column in table.Columns) copy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
        for (var index = 0; index < historyRows; index++)
        {
            var start = database.Now.AddHours(-historyRows - 24 + index);
            table.Rows.Add(index == 0 ? Guid.Parse("11111111-1111-1111-1111-111111111111") : Guid.NewGuid(), 1L, 1L, 1L, 1L, 1L, 1L, start, start.AddHours(1), 60, "Confirmed", database.Now);
            if (table.Rows.Count == 1000 || index == historyRows - 1) { await copy.WriteToServerAsync(table); table.Clear(); }
        }
    }
    private static async Task<int> InspectAsync(SqlDatabaseFixture database)
    {
        await using var connection = new SqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        await using var command = new SqlCommand("WITH intervals AS (SELECT StartUtc, EndUtc, DurationMinutes, TechnicianId, ServiceBayId, " +
            "MAX(EndUtc) OVER (PARTITION BY TechnicianId ORDER BY StartUtc,Id ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS techEnd, " +
            "MAX(EndUtc) OVER (PARTITION BY ServiceBayId ORDER BY StartUtc,Id ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS bayEnd FROM Appointment) " +
            "SELECT COUNT(*) FROM intervals WHERE StartUtc<techEnd OR StartUtc<bayEnd OR TechnicianId IS NULL OR ServiceBayId IS NULL OR EndUtc<>DATEADD(minute,DurationMinutes,StartUtc)", connection)
        { CommandTimeout = 120 };
        var overlaps = Convert.ToInt32(await command.ExecuteScalarAsync());
        command.CommandText = "SELECT COUNT(*) FROM (SELECT DealershipId,RequestKey FROM Appointment WHERE RequestKey IS NOT NULL GROUP BY DealershipId,RequestKey HAVING COUNT(*)>1) AS duplicates";
        return overlaps + Convert.ToInt32(await command.ExecuteScalarAsync());
    }
}
