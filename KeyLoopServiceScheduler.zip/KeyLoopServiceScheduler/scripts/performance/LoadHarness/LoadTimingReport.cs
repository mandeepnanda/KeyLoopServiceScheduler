using System.Text.Json;

namespace KeyLoopServiceScheduler.LoadHarness;

public sealed record LoadTimingSample(string Operation, DateTime StartUtc, DateTime EndUtc, double DurationMs, string TraceId);
public sealed record LoadTimingSummary(string Operation, int Count, double TotalMs, double P50Ms, double P95Ms, double P99Ms);

public static class LoadTimingReport
{
    public static IReadOnlyList<LoadTimingSummary> Read(IEnumerable<string> files, DateTime startUtc, DateTime endUtc)
    {
        var samples = new List<LoadTimingSample>();
        foreach (var file in files)
        {
            if (!File.Exists(file)) throw new InvalidOperationException("API load timing capture is missing.");
            using var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(stream);
            while (reader.ReadLine() is string line)
            {
                var sample = JsonSerializer.Deserialize<LoadTimingSample>(line, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                    ?? throw new InvalidOperationException("Invalid timing record.");
                if (sample.StartUtc >= startUtc && sample.EndUtc <= endUtc) samples.Add(sample);
            }
        }
        return samples.GroupBy(sample => sample.Operation).Select(group =>
        {
            var durations = group.Select(sample => sample.DurationMs).Order().ToArray();
            double Percentile(double p) => durations[Math.Clamp((int)Math.Ceiling(durations.Length * p) - 1, 0, durations.Length - 1)];
            return new LoadTimingSummary(group.Key, durations.Length, durations.Sum(), Percentile(.50), Percentile(.95), Percentile(.99));
        }).OrderBy(summary => summary.Operation).ToArray();
    }
}
