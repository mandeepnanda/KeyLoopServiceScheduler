param([int]$HistoryRows = 100000, [string]$Output = 'artifacts/performance')
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:SCHEDULER_TEST_CONNECTION)) { throw 'Set SCHEDULER_TEST_CONNECTION for an isolated SQL test instance. Mock performance is not SQL evidence.' }
dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw 'Release build failed.' }
dotnet run --project scripts/performance/LoadHarness -c Release -- $Output $HistoryRows
if ($LASTEXITCODE -ne 0) { throw 'Load harness failed; inspect recorded outcomes.' }
