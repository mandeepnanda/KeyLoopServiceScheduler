import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const path = process.argv[2] ?? 'specs/001-service-scheduler/contracts/openapi.json';
const doc = JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const post = doc.paths['/api/v1/appointments'].post;
const keySchema = post.parameters.find(p => p.name === 'Idempotency-Key').schema;
const key = new RegExp(keySchema.pattern);
const validKey = value => key.test(value) && value.length >= keySchema.minLength && value.length <= keySchema.maxLength;
for (let code = 0; code < 256; code++) assert.equal(validKey(String.fromCharCode(code)), code >= 33 && code <= 126, `key character ${code}`);
for (const value of ['', 'x'.repeat(129), 'é', '🙂', 'a\n', 'a b']) assert.equal(validKey(value), false, JSON.stringify(value));
for (const value of ['demo-001', 'x'.repeat(128)]) assert.equal(validKey(value), true);
const timestamp = new RegExp(doc.components.schemas.BookingRequest.properties.startTime.pattern);
for (const value of ['2030-01-07T09:00:00Z', '2030-01-07T09:00:00.1234567+05:30']) assert.equal(timestamp.test(value), true);
for (const value of ['2030-01-07T09:00:00', '2030-01-07T09:00:00.12345678Z', '2030-01-07T09:00:00Z\n']) assert.equal(timestamp.test(value), false);
for (const [route, item] of Object.entries(doc.paths)) for (const operation of Object.values(item)) {
  for (const [status, response] of Object.entries(operation.responses)) {
    assert.ok(response.headers?.['X-Correlation-ID'], `${route} ${status} correlation`);
    if (route === '/api/v1/appointments' && ['200', '201'].includes(status)) assert.ok(response.headers.Location);
  }
}
console.log('OpenAPI ECMAScript schema checks passed: 256 key characters, bounds, Unicode, timestamps, headers. Calendar/range are tested by the API suite.');
