# Data Model and Relational Schema

Design only; physical migrations belong to implementation. Reference IDs are positive SQL
bigint values ordered numerically ascending. Appointment IDs are application-generated GUIDs.
Customer names and vehicle descriptors are optional sample metadata, not required booking inputs.
All foreign-key deletes are restricted; no appointment deletion endpoint exists.

## ER Diagram

```mermaid
erDiagram
    Customer ||--o{ Vehicle : owns
    Customer ||--o{ Appointment : books
    Vehicle ||--o{ Appointment : receives
    Dealership ||--o{ Technician : employs
    Dealership ||--o{ ServiceBay : owns
    Dealership ||--o{ DealershipOperatingWindow : schedules
    Technician ||--o{ TechnicianWorkingWindow : schedules
    Technician ||--o{ TechnicianQualification : holds
    ServiceType ||--o{ TechnicianQualification : qualifies
    Dealership ||--o{ Appointment : hosts
    ServiceType ||--o{ Appointment : defines_duration
    Technician ||--o{ Appointment : assigned
    ServiceBay ||--o{ Appointment : assigned
```

## Tables

| Table | Fields and SQL types | Integrity/relationships |
|---|---|---|
| Customer | Id bigint PK, DisplayName nvarchar(200) nullable | Id > 0 |
| Vehicle | Id bigint PK, CustomerId bigint NOT NULL, Description nvarchar(200) nullable | Customer FK; alternate unique (Id, CustomerId) |
| Dealership | Id bigint PK, Name nvarchar(200) NOT NULL, TimeZoneId nvarchar(100) NOT NULL | Positive ID, required valid IANA zone |
| ServiceType | Id bigint PK, Name nvarchar(100) NOT NULL, DurationMinutes int NOT NULL | DurationMinutes > 0; one global fixed duration |
| Technician | Id bigint PK, DealershipId bigint NOT NULL, DisplayName nvarchar(200) nullable | Dealer FK; unique (Id, DealershipId) |
| TechnicianQualification | TechnicianId bigint NOT NULL, ServiceTypeId bigint NOT NULL | Composite PK; both FKs; no expiry/grading in MVP |
| ServiceBay | Id bigint PK, DealershipId bigint NOT NULL, Name nvarchar(100) nullable | Dealer FK; unique (Id, DealershipId); all services compatible |
| DealershipOperatingWindow | Id bigint PK, DealershipId bigint NOT NULL, LocalStart datetime2(7) NOT NULL, LocalEnd datetime2(7) NOT NULL | Dealer FK; LocalEnd > LocalStart |
| TechnicianWorkingWindow | Id bigint PK, TechnicianId bigint NOT NULL, LocalStart datetime2(7) NOT NULL, LocalEnd datetime2(7) NOT NULL | Technician FK; LocalEnd > LocalStart |
| Appointment | Id uniqueidentifier PK, CustomerId/VehicleId/DealershipId/ServiceTypeId/TechnicianId/ServiceBayId bigint NOT NULL; StartUtc/EndUtc datetimeoffset(7) NOT NULL; DurationMinutes int NOT NULL; Status varchar(16) NOT NULL; RequestKey varchar(128) nullable; CreatedUtc datetimeoffset(7) NOT NULL | Constraints below |

Seed dated schedule windows with explicit local start and end dates; crossing midnight has
LocalEnd on the following date. Windows may overlap or touch; normalize their UTC union for
coverage. No weekday recurrence, holiday overrides, or administrative endpoints in this phase.
Both local boundaries must resolve uniquely in the dealership's named zone. Exclude the affected
window for that date when a boundary is ambiguous/nonexistent; do not exclude an entire day or
another technician's unaffected windows. Missing covering windows mean unavailable.

## Appointment Constraints and Atomicity

- FK CustomerId -> Customer; ServiceTypeId -> ServiceType; DealershipId -> Dealership.
- Composite FK (VehicleId, CustomerId) -> Vehicle(Id, CustomerId) enforces ownership.
- Composite FK (TechnicianId, DealershipId) -> Technician(Id, DealershipId).
- Composite FK (ServiceBayId, DealershipId) -> ServiceBay(Id, DealershipId).
- Composite FK (TechnicianId, ServiceTypeId) -> TechnicianQualification enforces qualification.
- CHECK Status = 'Confirmed'; EndUtc > StartUtc; DurationMinutes > 0.
- CHECK (EndUtc = DATEADD(minute, DurationMinutes, StartUtc)) enforces elapsed-duration/end
  equality using the saved duration snapshot, independently of application validation.
- Every primary key is NOT NULL. Required appointment fields and schedule parent/start/end
  fields are explicitly NOT NULL; CHECK predicates do not substitute for null rejection.
  Integration tests attempt direct SQL null inserts for status, duration, creation time and
  schedule boundaries and verify rejection with no changed rows.
- CHECK offsets of StartUtc, EndUtc, CreatedUtc are zero; values persist as canonical UTC.
- Derive EndUtc by adding positive elapsed minutes; validate against representable date range
  before arithmetic. Check saved duration/end consistency in domain and integration tests.
  Direct-SQL tests MUST reject mismatched duration/end values and overflowing arithmetic;
  valid values at 100 ns precision MUST preserve equality. Required fields remain NOT NULL.
  Snapshot DurationMinutes protects historical confirmations if reference configuration evolves.
- Both assignment FKs are non-null on the same row. No additional reservation rows: each
  confirmed Appointment reserves both resources over [StartUtc, EndUtc).
- Optional RequestKey uses Latin1_General_100_BIN2 collation and a length constraint. Contract
  restricts keys to 1–128 visible ASCII characters with no whitespace. This excludes trailing
  space equality surprises. Missing key is null; present empty keys are invalid.
- Filtered unique index (DealershipId, RequestKey) WHERE RequestKey IS NOT NULL.
  Key and booking fields commit together. No permanent failed-key record or separate expiry.
- All booking insertion paths hold the dealership application lock. Constraints alone do not
  enforce arbitrary overlap. Reference data cannot mutate during MVP serving.

## Indexes and Query Patterns

| Access | Index | Query/use |
|---|---|---|
| Appointment ID | PK Id | Direct projection for retrieval/commit verification |
| Confirmed replay | Unique DealerId, RequestKey filtered non-null | Exact key lookup under dealer lock |
| Technician overlap | TechnicianId, StartUtc INCLUDE EndUtc, Status; filter Confirmed | StartUtc < end AND EndUtc > start |
| Bay overlap | ServiceBayId, StartUtc INCLUDE EndUtc, Status; filter Confirmed | Same half-open predicate |
| Eligible technicians | Qualification ServiceTypeId, TechnicianId plus Technician DealerId, Id | Local qualified candidates, numeric ordering |
| Local bays | ServiceBay DealershipId, Id | Lowest free candidate |
| Dealer windows | DealershipId, LocalStart INCLUDE LocalEnd | Fetch windows intersecting requested local dates |
| Technician windows | TechnicianId, LocalStart INCLUDE LocalEnd | Fetch all candidate schedules in a batch |

Use parameterized queries and no-tracking projections. Fetch candidate working windows in one
batch; no query per candidate. Apply indexed overlap exclusion in SQL, then full-window coverage
in the domain and select lowest valid numeric IDs. Query window dates must include windows
starting earlier than the requested date but ending within/after the interval; do not assume
same-day requests. Explain and inspect scans with growing history as described in plan.md.

## Replay Equality and Lifecycle

Replay identity is (DealershipId, RequestKey). Payload equality is exact customer ID, vehicle
ID, service type ID, dealership ID, and normalized UTC start instant at 100 ns precision.
Assigned resources, calculated end, duration, status and telemetry fields are outputs and are
not caller payload fields. Equivalent input offsets representing the same instant are equal.
Unknown fields are rejected so ignored content cannot ambiguously change replay identity.

Lifecycle: no record -> Confirmed only through one successful transaction. Failed transactions
leave no appointment or assignments. Confirmed -> Confirmed on retrieval or keyed replay;
no cancellation, expiry, rescheduling, or completed-state transition. The appointment remains
Confirmed after its time passes; the historical interval no longer conflicts with later intervals.

Confirmed replay precedes future-time validation; it remains valid after its end and restart.
Known failed attempts do not consume keys; reuse with the same details starts a fresh attempt.
Before confirmation, no payload binding is retained after rollback; changed details after a
failed attempt are therefore a fresh request (technical consequence of storing keys only on
confirmed rows). Concurrent different payloads with a shared key are serialized; once one
confirms, others receive KEY_PAYLOAD_MISMATCH. Retain keys as long as appointments exist.

## Seed and Validation Requirements

Fixtures include at least two dealerships (one DST-observing zone), multiple resources with
numeric IDs, multiple services, qualifications including missing/local/other-dealer cases,
customers and owned vehicles, dated schedules, and confirmed bookings. Generate dates relative
to an injected clock for automated tests. Development seeding accepts an explicit base date;
never silently seed schedules that have already elapsed.

Validate ownership and references, future starts for new attempts, positive durations,
zone validity and full-interval coverage. Reject zero/negative IDs, malformed/offsetless times,
invalid keys and payload fields at the API boundary. SQL backstops ownership, locality,
qualification, non-null assignments and key uniqueness. Overlap and schedule correctness remain
protected by the transaction protocol and policy tests.
