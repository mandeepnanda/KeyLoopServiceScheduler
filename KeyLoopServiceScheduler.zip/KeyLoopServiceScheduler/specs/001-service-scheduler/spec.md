# Feature Specification: Keyloop Unified Service Scheduler

**Feature Branch**: Not created; no branch-creation hook is configured.

**Created**: 2026-10-09

**Status**: Draft

**Input**: User description in [specification-input-001.md](../../docs/specification-input-001.md).

## Clarifications

### Session 2026-10-09

- Q: Should booking require the entire appointment to fit both dealership operating hours and the assigned technician's working hours? → A: Require seeded dealership operating hours and technician working hours; missing hours mean unavailable.
- Q: How should dealership operating hours and technician working hours be interpreted across time zones? → A: Each dealership has a named time zone; both schedules use dealership-local time, including daylight-saving changes. Requests retain explicit offsets, and conflicts are compared as absolute instants.
- Q: Should each service type have one fixed duration shared across all dealerships, vehicles, and technicians? → A: One seeded positive duration per service type, shared across dealerships, vehicles, and technicians, with no setup or cleanup buffer.
- Q: Should every service bay support every service type, or must bays have service-specific capabilities? → A: Every seeded bay supports every service type; allocation checks dealership membership, operating hours, and booking conflicts without bay capability restrictions.
- Q: How should the scheduler choose resources when several qualified technicians and bays are available? → A: Select the lowest-identifier eligible technician and lowest-identifier available bay, after applying all qualification, dealership, schedule, and conflict rules.

Clarification session 2 (new invocation on the same date):

- Q: What should happen when a dealership opening, closing, or technician shift boundary falls at a local time that daylight-saving changes repeat or skip? → A: Exclude the affected schedule window for that date; other valid windows remain usable.

Clarification session 3 (clarification-input-002.md):

- Q: Should retrying the same booking request return the original appointment rather than risk creating another appointment? → A: Support an optional caller-supplied request key; the same key and booking details return the original confirmation, changed details with that key are rejected, and requests without a key are independent attempts.
- Q: Should a request key be unique across the whole scheduler or only within one dealership? → A: Request keys are unique within a dealership; the same key at another dealership identifies a separate request.

- Q: How long should a confirmed booking's request key remain usable to replay its original confirmation? → A: Retain the request key for as long as the appointment record exists, with no separate expiry.

- Q: If a keyed booking fails without creating an appointment, should the caller be able to retry using the same key? → A: Allow retry with the same key and details after a known failure; once confirmed, subsequent retries return that appointment.

- Q: Should an unsuccessful booking distinguish resource conflicts from temporary persistence failures? → A: Distinguish resource unavailability or booking conflicts, request-key mismatches, and technical failures with stable reason codes, clear explanations, and correlation identifiers.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Confirm a valid service appointment (Priority: P1)

As a dealership booking caller acting for an existing customer, I want to request service
for the customer's vehicle at a chosen dealership and time, so that the appointment is
confirmed with both a qualified technician and a service bay for its full duration.

**Why this priority**: A correct confirmed booking is the scheduler's primary business value.

**Independent Test**: Use sample customers, vehicles, service types, and resource schedules to
submit booking requests and inspect their outcomes and saved records without a frontend.

**Acceptance Scenarios**:

1. **AS-001**: **Given** a valid customer-owned vehicle and a qualified technician and bay
   available at the dealership for the entire service duration, **When** a booking is requested,
   **Then** exactly one confirmed appointment is created with a unique identifier, all requested
   details, both resource links, and the service-derived end time.
2. **AS-002**: **Given** no technician at the dealership is qualified for the selected service,
   **When** booking is requested, **Then** a clear unavailability error is returned and no
   appointment or resource reservation is created.
3. **AS-003**: **Given** all qualified dealership technicians are busy during any part of the
   requested interval, **When** booking is requested, **Then** booking fails without saving
   an appointment or reserving a bay.
4. **AS-004**: **Given** all dealership bays are busy during any part of the requested interval,
   **When** booking is requested, **Then** booking fails without saving an appointment or
   reserving a technician.
5. **AS-005**: **Given** the only eligible technician or the only available candidate bay has
   a confirmed booking with a partial overlap, **When** booking is requested, **Then** the
   request fails; repeat independently for technician and bay conflicts and for full overlap.
6. **AS-006**: **Given** both resources are otherwise available, **When** the requested interval
   ends exactly at an existing booking's start or starts exactly at its end, **Then** the
   adjacent appointment is accepted.
7. **AS-008**: **Given** only one eligible technician and one bay can serve an interval,
   **When** two independent conflicting requests (without keys or with distinct keys) arrive simultaneously, **Then** exactly one receives a
   confirmed booking and the other receives a conflict or unavailability outcome; no duplicate
   reservation or partial appointment remains. Repeat with only the technician shared, only
   the bay shared, and requests handled by different running instances.
   These acceptance runs use valid requests, healthy database connectivity, sufficient request
   budgets, and no injected faults. Technical failures fail the acceptance run and MUST be
   recorded, not excluded. Separate fault and contention tests require zero overlapping or
   partial confirmations without guaranteeing a successful response.
8. **AS-009**: **Given** an unknown customer, vehicle, dealership, or service type, a vehicle
   belonging to another customer, or an invalid start time, **When** booking is requested,
   **Then** a clear validation error is returned and no appointment or reservation is saved.
9. **AS-011**: **Given** a service with a known positive duration, **When** booking succeeds,
   **Then** the saved end time equals the start time plus that duration and every linked
   technician and bay belongs to the requested dealership.
10. **AS-012**: **Given** multiple eligible resource pairs, **When** one pair is unavailable
    but another covers the full duration, **Then** the request succeeds using a valid pair.
11. **AS-018**: **Given** otherwise eligible, conflict-free resources, **When** an appointment
    starts before opening or a technician's shift, ends after closing or the shift, or crosses
    a gap in either schedule, **Then** booking fails without an appointment or reservation.
    An appointment starting exactly at opening or shift start and ending exactly at closing
    or shift end is allowed when all other rules are satisfied.
12. **AS-019**: **Given** missing dealership hours or no qualified technician with working hours
    covering the requested interval, **When** booking or availability is requested, **Then**
    unavailability is reported and no appointment or resource reservation is created.
13. **AS-020**: **Given** a dealership with a named time zone and local operating and working
    hours, **When** equivalent requested instants are expressed with different offsets,
    **Then** booking and availability produce the same schedule and conflict decisions.
    Repeat on dates with different daylight-saving offsets, and verify that local opening
    and working hours follow the dealership's named time zone on each date.
14. **AS-021**: **Given** the same service type and otherwise valid bookings at different
    dealerships for different vehicles and technicians, **When** appointments are confirmed,
    **Then** each appointment has the same service-defined elapsed duration, with no added
    resource buffer. Repeat across a daylight-saving change to verify that end time is start
    plus elapsed duration rather than a local-clock adjustment.
15. **AS-022**: **Given** a supported service type, a qualified local technician, and any free
    local bay within the required operating and working hours, **When** booking is requested,
    **Then** the bay is eligible regardless of service type; no bay capability configuration
    is needed. Repeat for each seeded service type.
16. **AS-023**: **Given** multiple qualified, fully available local technicians and bays,
    **When** booking is requested, **Then** the lowest-identifier eligible technician and
    lowest-identifier available bay are assigned. If either lowest-identifier resource is
    ineligible or unavailable, it is skipped and the next valid resource is selected.
    Repeat with the same initial state and verify the same assignments.
17. **AS-024**: **Given** a dealership operating or technician working window with an opening,
    closing, or shift boundary at a repeated or nonexistent local time, **When** booking or
    availability is requested for that date, **Then** the affected window cannot establish
    availability. Repeat for each kind of boundary and both repeated and skipped times.
    Another unaffected window may establish availability if it covers the entire appointment
    and all other rules hold; otherwise booking fails without appointments or reservations.
18. **AS-025**: **Given** a confirmed booking made with a request key, **When** the same key
    and booking details are submitted again, including after restart or a lost response,
    **Then** the original appointment identifier and confirmation are returned with no new
    appointment or reservations. A different payload with that key is rejected without changes.
19. **AS-026**: **Given** two identical valid requests carrying the same key, **When** they
    arrive simultaneously, **Then** at most one appointment is created and any successful
    responses refer to that same appointment, even if multiple resource pairs are available.
20. **AS-027**: **Given** requests without a key, **When** identical details are submitted
    repeatedly, **Then** each submission is evaluated independently under normal booking rules;
    another valid resource pair may produce another appointment.
21. **AS-028**: **Given** a confirmed keyed booking at one dealership, **When** the same key
    is submitted at another dealership with otherwise valid booking details, **Then** the
    request is evaluated independently and may create a separate appointment. At the original
    dealership, the same key and details replay the original confirmation; changed details
    are rejected without modifying either dealership's appointments or reservations.

22. **AS-029**: **Given** an existing confirmed keyed appointment, **When** the same dealership, key, and booking details are submitted after more than 24 hours, after its end time, or after restart, **Then** the original confirmation is returned with no new appointments or reservations. No separate key expiry or future-start rejection applies to replay.

23. **AS-030**: **Given** a keyed attempt rejected for validation or unavailable resources, or
  a confirmation transaction that is known to have failed without committing, **When** its
  outcome is checked, **Then** no appointment or resource reservations exist from that attempt.
  **When** the same key and details are retried after the temporary cause clears, **Then** the
  normal booking rules are evaluated again and may produce one confirmation. A subsequent
  replay returns that confirmation rather than creating another appointment.
24. **AS-031**: **Given** a confirmation that committed but its response was lost, **When** the
  caller retries with the same dealership, key, and details, **Then** the committed appointment
  is returned without duplication. A communication failure MUST NOT be treated as evidence
  that no appointment committed; a technical uncertainty MUST NOT be reported as success or
  a definitive resource-unavailability result.

25. **AS-032**: **Given** separately a request with no valid resource pair, a confirmed request
  key reused with changed booking details, and a known failed confirmation transaction,
  **When** each request is processed, **Then** each returns its distinct stable reason code,
  clear explanation, and correlation identifier with no new appointment or reservations.
  Existing confirmed records remain unchanged. For an uncertain persistence outcome, a
  technical failure is reported without asserting rollback or resource unavailability;
  keyed retry resolves a committed confirmation under AS-031 without creating duplicates.

---

### User Story 2 - Retrieve a durable confirmed appointment (Priority: P2)

As a booking caller, I want to retrieve a confirmed appointment by its identifier, so that
I can verify the service details and assigned resources later.

**Why this priority**: Customers and dealership staff need a reliable record of a confirmation.

**Independent Test**: Retrieve a pre-existing confirmed sample appointment by identifier,
including after an application restart, without first using the booking workflow.

**Acceptance Scenarios**:

1. **AS-007**: **Given** a confirmed appointment, **When** the application restarts and the
   caller retrieves it, **Then** its identifier, details, status, and both resource links remain
   unchanged, and it still prevents overlapping bookings on its resources.
2. **AS-010**: **Given** an existing confirmed appointment, **When** its identifier is queried,
   **Then** the customer, vehicle, dealership, service type, technician, bay, start, end,
   and confirmed status are returned.
3. **AS-013**: **Given** an unknown or malformed appointment identifier, **When** retrieval is
   requested, **Then** a clear not-found or validation outcome is returned without changing data.

---

### User Story 3 - Check provisional service availability (Priority: P3)

As a booking caller, I want to check whether a dealership can perform a service at my requested
time, so that I can decide whether to attempt a booking.

**Why this priority**: A preliminary check helps callers choose a time but cannot replace
booking confirmation.

**Independent Test**: Query sample schedules with available and unavailable resource pairs
and verify the response and absence of new appointments or reservations.

**Acceptance Scenarios**:

1. **AS-014**: **Given** a valid dealership, service type, and start time with an eligible
   resource pair, **When** availability is queried, **Then** the result indicates availability
   for the entire derived interval and explicitly states that it is provisional until booking
   confirmation succeeds; no resource is reserved.
2. **AS-015**: **Given** no qualified technician or no fully available technician or bay,
   **When** availability is queried, **Then** the result indicates unavailability with a clear
   reason and the same provisional notice; no records are changed.
3. **AS-016**: **Given** availability was reported and another caller then reserves the only
   resource pair, **When** the original caller requests booking, **Then** booking re-evaluates
   availability and rejects the conflict without creating a partial booking.
4. **AS-017**: **Given** an unknown dealership or service type or invalid start time,
   **When** availability is queried, **Then** a validation outcome is returned without changing data.

### Edge Cases

- Partial overlap, containment, equal intervals, and either adjacent boundary are evaluated
  separately for technicians and bays. Intervals are half-open: start inclusive, end exclusive.
- A qualified technician at another dealership cannot satisfy the request; neither can a bay
  at another dealership or an unqualified but free local technician.
- A resource free at the start but unavailable before the end cannot satisfy the request.
- The entire appointment must fit seeded dealership operating hours and the selected
  technician's working hours, without crossing a closed or non-working gap. Missing hours
  mean unavailable. Availability queries enforce the same schedule boundaries as bookings.
- No technicians, no bays, or no qualifications in sample data produces unavailability.
- If an alternative valid pair exists, a conflict on one candidate does not reject the request.
- Lowest-identifier selection applies only to resources that pass every eligibility and
  availability rule; a lower identifier never overrides qualification, hours, or conflicts.
- Invalid times include missing or malformed values, missing time-zone offsets, times at or
  before the booking decision, and values for which the derived end cannot be represented.
- Zero or negative service duration is invalid reference data and cannot produce a confirmation.
- Equal instants expressed with different offsets must yield the same overlap decision.
- Dealership operating hours and technician working hours use the dealership's named time
  zone, including daylight-saving changes. A request's offset identifies its instant and
  does not replace the dealership's time zone for evaluating local hours.
- A schedule window whose local start or end boundary is repeated or skipped by a
  daylight-saving change is excluded for that date. Other valid windows remain usable.
  A transition inside a window with unambiguous boundaries does not by itself exclude it;
  the confirmed elapsed-duration and full-interval rules still apply.
- A request crossing midnight is accepted if its complete interval satisfies the resource rules.
- A failure while confirming cannot leave an appointment with only one assigned resource.
- Availability checks never hold resources; a positive result may become stale immediately.
- Repeating a request without a key is a new booking attempt. A keyed replay of a confirmed
  booking returns the original confirmation; changed details with that key are rejected.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001 — Appointment Request**: The system MUST accept an existing customer, a vehicle
  belonging to that customer, a dealership, a supported service type, and a requested start
  date and time. Acceptance: AS-001 and AS-009.
- **FR-002 — Service Duration**: The system MUST determine duration from the service type and
  derive end time as start plus that positive elapsed duration. Under the confirmed assessment
  assumption, each service type MUST have one seeded fixed duration shared across dealerships,
  vehicles, and technicians, with no setup, cleanup, travel, or buffer time added. Callers MUST
  NOT override duration or end time. Acceptance: AS-011, AS-021 and the invalid-duration edge case.
  Saved start, end and duration MUST preserve this elapsed-duration equality.
- **FR-003 — Technician Eligibility**: Only technicians qualified for the service, belonging
  to the requested dealership, and available for the entire interval MUST be eligible.
  The entire interval MUST fit the technician's seeded working hours; missing working hours
  mean the technician is unavailable. Acceptance: AS-001, AS-002, AS-003, AS-011, AS-018,
  AS-019 and cross-dealership edge cases.
- **FR-004 — Service Bay Availability**: An assigned bay MUST belong to the requested dealership
  and be available for the entire interval within dealership operating hours. Under the confirmed
  assessment assumption, every seeded bay MUST support every service type; no bay qualification
  or equipment capability filter applies. Acceptance: AS-004, AS-011, AS-018, AS-019, AS-022
  and full-duration and cross-dealership edge cases.
- **FR-005 — Conflict Detection**: The system MUST reject a booking if its assigned technician
  or bay overlaps an existing confirmed booking. Intervals MUST be half-open [start, end);
  overlap occurs when each interval starts before the other ends. Back-to-back appointments
  MUST be allowed. Acceptance: AS-005, AS-006 and AS-008.
- **FR-006 — Appointment Confirmation**: The system MUST automatically select one eligible
  technician and one available bay and confirm only when both are reserved together. Under
  the confirmed assessment assumption, it MUST select the lowest-identifier eligible technician
  and lowest-identifier available bay after applying all qualification, dealership, schedule,
  and conflict rules. Identifiers MUST have a documented stable total ordering so selections
  are reproducible. It MUST durably retain links to customer, vehicle, dealership, service type, technician, and bay,
  plus start time, end time, and confirmed status, and return a unique appointment identifier.
  Appointment and assignments MUST succeed or fail together. Acceptance: AS-001, AS-007,
  AS-008, AS-010, AS-011, AS-012, AS-023 and the partial-failure edge case.
- **FR-007 — Unavailable Resources**: If no valid resource pair exists, the system MUST return
  a clear business error and MUST NOT create an appointment or either resource reservation.
  Acceptance: AS-002 through AS-005 and AS-016.
- **FR-008 — Data Validation**: The system MUST reject unknown customers, vehicles, dealerships,
  and service types, invalid start times, and vehicles not owned by the requested customer.
  Validation failures MUST NOT persist appointments or reservations. Acceptance: AS-009,
  AS-017 and the invalid-time edge cases.
- **FR-009 — Appointment Retrieval**: The system MUST support retrieval of a confirmed
  appointment by identifier with all saved details and resource links. Unknown identifiers MUST
  produce a not-found outcome; malformed identifiers MUST produce a validation outcome.
  Acceptance: AS-007, AS-010 and AS-013.
- **FR-010 — Availability Query**: The system MUST allow a caller to query a dealership,
  service type, and start time using the same duration, qualification, and full-interval
  availability rules as booking. It MUST report availability or its absence, the derived
  interval, and an explicit notice that availability is provisional until confirmation succeeds.
  It MUST NOT create appointments or reserve resources. It MUST enforce the same dealership
  operating hours and technician working hours as confirmation. Acceptance: AS-014 through
  AS-017 and AS-019, plus the schedule-boundary edge cases.
- **FR-011 — Operating Hours (confirmed assessment assumption)**: The entire appointment
  MUST fit the dealership's seeded operating hours and the selected technician's seeded
  working hours, without crossing a gap in either. Missing dealership hours MUST mean
  unavailable. Starting exactly at opening or shift start and ending exactly at closing or
  shift end MUST be allowed if all other rules hold. Acceptance: AS-018 and AS-019.
- **FR-012 — Time Zones (confirmed assessment assumption)**: Each dealership MUST have a
  named time zone. Dealership operating hours and technician working hours MUST be evaluated
  in that zone, including daylight-saving changes. Requests MUST carry explicit offsets;
  schedule checks MUST interpret their instants in the dealership's zone, and conflicts MUST
  be compared as absolute instants. Equivalent instants with different supplied offsets MUST
  produce the same decision under otherwise identical conditions. A dealership operating or
  technician working window MUST be excluded for a date if either boundary is a repeated or
  nonexistent local time in that zone. Other unaffected windows MUST remain usable subject to
  all normal rules; no boundary is silently shifted or assigned a guessed offset.
  Acceptance: AS-020 and AS-024.

- **FR-013 — Booking Retries (confirmed assessment assumption)**: Booking requests MUST
  support an optional caller-supplied request key, unique within the requested dealership.
  The same key at another dealership MUST identify a separate request. Repeating the same
  dealership, key, and booking details
  after confirmation MUST return the original appointment identifier and confirmation without
  creating new appointments or assignments, including after restart. Reusing a confirmed key
  with changed details MUST be rejected without changes. Concurrent identical keyed requests
  MUST create at most one appointment; every successful response MUST identify that same
  appointment. Requests without a key MUST be independent attempts. Acceptance: AS-025
  through AS-029. A confirmed request key MUST remain usable for as long as its appointment record exists, with no separate expiry. Replay MUST return the original confirmation even after the appointment starts or ends; future-start validation applies only to new booking attempts. A known failed attempt MUST leave no appointment or reservations and MUST NOT permanently consume the key; the same key and details MUST be eligible for a fresh attempt. Once confirmed, replay is binding. Acceptance also includes AS-030 and AS-031.

- **FR-014 — Booking Failure Outcomes (confirmed assessment assumption)**: Unsuccessful
  booking outcomes MUST distinguish resource unavailability or booking conflicts,
  request-key detail mismatches, and technical failures. Each MUST provide a stable reason
  code, a clear explanation, and a correlation identifier without exposing internal or
  sensitive customer information. A technical failure MUST NOT be reported as resource
  unavailability or successful confirmation. A definitive failed confirmation MUST leave
  no appointment or either resource assignment. Acceptance: AS-030 through AS-032.

### Booking Outcome Evaluation Order

For reproducible outcomes when several conditions fail, booking MUST use this sequence:

1. Validate request syntax and header format; this does not establish resource eligibility.
2. Begin the booking transaction and acquire the dealership lock before authoritative reads.
3. Resolve confirmed-key replay or payload mismatch before new-booking validation.
4. Validate customer, vehicle, dealership and service references, then vehicle ownership.
5. Validate service duration and dealership time-zone configuration.
6. Derive the interval and validate representability and a strictly future start at the decision.
7. Evaluate dealership operating-hours coverage.
8. Evaluate local technician qualifications.
9. Evaluate qualified technicians' working-hours coverage and booking conflicts.
10. Evaluate local bay conflicts, select the lowest eligible resource identifiers, and persist
    both assignments with the appointment atomically before returning confirmation.

Multi-failure acceptance cases MUST establish this precedence. Confirmed replay bypasses
new-booking configuration, future-time and resource checks; syntax validation still applies.
Availability uses the same applicable validation and eligibility order but performs no replay,
resource reservation or booking write.

### Non-Functional Requirements

- **NFR-001 — Concurrent correctness**: Conflicting independent requests MUST NOT both confirm against
  the same technician or bay, even across running instances. Verify AS-008 repeatedly for
  each shared-resource variant and record outcomes; availability alone is not proof of safety.
- **NFR-002 — Durability and integrity**: Confirmed records and reservations MUST survive
  restart unchanged. Any failed confirmation MUST leave no partial appointment or assignment.
  Verify AS-007 and failure during confirmation.
- **NFR-003 — Understandable outcomes**: Validation, unavailability or conflict, and not-found
  outcomes MUST be distinguishable and explain the reason to a caller without exposing sensitive
  customer details or internal failures. Verify AS-002 through AS-005, AS-009, AS-013 and AS-017.
- **NFR-004 — Operational traceability**: Booking attempts and outcomes MUST be traceable with
  a correlation identifier. Routine operational records MUST avoid unnecessary customer-sensitive
  information. Verify successful and failed attempts can be correlated without customer names
  or vehicle identifying details in routine records.
- **NFR-005 — Verifiable delivery**: Automated checks MUST cover success, validation failures,
  unavailable resources, overlaps, concurrent requests, and retrieval after restart. Recorded
  results MUST distinguish passed, failed, and unexecuted checks; failures MUST NOT be hidden.
- **NFR-006 — Reproducible assessment**: Documentation MUST let a reviewer prepare sample data,
  run the service, exercise the three user journeys, and repeat verification. It MUST explain
  system design, assumptions, decisions, limitations, and AI collaboration and corrections.
  Verify by following the documented instructions in a clean assessment environment.

### Key Entities *(include if feature involves data)*

- **Customer**: Existing customer identified uniquely; owns one or more vehicles.
- **Vehicle**: Existing vehicle identified uniquely; belongs to one customer for booking validation.
- **Dealership**: Service location identified uniquely; owns the candidate technicians and bays
  and has a named time zone and seeded local operating hours that bound the entire appointment.
- **Service Type**: Supported service identified uniquely; defines one seeded positive fixed
  elapsed duration shared across dealerships, vehicles, and technicians, with no resource buffer.
- **Technician**: Dealership resource identified uniquely; has qualifications and a schedule of
  confirmed assignments and seeded working hours in the dealership's named time zone that
  bound the entire appointment.
- **Technician Qualification**: Relationship indicating the service types a technician may perform.
- **Service Bay**: Dealership resource identified uniquely; has a schedule of confirmed assignments,
  supports every service type, and is available only within dealership operating hours when
  free of booking conflicts.
- **Appointment**: Durable confirmed service commitment with a unique identifier, links to all
  six requested or assigned entities, a start, an end, and booking status. Its technician and
  bay assignments reserve both resources over the same complete interval.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Every valid new-booking acceptance case creates exactly one complete confirmed
  appointment with the service-derived duration and both resource assignments. Successful keyed
  replay returns the existing confirmation and creates zero new appointments or assignments.
  Validation, resource-unavailability and known rolled-back attempts create zero appointments
  or assignments. Uncertain commit outcomes follow SC-013 and MUST NOT imply proven rollback.
- **SC-002**: Across at least 100 repeated pairs of simultaneous independent conflicting requests for each
  AS-008 shared-resource variant, including requests handled by different instances, exactly
  one request per pair confirms and zero overlapping confirmed assignments exist.
  Runs use valid requests, healthy database connectivity, sufficient request budgets and no
  injected faults. Technical failures fail the acceptance run and MUST be recorded, not
  excluded. Separate fault and contention tests require zero overlapping or partial
  confirmations without guaranteeing a successful response.
- **SC-003**: Both forms of adjacent intervals are accepted in 100% of acceptance cases;
  partial, contained, and equal overlapping intervals are rejected for each constrained resource.
- **SC-004**: Every confirmed appointment used in restart verification is retrievable afterward
  with unchanged details and continues to block conflicting use of its assigned resources.
- **SC-005**: Every availability acceptance case correctly reports full-duration eligibility,
  includes the provisional notice, and changes zero appointments or resource reservations.
- **SC-006**: A reviewer following the supplied instructions can independently demonstrate
  booking, availability checking, and retrieval with the sample data and repeat all mandatory
  acceptance checks without undocumented setup steps.
- **SC-007**: All schedule-boundary and missing-hours acceptance cases produce the specified
  outcome: zero confirmations outside dealership or technician hours, zero confirmations
  without covering hours, and successful valid appointments at the exact opening and closing
  boundaries. Availability queries agree with these rules without reserving resources.
- **SC-008**: In all AS-020 cases, equivalent instants produce identical availability and
  conflict decisions regardless of the request's supplied offset, and local operating and
  working hours are respected on dates with different daylight-saving offsets.
- **SC-009**: All AS-021 cases yield the same elapsed duration for the same service type,
  including across daylight-saving changes, with zero added buffer time.
- **SC-010**: All AS-023 cases assign the lowest-identifier valid technician and bay, including
  when lower-identifier candidates must be skipped; identical initial states yield identical
  assignments in 100% of repeated selection checks.
- **SC-011**: All AS-024 cases exclude affected windows and create zero reservations from
  them. Unaffected windows covering the full appointment remain eligible in 100% of cases
  where all other booking rules are satisfied.

- **SC-012**: All successful keyed replay cases return the original identifier with zero new
  appointments or reservations. Concurrent identical keyed requests create at most one
  appointment, including when multiple valid resource pairs exist; changed details with a
  confirmed key produce zero booking changes.

- **SC-013**: Every AS-030 through AS-032 case yields the specified externally observable
  outcome. Known failed confirmations leave zero appointments and zero new reservations;
  committed confirmations remain complete and keyed retries create zero duplicates.
  All failure responses include the distinct reason code and correlation identifier.

## Assumptions

FR-001 through FR-010 and AS-001 through AS-010 originate in the supplied specification input.
The business defaults below are proposed assessment assumptions unless explicitly marked
confirmed in this clarification session. FR-011 and FR-012 and their schedule and time-zone
scenarios express confirmed assessment decisions; they are not additional requirements
quoted from Keyloop.
The fixed, shared, buffer-free duration rule in FR-002 is also a confirmed assessment assumption;
the original Keyloop requirement specifies service-derived duration without this configuration detail.
The universal bay compatibility rule in FR-004 is a confirmed assessment assumption; the
original Keyloop requirements do not specify bay equipment or service capabilities.
The lowest-identifier selection rule in FR-006 is a confirmed assessment assumption; Keyloop
explicitly requires a valid pair but does not prescribe a ranking policy.
Distinct failure codes and correlation identifiers in FR-014 are confirmed assessment assumptions. Atomic confirmation, no partial bookings, conflict prevention, and provisional availability remain mandatory requirements from the input and constitution.
Optional request keys and confirmed-booking replay in FR-013 are confirmed assessment
assumptions, not requirements stated in the original specification input. Request keys are
confirmed to be scoped to the requested dealership, not globally unique across dealerships.

- **A-001 — Actors**: A caller represents a customer or dealership booking process. Identity,
  authentication, and authorization workflows are not added to this assessment feature.
- **A-002 — Existing data**: Pre-seeded records supply customers, vehicle ownership, dealerships,
  service types and durations, technician qualifications, and bays. Creating or editing these
  records is outside scope. A service type is usable at a dealership if a local technician is
  qualified; a separate dealership service catalogue is not required.
- **A-003 — Time rules**: Requests use explicit offsets to identify unambiguous instants. A start
  must be strictly in the future when the booking decision is made; there is no minimum lead
  time, maximum booking horizon, or fixed slot grid in this version. Availability applies the
  same future-time validation. Comparisons use instants rather than displayed local clock values.
  The named dealership time zone and explicit request offsets are confirmed by FR-012;
  the future-start restriction and absence of lead-time or horizon limits remain proposed defaults.
- **A-004 — Resource schedules (confirmed)**: Confirmed appointments block resources. Seeded
  dealership operating hours and technician working hours MUST both cover the entire interval
  with no closed or non-working gaps. Missing hours mean unavailable. Bays follow dealership
  operating hours. Shift, holiday, leave, and maintenance administration remain outside scope.
  Both schedules use dealership-local time in its named zone, including daylight-saving changes.
  For a date when either local boundary is repeated or nonexistent, the affected window is
  excluded. Other unaffected windows remain usable under the normal full-interval rules.
- **A-005 — Duration (confirmed)**: Each service type has one seeded fixed positive elapsed
  duration, independent of dealership, vehicle, and technician. No setup, cleanup, travel,
  or buffer time is added. End time is start plus elapsed duration, including across
  daylight-saving changes. Duration configuration administration remains outside scope.
- **A-006 — Selection (confirmed)**: Select the lowest-identifier eligible technician and
  lowest-identifier available bay using a documented stable identifier ordering. Apply all
  qualification, dealership, schedule, and conflict rules before selection. Caller-selected
  resources, fairness, load balancing, and additional preference ranking are not required.
- **A-007 — Confirmation**: Only confirmed appointments reserve resources. No pending holds,
  reservation expiry, cancellation, or rescheduling is included. Confirmed bookings made with
  a request key have the replay guarantee in FR-013 for the lifetime of the appointment record, with no separate key expiry; unkeyed requests remain independent. Known failed attempts do not permanently consume the key; the same key and details may be retried. These retry and retention rules are confirmed assessment assumptions.
- **A-008 — Bays (confirmed)**: Every seeded bay supports every service type. Allocation
  checks dealership membership, operating hours, and booking conflicts; no bay qualification
  or equipment compatibility configuration is required.
- **A-009 — Assessment limits**: No production workload or response-time target was supplied.
  The concurrency repeat count in SC-002 is a verification baseline, not a capacity claim.

## Scope

### In Scope

- Optional request keys for safe replay of confirmed bookings and rejection of changed
  booking details with a confirmed key.
- Backend booking, durable confirmation, retrieval, and provisional availability checking.
- Existing-customer and vehicle-ownership validation, service-derived durations, qualified
  local technician selection, local bay selection, and full-duration conflict prevention.
- Pre-seeded sample dealership, customer, vehicle, technician, bay, service-type, and
  qualification data, plus dealership operating hours and technician working hours, sufficient
  to demonstrate positive, negative, schedule-boundary, and concurrent scenarios.
- Named dealership time zones and evaluation of local schedules across daylight-saving changes.
- Backend demonstrations through documented requests and automated verification, with a
  mocked frontend experience consistent with the constitution.
- Documentation and operational evidence required by NFR-004 through NFR-006.

### Out of Scope

- A production frontend, payments, notifications, and external dealership-management integration.
- Cancellation, rescheduling, temporary holds, customer or vehicle registration, and resource
  or qualification administration.
- Authentication infrastructure, multi-service appointments, resource-selection optimization,
  and duplicate-request replay guarantees for submissions without a request key.
- Technical framework, storage, hosting, or implementation selection during specification.

## Risks and Unresolved Questions

- **R-001 — Stale availability**: Another request may consume resources after a positive query.
  AS-016 and FR-006 require confirmation to enforce correctness independently of the query.
- **R-002 — Concurrent or interrupted confirmation**: Overlap races and partial failure can
  corrupt schedules. NFR-001 and NFR-002 require evidence of exclusive, all-or-nothing outcomes.
- **R-003 — Real dealership calendars**: Seeded operating and working hours bound this assessment.
  Holiday, absence, and calendar administration require later scope; missing hours fail closed
  as unavailable under the confirmed A-004 rule.
- **R-004 — Reference-data quality**: Wrong ownership, qualification, or duration data undermines
  selection. Sample data must be internally consistent; invalid durations cannot confirm bookings.
- **R-005 — Lost confirmation response**: A caller may retry after an unseen successful booking.
  Reusing its request key and details returns the original confirmation. Without a key, a
  retry may conflict with the original booking or create another appointment on other resources.
- **R-006 — Assessment versus production use**: Identity controls and production performance
  targets remain outside this assessment and must be defined before extending to production use.
- **Unresolved questions**: No blocking business questions remain for the assessment.
  Eleven business decisions are confirmed across three
  clarification invocations. Remaining proposed defaults
  include future-start validation, qualification by seeded service-type relationship, and
  confirmed-only lifecycle without holds. These are distinct from the
  explicit requirements and remain documented assessment assumptions.
- **Daylight-saving boundary limitation (confirmed)**: Affected schedule windows are excluded
  for that date when either boundary is repeated or nonexistent; unaffected windows remain
  usable. This conservative assessment rule can reduce bookable hours on transition dates,
  but avoids inventing operating or working hours.
- **Deferred planning detail — Identifier ordering**: Planning MUST document the stable total
  ordering used to interpret lowest identifier. Identifier representation is an implementation
  choice; it MUST preserve the confirmed deterministic selection behavior.
