# Research and Technology Decisions

Date: 2026-10-09. Source inputs: spec.md, constitution v1.0.0, docs/plan-input-001.md.
The updated planning input specifies .NET 10; the earlier .NET 8 conflict is resolved.
All decisions below are proposed technical design, not measured implementation results.

## ADR-001 — Runtime and dependencies

**Decision:** C# on .NET 10 LTS, ASP.NET Core controllers, EF Core 10 SQL Server provider,
SQL Server 2022 Developer for local non-production use, xUnit, ASP.NET Core testing,
Serilog.AspNetCore 10, and OpenTelemetry SDK instrumentation. Use built-in OpenAPI generation.
Pin compatible stable package patches and SDK in implementation; do not select prerelease
instrumentation merely to obtain SQL spans. Custom transaction spans provide a stable fallback.

**Rationale:** Matches the updated input and constitution; one runtime family reduces version drift.
**Alternatives considered:** .NET 8 conflicts with current inputs; microservices add unnecessary scope.
Evidence: [.NET support](https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core),
[ASP.NET Core OpenAPI](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/openapi/overview?view=aspnetcore-10.0),
[Serilog guidance](https://github.com/serilog/serilog-aspnetcore/blob/dev/README.md).

## ADR-002 — Cooperative dealership serialization

**Decision:** Explicit ReadCommitted transaction; exclusive transaction-owned sp_getapplock
on canonical resource scheduler:dealership:<numeric-id>, same database and public database
principal, before any booking eligibility, key lookup, or conflict reads. All booking writers
must use this convention. Different dealerships use different lock resources.

**Rationale:** A dealership is a disjoint pool of technicians and bays. Serializing its writers
makes read-select-insert indivisible relative to other participating writers, with a short,
auditable critical section. This correctness argument is a design inference, pending real SQL tests.
**Alternatives considered:** In-process locks cannot coordinate processes. Prechecks race.
Rowversion does not protect missing overlapping rows. Serializable range locking can work but
needs more complex access-path and deadlock analysis. Per-resource locks complicate discovery
and ordered acquisition. SQL Server has no simple unique constraint for arbitrary interval overlap.

SQL application locks are database/principal scoped, require an active transaction when owned
by Transaction, and are released by commit or rollback. Return codes >=0 succeed; -1 timeout,
-2 cancellation, -3 deadlock, -999 call error. Explicitly read the procedure return value, not
rows affected. Application-lock deadlock errors require explicit rollback.
Evidence: [sp_getapplock](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql?view=sql-server-ver17).

## ADR-003 — Atomic record and retry behavior

**Decision:** One Appointment row holds both non-null resource foreign keys; its interval reserves
both resources. Persist the optional request key on that row with a filtered unique index on
(DealershipId, RequestKey). No separate failed-request or pending-hold rows. Numeric bigint
reference identifiers sort ascending; appointment IDs are application-generated GUIDs.
The same-row CHECK (EndUtc = DATEADD(minute, DurationMinutes, StartUtc)) enforces elapsed
duration/end equality from the duration snapshot. Application validation still rejects overflow
before arithmetic; direct-SQL integration cases validate mismatches, overflow and 100 ns precision.

**Rationale:** One durable row eliminates a partial-assignment representation. The key and
confirmation commit together; failed attempts do not consume a key. Compare customer, vehicle,
service type, dealership, and canonical start instant for replay; equivalent offsets are equal.
Key equality is exact case-sensitive ASCII, with no trimming. Lookup precedes future-time checks.
**Alternatives considered:** Separate reservation tables add consistency work for no MVP benefit;
expiration contradicts the confirmed lifetime policy; required keys contradict optional keys.

## ADR-004 — Bounded failures, no blind write replay

**Decision:** Disable automatic EF/SqlClient booking-write retries. At most one whole-transaction
retry, with 100–250 ms jitter, only after a known rollback and transient deadlock/connectivity
failure before commit. Do not retry validation, business unavailability, key mismatches, lock
wait expiry, cancellation, or an uncertain commit. Keep one appointment GUID per server operation.
For a commit exception, inspect that GUID on a fresh primary connection once if deadline permits;
otherwise return a technical outcome with unknown commit state. Keyed client retry finds a
committed row under the same dealer lock. An unkeyed client retry has no deduplication guarantee.

**Rationale:** A connection failure during commit does not prove rollback. Bounded verification
avoids creating another appointment through blind replay. Fresh contexts discard failed state.
Each attempt owns one Infrastructure-created unit of context, transaction, lock and stores;
Application sees only attempt-bound ports. Every booking read/write shares that connection and
transaction. Dispose the entire unit before retry, including stores; never reuse request-scoped
stores bound to the failed context.
The response-work deadline is 10 seconds; verification uses remaining time only. Cancelled
rollback has a separate maximum 1-second cleanup budget. Disposal/disconnect detection can take
longer and is not a server-lock-release deadline. A still-connected caller receives REQUEST_TIMEOUT
only with established no-write/rollback; uncertain commit remains BOOKING_OUTCOME_UNKNOWN.
**Alternatives considered:** EF retry strategy wrapping the whole transaction can be introduced
later with explicit success verification; stacked provider/application retries obscure budgets.
Evidence: [EF resiliency](https://learn.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency),
[EF transactions](https://learn.microsoft.com/en-us/ef/core/saving/transactions).

## ADR-005 — Time and schedule design

**Decision:** Store appointment instants as UTC datetimeoffset(7), durations as positive integer
minutes, dealership IANA zone names, and seeded dated local schedule windows. Each window has
local start/end datetime2(7). Resolve using TimeZoneInfo; exclude a window when either boundary
is invalid or ambiguous. Merge overlapping or adjacent valid windows before coverage checks.
Use elapsed duration across transitions; accept cross-midnight dated windows. Missing zone or
unknown zone is invalid reference configuration, not silent UTC fallback.

**Rationale:** Dated seed windows need no recurring-calendar engine and support full-interval,
DST, and midnight acceptance cases. Named zones remain distinct from request offsets.
**Alternatives considered:** Fixed offsets violate confirmed DST behavior; recurring schedule
administration and a second time library are unnecessary assessment complexity.
Evidence: [TimeZoneInfo](https://learn.microsoft.com/en-us/dotnet/api/system.timezoneinfo).

## ADR-006 — Verification, telemetry, and caching

**Decision:** Pure policy unit tests; WebApplicationFactory HTTP integration tests with real SQL
Server; separately launched API processes for concurrency evidence. No EF InMemory/SQLite substitute
for SQL concurrency. Serilog JSON console records; OpenTelemetry ASP.NET Core instrumentation,
custom booking/lock/transaction activities and meters, optional OTLP endpoint. No availability
cache or Redis. Initially query reference data directly; profiling may justify bounded caching.

**Rationale:** Test the deployed database semantics, keep telemetry portable, avoid stale allocation.
Console/OTLP/log sinks run behind bounded nonblocking queues. Emit completed lock/transaction
measurements after lock release; full queues drop telemetry rather than blocking booking.
Count logical requests, transaction attempts, new confirmations and replays separately. Rate
denominators are terminal logical requests; exclude technical failures from resource-conflict counts.
Test-only Infrastructure decorators inject pre-save/pre-commit faults, negative application-lock
results and a simulated connection error after a real successful SQL commit. That last test
proves recovery logic, not transport fidelity. Real held-lock tests and separate-process races
remain necessary. Include same-key/different-payload races, mandatory-column null rejection,
timestamp validation, cancellation and blocked telemetry-sink tests.
**Alternatives considered:** Mock-only concurrency tests do not exercise locks; cache invalidation
complexity outweighs benefit for seed-only reference data at assessment volume.
Evidence: [ASP.NET testing](https://learn.microsoft.com/en-us/aspnet/core/test/integration-tests?view=aspnetcore-10.0),
[OpenTelemetry libraries](https://opentelemetry.io/docs/languages/dotnet/libraries/).

## Research resolution

No unresolved technical choices block Phase 1. SDK and dependency patch pinning, physical
migrations, query plans, and actual performance verification belong to implementation.
The lock protocol is cooperative: privileged ad hoc SQL writes bypass it. Reference data is
immutable while serving the MVP. Any future booking or schedule mutation must join the protocol.

## Approved Architecture Review Corrections

The approved review closes nullability, regex, retry-unit ownership, deadline/cleanup, contract,
test-seam and telemetry gaps. Resource conflicts use TECHNICIAN_UNAVAILABLE/BAY_UNAVAILABLE;
the undefined generic conflict code is removed. Booking replay/failure scenarios are grouped
under the booking story. No additional application infrastructure or implementation code is added.

## Approved Requirements-to-Task Analysis Corrections

The approved top-five corrections add the same-row duration/end CHECK, healthy AS-008/SC-002
preconditions with technical failures recorded as failed runs, explicit SC-001 creation versus
replay outcomes, one ordered booking decision sequence after replay, and conflict rates based
on terminal logical requests rather than transaction attempts. Mapping, migration, direct-SQL,
multi-failure and metric tests are assigned in tasks.md. Fault/contention safety remains distinct
from healthy acceptance, and unknown commit never implies rollback. These are design corrections;
no database constraint, application test or runtime measurement has been executed by this update.

Constraint capability evidence: [SQL Server table CHECK expressions](https://learn.microsoft.com/en-us/sql/t-sql/statements/alter-table-table-constraint-transact-sql?view=sql-server-ver16)
support same-row column comparisons; [DATEADD](https://learn.microsoft.com/en-us/sql/t-sql/functions/dateadd-transact-sql?view=sql-server-ver16)
supports datetimeoffset column inputs. The proposed equality CHECK still requires migration and
direct-SQL verification on the selected SQL Server version.
