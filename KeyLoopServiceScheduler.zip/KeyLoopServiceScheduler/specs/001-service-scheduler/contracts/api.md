# HTTP API Contract

Canonical machine-readable companion: [openapi.json](openapi.json). Base path /api/v1.
UTF-8 JSON. No authentication for local MVP. Public production hosting is outside this plan.
All responses include X-Correlation-ID; valid supplied IDs are ASCII tokens <=64 characters,
otherwise generate one. Trace context is handled independently. Errors use application/problem+json.
JSON integers identify reference entities (SQL bigint); GUID strings identify appointments.
Clients must support 64-bit reference IDs. Unknown properties are rejected.

## Operations

| Operation | Request | Success | Failure |
|---|---|---|---|
| POST /api/v1/appointments | customerId, vehicleId, dealershipId, serviceTypeId, startTime; optional Idempotency-Key header | 201 new with Location; 200 replay with same body and Location | 400 validation; 409 unavailable/conflict/key mismatch; 503 technical; 500 unexpected |
| GET /api/v1/appointments/{id} | GUID identifier | 200 Appointment | 400 malformed ID; 404 unknown; 503 database unavailable; 500 unexpected |
| GET /api/v1/availability | dealershipId, serviceTypeId, startTime query | 200 Availability, whether available or not | 400 validation; 503 database unavailable; 500 unexpected |
| GET /health/live | None | 200 alive | Process unavailable cannot respond |
| GET /health/ready | None | 200 database accessible | 503 unavailable |

New startTime is an ISO 8601 timestamp with explicit numeric offset or Z, at most seven
fractional-second digits; precision is not silently truncated. Validate the complete calendar value, offset within -14:00 to +14:00, and both normalized start and derived end within year 0001 through 9999. Reject invalid dates, overflow, offsetless values and excess precision as INVALID_START_TIME. JSON reference IDs must fit signed 64-bit positive integers; overflow is INVALID_REQUEST. No end/duration/resource input.
IDs must be positive. Derivation uses positive elapsed service minutes. A new start must be
strictly future at the locked booking decision (or availability evaluation); replay precedes
this check. Request offsets identify instants; dealership zone defines local schedule coverage.

Appointment body: id, customerId, vehicleId, dealershipId, serviceTypeId, technicianId,
serviceBayId, startTime, endTime, durationMinutes, status (Confirmed). Times are UTC with Z.
No customer names, vehicle identifying information or raw request key in the response.
A new confirmation is returned only after successful commit. Location points to retrieval.

Availability body: dealershipId, serviceTypeId, startTime, endTime, available (boolean),
reasonCode (AVAILABLE or unavailability code), and notice. Notice always reads:
"Availability is provisional until booking confirmation succeeds."
No candidate reservation or promise of a specific assignment is made. Missing hours/no
resources is a successful query with available=false; malformed or unknown references are 400.

## Request Keys

Idempotency-Key is optional, case-sensitive, 1–128 visible ASCII characters without whitespace;
no trimming. Missing header means independent booking; empty/invalid header is 400 INVALID_KEY.
Scope is requested dealership. Confirmed payload comparison uses customer/vehicle/dealer/service
IDs and canonical start instant; equivalent offsets compare equal. Same key/detail replay returns
200 and original ID, even after restart or appointment end. Different details return 409
KEY_PAYLOAD_MISMATCH without changing bookings. Keys have no separate expiry.

Same-key concurrent requests create at most one booking. Any successful responses identify that
booking. A technical timeout may still occur for a waiting caller; retry safely with the same key.
Known failed attempts retain no key or appointment and allow a fresh attempt. A lost response
or commit uncertainty is not a known failure: retry the same key to resolve a durable result.
Unkeyed repeated requests can create additional appointments if other valid pairs exist.

## Problem Details and Error Codes

Fields: type (stable urn:keyloop:problem:<code>), title, status, detail, instance (path),
code, correlationId; optional errors maps fields to validation messages; optional outcome
is not_committed or unknown for technical failures where known. No DB exception text exposed.

| HTTP | Stable code | Meaning/retry behavior |
|---|---|---|
| 400 | INVALID_REQUEST | Missing/unknown fields, malformed IDs or values |
| 400 | UNKNOWN_CUSTOMER / UNKNOWN_VEHICLE / UNKNOWN_DEALERSHIP / UNKNOWN_SERVICE_TYPE | Referenced record does not exist |
| 400 | VEHICLE_CUSTOMER_MISMATCH | Vehicle does not belong to requested customer |
| 400 | INVALID_START_TIME / INVALID_KEY | Correct input; no booking created |
| 409 | NO_QUALIFIED_TECHNICIAN | No local technician qualified for service |
| 409 | DEALERSHIP_CLOSED | No operating window covers full interval |
| 409 | TECHNICIAN_UNAVAILABLE | No qualified technician with full schedule coverage/free interval |
| 409 | BAY_UNAVAILABLE | No free local bay for interval |
| 409 | KEY_PAYLOAD_MISMATCH | Confirmed key reused with changed details |
| 503 | REQUEST_TIMEOUT | Response-work deadline reached before commit with established no-write/rollback; retry same key |
| 503 | BOOKING_BUSY | Finite dealership lock wait expired; not a resource conflict |
| 503 | DATABASE_UNAVAILABLE | Known pre-commit persistence/connection failure |
| 503 | BOOKING_OUTCOME_UNKNOWN | Commit could not be verified; use same keyed retry |
| 500 | INVALID_REFERENCE_CONFIGURATION / INTERNAL_ERROR | Invalid service duration/zone or unexpected defect; do not invent availability |
| 404 | APPOINTMENT_NOT_FOUND | Valid identifier has no appointment |

409 availability codes also appear in 200 available=false query results. Booking decision order:

1. Validate request syntax and header format before starting the transaction.
2. Begin ReadCommitted and acquire the dealership lock before authoritative reads.
3. Resolve confirmed-key replay or payload mismatch before new-booking validation.
4. Validate customer, vehicle, dealership and service references, then vehicle ownership.
5. Validate service duration and dealership time-zone configuration.
6. Derive the interval and validate representability and strictly future start at the decision.
7. Evaluate dealership operating-hours coverage.
8. Evaluate local technician qualifications.
9. Evaluate qualified technician working-hours coverage and booking conflicts.
10. Evaluate local bay conflicts, select lowest eligible IDs and persist both assignments atomically.

This order determines the primary reason when multiple conditions fail; tests include paired
failures. Syntax validation still applies to replay, which bypasses new-booking configuration,
future-time and resource checks. Availability follows the applicable validation/eligibility order
without replay, reservations or writes. Use TECHNICIAN_UNAVAILABLE or BAY_UNAVAILABLE for booking
conflicts, including after a stale advisory check; there is no generic conflict code. Do not retry
business outcomes internally.
503 may include Retry-After: 1 for known transient/busy failures; it is a hint, not a success
promise. Do not advise a new key on an unknown outcome. Unexpected exceptions produce 500
without falsely asserting rollback. A disconnected caller may receive no HTTP response;
cleanup still executes and uncertain commit retains the same recovery rules.

Recovery guidance distinguishes operation, original valid-key presence and known persistence
outcome. For keyed uncertainty, replay the original key with unchanged details. For unkeyed
uncertainty, explain that confirmation may exist, retry can duplicate it and a new key cannot
recover the original attempt. Known noncommits permit retry. GET failures omit booking-key advice.

Example technical error:

```json
{
  "type": "urn:keyloop:problem:BOOKING_BUSY",
  "title": "Booking is temporarily busy",
  "status": 503,
  "detail": "The booking was not confirmed. Retry later using the original request key and unchanged booking details.",
  "instance": "/api/v1/appointments",
  "code": "BOOKING_BUSY",
  "correlationId": "assessment-01",
  "outcome": "not_committed"
}
```

## Contract Verification

Assert all FR-001–FR-014/AS-001–AS-032 statuses and fields, UTC timestamps, correlation propagation,
201/200 replay distinction, validation and key mismatch, empty availability, rollback and
uncertain-outcome responses. Generated runtime OpenAPI must match this design contract or an
intentional reviewed contract amendment. Development OpenAPI is /openapi/v1.json; a development
UI may be added only as a backend demonstration, not a production frontend.

## Deadline, Validation, and Evidence

The response-work deadline is 10 seconds; verification may use only its remaining budget.
An independent rollback cleanup token is capped at 1 second. Disposal/SQL disconnect detection
can finish later; this is not a hard 10-second server-lock-release promise. If still connected,
return REQUEST_TIMEOUT with outcome=not_committed only when rollback/no-write is established;
otherwise, after commit begins, return BOOKING_OUTCOME_UNKNOWN with outcome=unknown. No response
may be deliverable after client disconnect. No new query or retry runs during cleanup.

Contract tests must use ECMAScript-compatible regex evaluation for the machine-readable schemas,
accept the documented key and every visible ASCII character, and reject whitespace/control or
non-ASCII keys. Validate timestamp syntax and actual calendar/range/precision separately.
All success and error responses, including health responses, declare X-Correlation-ID; booking
200 replay and 201 creation both declare Location. Failure-code tests assert resource conflict,
key mismatch, busy, timeout and uncertain commit remain distinct as specified.
