# Quickstart and Validation Guide

The current increment provides source projects, the initial migration, seed-only mode,
availability/booking application services and domain/persistence/lifecycle tests. Live SQL verification remains unexecuted
on this host. Business endpoints, readiness/OpenAPI, telemetry and process/load harnesses now exist;
their SQL-backed acceptance and performance execution remain open. For a runnable local demonstration,
follow [demo instructions](../../docs/demo-instructions.md). See [persistence evidence](../../docs/verification/persistence.md),
[API semantics](contracts/api.md) and [schema](data-model.md).

## Prerequisites

- .NET 10 SDK and compatible dotnet-ef 10 tool pinned in a local tool manifest.
- SQL Server 2022 Developer local instance or Docker-hosted persistent SQL instance.
- Database connection permission for migrations/seed and a separate runtime login with minimal
  read/write rights and application-lock permission; no runtime schema administration.
- SQL tools or a client able to inspect appointments/locks. Docker is optional for a local
  Windows SQL Server; it is required only if choosing the container test environment.
- Release-build two-process test harness and a disposable isolated test database.

Do not use production SQL databases for seeding or destructive fixture resets. The SQL Developer
edition is only for development/test; production requires appropriately licensed/managed storage.
Secrets are local environment/user secrets, not tracked configuration.

## Setup and Start

From the repository root in PowerShell:

```powershell
dotnet --version
dotnet tool restore
dotnet restore KeyLoopServiceScheduler.slnx
dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore
$env:ConnectionStrings__Scheduler = 'Server=localhost;Database=KeyLoopScheduler;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=False;ConnectRetryCount=0;Connect Timeout=3'
dotnet ef database update --project src/KeyLoopServiceScheduler.Infrastructure --startup-project src/KeyLoopServiceScheduler.Api
$env:ASPNETCORE_ENVIRONMENT = 'Development'
dotnet run --project src/KeyLoopServiceScheduler.Api -- --seed-only --seed-base-date 2030-01-07
dotnet run --project src/KeyLoopServiceScheduler.Api -- --urls http://localhost:5080
```

The connection example is local Windows integrated security; Linux/container execution needs
an externally supplied SQL login connection string. TrustServerCertificate=True is a local-only
shortcut. Validate certificates and use secrets management for production. Seed-only mode
exits after deterministic seeding and rejects incompatible existing reference data. Choose a future
base date at execution time, and align requests to fixture dates. Tests inject a fixed clock.
Do not run automatic migrations independently on multiple running API replicas.

GET /health/live returns 200; GET /health/ready returns 200 when the configured database is reachable,
otherwise 503. GET /openapi/v1.json returns the generated contract in Development.
Dated windows and named zones must resolve on the chosen
OS; validate the DST-observing seed zone rather than silently falling back to UTC.

## Happy Path and Key Replay

With the implemented seed manifest: customer 1 owns vehicle 1, dealership 1 has operating hours
09:00–17:00 in Asia/Kolkata on 2030-01-07, service 1 lasts 60 minutes, technician 1 is qualified
and works 09:00–12:00 and 13:00–17:00. Seeded history occupies technician 1/bay 1 at
10:00–11:00; the 09:00 example below is adjacent and free. The HTTP journey is implemented;
its SQL execution still requires the externally configured instance and seed.

```powershell
$baseUrl = 'http://localhost:5080'
$bookingBody = @{ customerId=1; vehicleId=1; dealershipId=1; serviceTypeId=1; startTime='2030-01-07T09:00:00+05:30' } | ConvertTo-Json
$bookingHeaders = @{ 'Idempotency-Key'='assessment-booking-001'; 'X-Correlation-ID'='assessment-001' }
$booking = Invoke-RestMethod -Method Post -Uri "$baseUrl/api/v1/appointments" -ContentType 'application/json' -Headers $bookingHeaders -Body $bookingBody
Invoke-RestMethod -Uri "$baseUrl/api/v1/appointments/$($booking.id)"
Invoke-RestMethod -Method Post -Uri "$baseUrl/api/v1/appointments" -ContentType 'application/json' -Headers $bookingHeaders -Body $bookingBody
Invoke-RestMethod -Uri "$baseUrl/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=2030-01-07T09%3A00%3A00%2B05%3A30"
```

Inspect status/headers with Invoke-WebRequest or docs/requests.http: first POST 201 with Location;
replay 200 with same ID; UTC interval 04:30Z–05:30Z; status Confirmed; assigned lowest eligible
numeric technician/bay IDs. Availability may still be true if another pair remains; the notice
must always state it is provisional. No new rows arise from retrieval/query/replay.
Changed vehicle/customer/service/start with that confirmed key yields 409 KEY_PAYLOAD_MISMATCH.
Same key at dealership 2 is independent. Equivalent timestamp offsets replay identically.

## Automated Verification

```powershell
dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --logger 'trx;LogFileName=unit.trx'
dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --logger 'trx;LogFileName=integration.trx'
dotnet test tests/KeyLoopServiceScheduler.ProcessTests -c Release --logger 'trx;LogFileName=process.trx'
```

Real SQL integration/process fixtures create isolated databases, apply migrations and seed a
fixed clock; no fallback to EF InMemory or SQLite if SQL is unavailable. Report unavailable SQL
as an unexecuted/failed prerequisite, never a passing concurrency check. Save logs and test reports.

Also verify direct SQL rejects null appointment status/duration/creation time and null schedule
parents/boundaries; CHECK constraints alone are insufficient for null rejection.
The separate CHECK (EndUtc = DATEADD(minute, DurationMinutes, StartUtc)) MUST reject
direct-SQL duration/end mismatches and arithmetic overflow and accept valid 100 ns precision.
Every retry must use a fresh attempt unit while all stores within that attempt share its one
SQL connection/transaction.
Contract checks validate the corrected key regex with ECMAScript semantics, including the sample
key, every visible ASCII character, and rejection of control/whitespace/non-ASCII values. Reject
offsetless, invalid-calendar, out-of-range, >7-digit fraction, and derived-end-overflow timestamps.
Check UTC-only responses, replay Location, all correlation headers and stable error codes.
Multi-failure cases follow spec.md §Booking Outcome Evaluation Order: syntax/header parsing,
transaction/lock, confirmed replay/mismatch, references/ownership, duration/zone configuration,
derived interval/future start, dealer hours, local qualifications, technician hours/conflicts,
then bay conflicts and selection. New confirmations create one row; replays create none;
known rolled-back failures create none and uncertain commit is not evidence of rollback.

| Validation | Expected outcome |
|---|---|
| FR-001/002/008 input cases | Unknown entities/ownership/invalid times rejected, no rows |
| Qualification/bays | Only local qualified full-duration resources accepted |
| Half-open boundaries | Touching accepted; partial/full/contained overlaps rejected |
| Hours/missing windows | Outside or absent hours unavailable; exact boundaries accepted |
| DST/midnight | Named-zone evaluation; affected-boundary windows excluded, unaffected usable |
| Restart | Confirmation unchanged; overlapping bookings still blocked |
| Advisory race | Prior positive query does not permit conflicting confirmation |
| Concurrent independent booking | At least 100 healthy pairs per AS-008 resource variant; exactly one confirms and the other has a business conflict; any technical failure fails the run and is recorded |
| Concurrent same key | At most one row, successful responses share ID even with spare pairs |
| Replay retention | Restart, 24 hours later and after appointment end still replay |
| Known failed keyed request | No row/key consumed; same details can retry |
| Lost committed response | Same keyed retry resolves original confirmation |
| Busy/technical failures | Distinct code/correlation; no false resource-unavailability claim |
| Same key, different simultaneous payloads | One confirmed key binding; other payload mismatches, original booking unchanged |
| Negative lock results | -1/-2/-3/-999 abort before allocation; rollback/dispose and no consumed key |
| Slow/full telemetry queue | Booking does not wait for logging/export; drops measured |

## Independent Processes and Fault Scenarios

ProcessTests launch API instances on localhost:5081 and 5082 against the same disposable SQL DB,
with separate connection pools. Barrier-release simultaneous requests. Use fixtures with only
one technician, only one bay, and one of each. Inspect persisted intervals using the same
half-open overlap predicate and assert zero overlaps. Test separate dealerships and verify
lock names differ. No outer test transaction hides actual commits.
Healthy AS-008/SC-002 runs use valid requests, healthy database connectivity, sufficient request
budgets and no injected faults. Never filter technical failures out of acceptance results.
Separate fault/contention runs require zero overlaps/partial confirmations without guaranteeing
a successful response.

Hold an exclusive transaction-owned dealer app lock from another connection: booking waits at
most configured lock budget then returns 503 BOOKING_BUSY, without appointment or consumed key.
Release it and retry the same key/details: normal evaluation may confirm.
Inject known failure before SaveChanges and before commit: appointment and both assignments
remain absent. Drop acknowledgement after a real commit: verification or keyed retry returns
one durable row. If SQL remains unavailable, response is BOOKING_OUTCOME_UNKNOWN with no claim
of rollback. Cancellation disposes/rolls back before commit where possible; once commit starts,
its uncertain outcome must follow the same recovery rule. A process restart releases its old
transaction once SQL detects disconnect; surviving callers use bounded wait.

Use a test-only decorator of the Infrastructure lock/transaction adapter, registered in the
test host only. Before-save/before-commit hooks throw before the real commit; post-commit hook
calls the real SQL commit and then throws a simulated connectivity error before the coordinator
sees success. This exercises recovery logic and is not proof of actual wire-level failure.
Optional proxy/transport tests must be labeled separately. Inject negative app-lock results
and assert no allocation follows; real held-lock testing independently verifies actual timeout.
Test cancellation during lock wait and commit and repeat requests after lock release.
Response work stops at 10 seconds; rollback cleanup gets at most 1 additional second. SQL lock
release after connection loss is observed separately and may take longer. If connected, deadline
expiry returns REQUEST_TIMEOUT only with established no-write/rollback; uncertain commit returns
BOOKING_OUTCOME_UNKNOWN. No query/retry gets a new budget during cleanup.
Resource conflicts use TECHNICIAN_UNAVAILABLE or BAY_UNAVAILABLE; do not add a generic conflict
code without distinct observable semantics. Hold a telemetry sink indefinitely and fill its
bounded queue to verify drops, correlation propagation and no booking-critical-section blocking.

## Reproducible Performance Run

The load harness is implemented at scripts/performance/run-load.ps1, with isolated DB ownership,
two-process startup and fixed profiles. Actual SQL/performance evidence and remote metric collection
remain open; see docs/verification/performance.md:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/performance/run-load.ps1 -HistoryRows 100000
```

Three repetitions with reset isolated state; fixed request mix 60% availability, 25% retrieval,
15% create. Record machine/resources, SQL/SDK version, response count, throughput, p50/p95/p99,
per-outcome counts, lock wait/transaction durations, query reads and post-run integrity checks.
Targets in plan.md are proposals. Do not manufacture measurements or mistake fast failed
requests for passing success latency. Larger future-load profiles are exploratory, not a claim
of production capacity.

## Deployment and Evidence

Publish one application with `dotnet publish src/KeyLoopServiceScheduler.Api -c Release`.
Run the published DLL under a service manager with external configuration and persistent SQL;
one-time migrations/seed happen before serving. Future replicas point to the same authoritative
primary and lock namespace; LB/readiness/central telemetry are documented future evolution.
Retain test results, configuration without secrets, load records and known limitations. All
commands require their stated prerequisites; they are instructions, not proof of execution.
Actual commands and results are recorded in docs/verification/implementation-003.md.
