# Implementation Plan: Keyloop Unified Service Scheduler

**Branch**: `001-service-scheduler` (workflow-resolved feature name; Git checkout not verified)
**Date**: 2026-10-09 | **Spec**: [spec.md](spec.md)
**Input**: Approved specification and [planning input](../../docs/plan-input-001.md).

## Summary

Build one stateless ASP.NET Core application that confirms vehicle service appointments only
when a qualified local technician and local bay cover the full interval. SQL Server coordinates
booking writers with a transaction-owned dealership lock. An appointment stores both resource
assignments atomically. Dealership-scoped optional request keys provide durable replay.
Availability remains advisory. Foundation and availability/booking application code are now provided.
Pure application and fake-unit lifecycle tests have run; live SQL/concurrency checkpoints and
performance verification remain open. See [booking evidence](../../docs/verification/booking.md).
HTTP, health/OpenAPI, observability and demo artifacts are now implemented under input-003. SQL-backed
HTTP/process and performance checkpoints remain open. See docs/verification/implementation-003.md.

## Technical Context

**Language/Version**: C#, .NET 10 LTS, net10.0; updated input matches constitution.
**Primary Dependencies**: ASP.NET Core Web API controllers; EF Core 10 SQL Server provider;
Microsoft.Data.SqlClient; xUnit; Microsoft.AspNetCore.Mvc.Testing 10; built-in OpenAPI;
Serilog.AspNetCore 10; OpenTelemetry SDK, ASP.NET instrumentation and custom activities/meters.
Use compatible stable patches pinned during implementation, with package lock restore in CI.
**Storage**: SQL Server 2022 Developer locally; persistent database, EF migrations, seed fixtures.
**Testing**: Pure unit tests, HTTP/real-SQL integration tests, two-process contention and fault tests.
**Target Platform**: Windows or Linux .NET runtime; SQL Server via local instance or container.
**Project Type**: Backend web service, modular monolith, one deployable application.
**Performance Goals**: Proposed p95 availability 300 ms, create 500 ms, retrieve 150 ms at
representative MVP load; unproven targets, measured separately from contention stress.
**Constraints**: No partial confirmation, no shared-resource overlap, no instance-local booking
state; no frontend implementation, broker, microservices, authentication infrastructure, or Redis.
**Scale/Scope**: Three use cases; 14 functional requirements; assessment data and future workload
assumptions in the scalability section. Design capacity is not established by documentation.

## Constitution Check

Pre-research gate: PASS after confirming updated .NET 10 input. Post-design gate: PASS by design.
These are design-compliance conclusions, not runtime verification results.

| Principle | Design evidence |
|---|---|
| I Requirements-first | FR-001–FR-014 and AS-001–AS-032 mapped below; assumptions separated |
| II Architecture | .NET 10; four concern boundaries; one app; focused ports, no generic repository |
| III Domain correctness | Full duration, seeded hours, qualification, half-open overlap, atomic row |
| IV API | REST endpoints, validated DTOs, statuses, Problem Details and OpenAPI contract |
| V Integrity | FKs/checks/indexes, transaction-owned SQL coordination, independent-process tests |
| VI Verification | Unit/integration/fault/concurrency plan; truthful execution evidence |
| VII Observability | Structured records, correlation, booking and lock metrics, privacy filters |
| VIII AI engineering | Small reviewed increments; decision records and collaboration log planned |
| IX Assessment scope | Backend complete; documented requests/test demonstration, no extra infra |
| X Documentation | Research, data model, contracts, quickstart, System Design Document |

## Project Structure

### Documentation (this feature)

```text
specs/001-service-scheduler/
  spec.md
  plan.md
  research.md
  data-model.md
  quickstart.md
  contracts/api.md
  contracts/openapi.json
  checklists/requirements.md
  tasks.md                     # Later speckit-tasks output; not generated here
docs/system-design.md
```

### Source Code (repository root)

Planned paths, not files generated during planning:

```text
KeyLoopServiceScheduler.slnx
src/KeyLoopServiceScheduler.Api/
src/KeyLoopServiceScheduler.Application/
src/KeyLoopServiceScheduler.Domain/
src/KeyLoopServiceScheduler.Infrastructure/
tests/KeyLoopServiceScheduler.UnitTests/
tests/KeyLoopServiceScheduler.IntegrationTests/
tests/KeyLoopServiceScheduler.ProcessTests/
docs/requests.http
scripts/performance/             # Later repeatable load scenarios
README.md
```

**Structure Decision**: Four projects make dependency boundaries explicit. API references
Application and Infrastructure for composition; Application references Domain; Infrastructure
references Application/Domain; Domain has no web or persistence references. ProcessTests launch
built API binaries with separate processes and connections against one isolated SQL database.

## Complexity Tracking

No constitutional violations or exceptions. Four projects implement explicitly requested
boundaries. One lock per dealership and one appointment row avoid a general reservation engine.

## Architecture and Responsibilities

```mermaid
flowchart LR
    Caller[Booking caller] --> Api[API controllers and Problem Details]
    Api --> App[Application use cases and transaction orchestration]
    App --> Domain[Pure qualification, interval and schedule policies]
    App --> Ports[Focused persistence and transaction ports]
    Infra[Infrastructure EF Core and SQL lock adapter] -. implements .-> Ports
    Infra --> Sql[(SQL Server)]
    Api -. composition root .-> Infra
    Api --> Telemetry[Serilog and OpenTelemetry]
    App --> Telemetry
```

| Component | Responsibility |
|---|---|
| API | Parse DTOs/offsets/key headers, shape validation, status mapping, correlation, OpenAPI |
| Application | BookAppointment, GetAppointment, QueryAvailability; replay order, workflow outcomes |
| Domain | Service duration, qualified-resource eligibility, half-open overlap, schedule coverage |
| Infrastructure | EF mappings/queries/migrations, SQL lock acquisition, transaction implementation |
| Composition root | Register adapters, options, health checks, telemetry; no booking policy |

No mediator or generic repository required. Use IBookingStore for focused lookups/save,
IBookingTransaction for transaction/lock lifecycle, IAppointmentReader for projections,
and TimeProvider for clock tests. Application coordinates one transactional delegate;
Infrastructure creates one attempt-scoped unit containing the DbContext, transaction, lock
and all booking stores; every store uses that same context and connection. Application receives
only persistence ports, never DbContext, DbConnection or SQL transaction objects. A retry
disposes the complete failed unit before creating a fresh one; stores cannot outlive or be
reused across attempts. The coordinator owns the unit factory and supplies attempt-bound ports
to the application delegate. Pure schedule resolution is
behind a narrow zone resolver to test ambiguity/missing-zone behavior.

DI lifetimes: scoped use cases, store, transaction coordinator, DbContext; singleton immutable
policy services, TimeProvider.System, telemetry factories, validated options. No singleton
DbContext or scoped service captured by a singleton. Request-scoped orchestration uses an
Infrastructure attempt factory; one context/transaction/store set per attempt, including retry.

## Booking Sequence

```mermaid
sequenceDiagram
    participant C as Caller
    participant A as API
    participant U as Application
    participant D as Domain
    participant S as SQL Server
    C->>A: POST booking, optional Idempotency-Key
    A->>U: Parsed canonical request
    U->>S: Begin ReadCommitted, acquire exclusive dealer app lock
    alt Lock acquisition fails
        U->>S: Roll back/dispose
        U-->>A: Technical outcome
    else Lock granted
        U->>S: Find confirmed dealer/key
        alt Same key and details already confirmed
            U->>S: End transaction, release lock
            U-->>A: Original appointment
        else Key payload differs
            U->>S: Roll back
            U-->>A: Key mismatch
        else New attempt
            U->>S: Load references, ownership, duration and zone configuration
            U->>D: Validate references/configuration, derive interval and check future start
            U->>S: Load dealer hours, local qualifications and resource schedules/conflicts
            U->>D: Evaluate dealer hours, qualifications, technician then bay availability; select lowest IDs
            alt Invalid or no valid resource pair
                U->>S: Roll back, no key consumed
                U-->>A: Validation or business failure
            else Valid pair
                U->>S: Insert appointment with both assignments and key
                U->>S: Commit
                U-->>A: Confirmation or uncertain technical outcome
            end
        end
    end
    A-->>C: 201 new, 200 replay, or Problem Details
```

## Transactions, Concurrency, and Recovery

Use canonical `scheduler:dealership:<id>` with invariant decimal bigint formatting, one database,
DbPrincipal public, LockMode Exclusive, LockOwner Transaction, LockTimeout 2000 ms. Acquire
before reads in an explicit ReadCommitted transaction using the same open EF connection.
ReadCommitted avoids starting from a stale transaction snapshot after waiting for the lock.
Fetch the stored procedure return code through an output/return parameter; >=0 grants the lock.
-1 is lock wait expiry, -2 cancellation, -3 deadlock, -999 protocol/configuration failure.
Any negative result aborts allocation and requires rollback/disposal; never continue the write.
The SQL mechanism and return semantics are documented in [Microsoft's lock reference](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql?view=sql-server-ver17).

Validate request syntax/header format before starting the transaction. Within the lock:
resolve confirmed-key replay or mismatch first; validate references then ownership; validate
service duration and dealership zone configuration; derive the interval and check representability
and future start; evaluate dealer hours, local qualifications, technician hours/conflicts,
then bay conflicts and sorted candidate selection, in that order. Multi-failure cases MUST
assert this precedence as specified in spec.md §Booking Outcome Evaluation Order.
Insert exactly one Appointment with non-null TechnicianId and ServiceBayId, normalized request
fields, optional key, status Confirmed, and generated GUID. Commit before reporting success.
No external calls, telemetry exports, or slow work while holding the lock.

Correctness argument (design inference): all candidate resources belong to one dealership.
Only one participating writer can inspect and change its bookings at a time. Each sees committed
prior allocations before selecting a valid pair. Thus two independent writers cannot both
commit overlapping intervals for the same resource. Different dealership locks are disjoint;
other DB contention may still occur. No lock contains day/start-time in its name, because
cross-midnight and unequal-start overlapping appointments must coordinate together.

This is cooperative serialization, not an interval constraint. Every future writer, import,
schedule change, or resource reassignment must use the same protocol. The MVP serves immutable
seed data and has no runtime administrative writer. Runtime credentials exclude schema/admin
privileges; privileged ad hoc writes remain outside the correctness guarantee. Ordinary FKs
and uniqueness do not independently prohibit interval overlap.

Proposed budgets: request 10 seconds; SQL connection 3 seconds; command timeout 5 seconds;
application-lock wait 2 seconds. Enforce a linked cancellation/deadline across operations, not
an independent fresh budget per query. MARS disabled; SqlClient ConnectRetryCount=0 for booking.
Default EF automatic write execution retries disabled. At most one full retry with 100–250 ms
jitter after known rollback for a transient pre-commit failure/deadlock, if total budget permits.
Never retry a business failure, key mismatch, lock timeout, cancellation, or uncertain commit.
The 10-second budget is the response-work deadline, not a promise that provider disposal or
SQL disconnect detection finishes within 10 seconds. Commit verification uses only remaining
response budget. Rollback gets an independent maximum 1-second cleanup token after cancellation;
no new query or retry is permitted then. If the caller is still connected, return 503
REQUEST_TIMEOUT at deadline with not_committed only when rollback/no-write is established;
once commit has started and cannot be verified, return BOOKING_OUTCOME_UNKNOWN instead.
Client disconnect may prevent any response. Disposal runs after bounded rollback; unresolved
connections are closed and never reused by the booking attempt. SQL may release server locks
later when it detects disconnect; other callers still use their own finite lock wait.

Generate an operation GUID once per server request, reused for internal attempts. On a commit
connection error, dispose the old context and inspect that GUID on a fresh primary connection
once if deadline allows. If found, report original confirmation; if unresolved, report 503
BOOKING_OUTCOME_UNKNOWN, never claim rollback. Do not blindly insert again. Keyed client retry
under dealer lock finds the durable confirmation; unkeyed retries are independent requests.
[EF resiliency guidance](https://learn.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency)
explains why a commit exception does not establish the transaction outcome.

Known failure before commit rolls back the whole row/key. A key is retained only with a
confirmation; retry after failure with the same details is allowed. Confirmed replay happens
before future-start validation and returns the same UTC result even after the appointment ends.
A filtered unique dealer/key index protects duplicate keys as an additional integrity layer.
Requests with equivalent offset instants compare equal; duration/end/resources are server outputs.

## Data Access, API, and Indexing

See [data model](data-model.md), [API semantics](contracts/api.md), and
[OpenAPI](contracts/openapi.json). Three business endpoints plus health and development OpenAPI.
Numeric resource IDs sort ascending; appointment GUIDs are not resource-ranking identifiers.
Enforce CHECK (EndUtc = DATEADD(minute, DurationMinutes, StartUtc)) in the appointment mapping
and migration, in addition to positive interval/duration and UTC constraints. Direct-SQL tests
reject duration/end mismatches and overflow and accept valid 100 ns precision values.
Dated local windows are unioned after invalid/ambiguous boundaries are excluded, then compared
as UTC intervals. Whole elapsed-duration coverage is required across every relevant date.

Indexes: qualification (ServiceTypeId, TechnicianId), local hours (parent ID, LocalStart),
technician conflict (TechnicianId, StartUtc) INCLUDE EndUtc/Status, bay conflict
(ServiceBayId, StartUtc) INCLUDE EndUtc/Status; both filtered to Confirmed where appropriate.
Replay uses filtered unique (DealershipId, RequestKey); retrieval uses appointment GUID PK.
An overlap query uses StartUtc < requestedEnd AND EndUtc > requestedStart, with NOT EXISTS
for candidate resources. Project only needed fields and avoid per-candidate database queries.
Availability performs read-only committed queries; it may become stale and never reserves resources.

As history grows, StartUtc range seeks can scan historical rows before testing EndUtc. Inspect
actual plans/logical reads at 100k and 1m appointments. Evaluate an EndUtc-leading alternative
or bounded history archiving only after profiling. Archiving must preserve confirmed key replay
and include all interval conflicts; do not silently add a booking horizon to reduce scans.

## Observability

Serilog structured JSON console logs with operation, outcome, reasonCode, traceId,
correlationId, dealerId and elapsedMs. Do not log customer names, VINs, request bodies, raw
request keys, SQL parameters or connection secrets. Sensitive-data logging disabled.
Use a validated caller correlation ID (ASCII token <=64) or generate one; return it in every
response. W3C trace context remains distinct; include both IDs in log scope.

OpenTelemetry HTTP spans and custom booking, lock.wait, transaction, availability spans;
SQL instrumentation only if stable and sanitized, otherwise custom DB operation spans.
Use bounded nonblocking telemetry queues and batch export, including console output; never
invoke a sink/exporter synchronously while holding the dealership lock. Queue saturation drops
telemetry and increments a bounded drop counter instead of blocking booking. Record lock and
transaction timing in memory and emit after commit/rollback releases the lock. Optional OTLP
and exporter failures do not affect booking; flush is shutdown-only and bounded.

| Signal | Definition/use |
|---|---|
| booking.requests | One terminal count per logical HTTP booking request by outcome/reason; internal retries do not add requests |
| booking.attempts | One count per started transaction attempt, including retry; separate from HTTP requests |
| booking.confirmations | One per newly committed row, never replay; commit recovery reports that row once within its server operation |
| booking.conflicts | One per terminal logical request rejected for resource unavailability/conflict; rate denominator is terminal logical booking requests, not transaction attempts |
| booking.replays / key_mismatch | Retry traffic and misuse |
| http.server.duration | Latency by route template/status, not URL/identifier |
| booking.transaction.duration | Lock+DB critical-section duration histogram |
| booking.lock.wait.duration | Wait histogram, expose per-dealer contention in logs |
| booking.lock.failures | Counts by timeout/deadlock/cancel/call-error |
| availability.duration | Read path timing and saturation |
| telemetry.dropped | Bounded queue saturation; no identifier labels |

Booking success rate is (new-confirmation responses + successful replay responses) / terminal
logical booking requests. Resource conflict rate is terminal resource-conflict responses /
terminal logical booking requests; technical busy/deadlock/timeouts are excluded from its numerator.
The numerator includes resource-unavailability/conflict rejections once per terminal request;
database failures are also excluded. Internal retries increment attempts, not logical requests.
Transaction duration spans one attempt from begin through commit/rollback, including lock wait;
lock.wait is a separate histogram. Cancelled/disconnected requests count once with their outcome.
Counters are operational observations, not an exact durable audit: a crash can lose telemetry.

No keys, GUIDs, customer IDs or dealer IDs as metric labels; use logs for high-cardinality diagnosis.
Growing wait with short DB time signals hot dealer serialization; long DB time/reads suggests
query/history bottlenecks; connection waits suggest pool saturation. Review p95/p99 and error
ratios together so fast errors do not appear as successful performance.

## Scalability and Performance

All figures are design assumptions proposed for assessment planning, not Keyloop requirements
or demonstrated capacity. Eight-hour daily active workload and a mix of 60-minute services
are sizing assumptions, not changes to business operating hours.

| Dimension | MVP test profile | Hypothetical production planning profile |
|---|---|---|
| Dealerships | 5 | 200 |
| Technicians / dealership | 10 | 30 |
| Bays / dealership | 6 | 20 |
| Appointments / dealership / day | 40 | 120 |
| Total appointments / day | 200 | 24,000 |
| Peak simultaneous creates | 10 across dealers; 10 hot-dealer stress | 100 across dealers; 20 hot-dealer stress |
| Availability volume / day | 2,000; test 10/sec | 240,000; exploratory peak 200/sec |
| History profiles | 10k and 100k rows | Explore 1m rows before capacity claims |

Proposed MVP p95 objectives: availability <=300 ms, new booking <=500 ms, retrieval <=150 ms,
under the mixed profile with low collision rate. Lock-heavy stress has a separate bounded-failure
objective: stop response work at the 10-second deadline, no overlaps/duplicates, correctly
identified technical failures; bounded cleanup may continue separately as documented above.
Hypothetical production targets retain these p95 objectives but are aspirational until benchmarked.
Record network, queue and DB time; no acceptance target is reported as achieved in this plan.

Reproducible future performance harness: fixed seed/random seed, disclosed machine/SQL version,
Release build, 30 sec warmup and 120 sec measurement; three repetitions. Issue 10 concurrent
mixed callers (60% availability, 25% retrieval, 15% create), with both low-collision and single
hot-dealer runs. Repeat at 100k history and against two processes sharing SQL. Export count,
throughput, p50/p95/p99, outcome counts, lock waits, transaction times and SQL reads. Independently
assert zero overlaps and duplicates after each run. Reset isolated DB between runs. At heavier
hypothetical load report results without claiming the MVP supports it. No benchmark runs yet.

Bottlenecks: per-dealer write serialization, long overlap scans, connection-pool exhaustion,
SQL log flush/disk I/O, DB CPU and lock escalation, excessive observability volume. Single DB is
a shared write and failure domain. SQL Server app locks coordinate on one primary/database;
separate databases do not share them. Read replicas are unsuitable for authoritative booking
or request-key lookup. Shared storage/HA do not make arbitrary cross-database locks global.

Caching: initially none. Reference reads are small and immutable in MVP. If profiling justifies
caching dealer/service/qualification data, use bounded TTL/versioned eviction and invalidate
all instances on changes, or re-read authoritative references under the booking transaction.
Never confirm from cached availability. Redis/distributed invalidation infrastructure is deferred.

| Area | MVP | Future production evolution |
|---|---|---|
| Compute | One stateless API process | Multiple instances behind load balancer, TLS |
| Persistence | One persistent local SQL Server | Managed primary/HA SQL Server, backups/recovery drills |
| Connections | Bounded provider pool per process | Tune aggregate pools to DB capacity; no unlimited replicas |
| Health | /health/live and SQL /health/ready | LB readiness, centralized monitoring |
| Telemetry | Structured console, optional OTLP | Centralized logs/traces/metrics and alerts |
| Consistency | Same dealer lock on primary | Keep protocol on same DB; optimize only with new evidence |
| Security | Local assessment only | Identity/access policy, secrets management, least privilege |

Domain rules, HTTP contracts, and use cases remain. A different relational engine requires a
new transaction adapter with equivalent serialization, replay uniqueness, commit verification,
and independent-process tests. Per-resource locking needs deterministic acquisition order and
candidate rechecks; sharding must co-locate a dealership's resources and keys. Switching DBs
or adding API instances alone does not solve concurrency and may increase contention.
No speculative production infrastructure is implemented by this plan.

## Verification and Delivery Phases

Phase 0 complete: research.md records decisions, alternatives and official evidence.
Phase 1 complete: this plan, data-model.md, contracts, quickstart and System Design Document.
Implementation sequence (source artifacts now exist; SQL/process/performance evidence remains open):

1. Scaffold four projects and test projects, pin dependencies, create reproducible configuration.
2. Implement pure duration/interval/qualification/schedule policies and deterministic ordering.
3. Add EF schema/migrations/seeding, focused queries, lock transaction adapter and replay logic.
4. Expose three use cases, Problem Details, OpenAPI, health checks and observability.
5. Verify real-SQL HTTP journeys, independent-process concurrency, fault recovery, performance;
   finish README/request examples, decision and AI collaboration evidence.

| Coverage | Requirements and acceptance |
|---|---|
| Input, ownership, duration | FR-001, FR-002, FR-008; AS-001/009/011/017/021 |
| Qualification and bay selection | FR-003, FR-004, FR-006; AS-002/003/004/012/022/023 |
| Intervals and concurrent allocation | FR-005, FR-006, FR-007; AS-005/006/008/016 |
| Retrieval/durability | FR-009; AS-007/010/013 |
| Provisional query | FR-010; AS-014/015/016/017 |
| Hours, zones, DST | FR-011, FR-012; AS-018/019/020/024 |
| Keys and retries | FR-013; AS-025/026/027/028/029/030/031 |
| Failure outcomes | FR-014; AS-030/031/032 |

Unit: overlap boundaries/containment, fixed elapsed duration, invalid start and ownership,
qualifications, numeric ordering, schedules/union/missing hours, midnight/DST, canonical replay
comparison. Integration: all AS cases through HTTP with isolated real SQL, schema checks,
filtered key uniqueness, exact statuses, UTC response serialization, privacy and trace checks.
Process: at least 100 pairs per shared-resource AS-008 variant across two API processes,
plus AS-026 with multiple free pairs and same key. No test wraps the whole run in a parent
transaction that conceals true commits. Use barriers, independent connections and clean state.
AS-008/SC-002 runs use valid requests, healthy connectivity, sufficient budgets and no injected
faults. A technical failure fails that acceptance run and is recorded, never filtered out.
Separate fault/contention runs assert zero overlaps/partial confirmations without promising
a successful response. New bookings create one row; replay creates none, under SC-001.

Fault: hold dealership lock to trigger finite timeout; fail before save and before commit;
simulate dropped commit acknowledgement; restart a process; verify no partial rows, release
of locks and replay. Exercise cancellation before commit and after commit begins; verify no
false rollback assertion. Different dealership attempts must not wait on the same app-lock
resource; incidental DB contention is measured separately. Passing evidence is required before
claiming concurrency safety. Document failures/unexecuted checks; do not delete failing tests.

Add a test-only Infrastructure transaction/lock adapter decorator, registered only by the test
host: inject before-save and before-commit faults; for acknowledgement loss, perform the real
SQL commit and then throw a simulated connectivity error before returning to the coordinator.
This validates recovery logic, not network transport fidelity; optional transport fault testing
is separately labeled. Inject -1/-2/-3/-999 lock outcomes without allowing allocation, and verify
the acquired transaction rolls back/disposes. Also run a real held-lock timeout test.
Verify all stores share the attempt connection/transaction and a retry uses a different context.
Add concurrent same-key/different-payload tests (one confirmed binding, other mismatch), direct
SQL null rejection for required columns, malformed/overflow/overprecision timestamp cases,
cancellation during lock wait and commit, correlation/header consistency, and a stalled
telemetry sink with a full queue. Existing bookings must remain unchanged and known failures
must leave no appointment/reservation/key; server lock release is observed separately from response.

## Deployment, Assumptions, and Risks

Local instructions and future commands are in quickstart.md. Implement one-time EF migrations
and seeding before serving, never competing startup migrations on multiple replicas. Keep
connection strings in environment/user secrets. Do not use SQL Developer licensing for production.
MVP reference data is immutable while serving. No runtime/SQL tooling has been installed by planning.

Main risks: cooperative locks can be bypassed, same-dealer throughput is serialized, named-zone
availability differs across OS deployments unless validated, dated seeds need future coverage,
unknown commit can remain unresolved during DB outage, unkeyed external retries may duplicate,
unauthenticated caller-key collisions are possible within a dealer. Authentication and stronger
client identity are production requirements, outside assessment. Tests and documentation must
make these limitations visible. SDK/package pinning, migrations, benchmarks and deployment are
future implementation work, not missing business decisions.
