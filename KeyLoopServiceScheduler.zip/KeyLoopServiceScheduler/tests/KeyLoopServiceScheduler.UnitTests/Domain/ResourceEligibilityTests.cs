using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Domain;

public sealed class ResourceEligibilityTests
{
    private static readonly DateTime StartLocal = new(2030, 1, 7, 9, 0, 0);
    private static readonly AppointmentInterval Interval = new(new DateTimeOffset(StartLocal, TimeSpan.Zero), new DateTimeOffset(StartLocal.AddHours(1), TimeSpan.Zero));
    private static readonly LocalWindow[] Hours = [new(StartLocal, StartLocal.AddHours(8))];
    private static TechnicianCandidate Tech(long id, long dealer = 1, bool qualified = true, bool busy = false, bool hours = true) =>
        new(id, dealer, qualified ? new HashSet<long> { 1 } : new HashSet<long>(), hours ? Hours : [], busy ? [Interval] : []);
    private static BayCandidate Bay(long id, long dealer = 1, bool busy = false) => new(id, dealer, busy ? [Interval] : []);
    private static EligibilitySelection Select(TechnicianCandidate[] techs, BayCandidate[] bays, LocalWindow[]? hours = null) =>
        EligibilityEvaluator.Select(1, 1, Interval, TimeZoneInfo.Utc, hours ?? Hours, techs, bays);

    [Fact]
    public void LowestNumericEligibleIdsWinRegardlessOfInputOrder()
    {
        var result = Select([Tech(10), Tech(2), Tech(1, qualified: false), Tech(3, busy: true)], [Bay(10), Bay(2), Bay(1, busy: true)]);
        Assert.Equal(EligibilityReason.Available, result.Reason);
        Assert.Equal(2, result.TechnicianId);
        Assert.Equal(2, result.ServiceBayId);
    }

    [Fact]
    public void OtherDealerAndUnqualifiedResourcesCannotSatisfyBooking()
    {
        Assert.Equal(EligibilityReason.NoQualifiedTechnician, Select([Tech(1, dealer: 2), Tech(2, qualified: false)], [Bay(1)]).Reason);
        Assert.Equal(EligibilityReason.BayUnavailable, Select([Tech(1)], [Bay(1, dealer: 2)]).Reason);
    }

    [Fact]
    public void ConflictingLowestCandidateDoesNotHideAlternativePair()
    {
        var result = Select([Tech(1, busy: true), Tech(2)], [Bay(1, busy: true), Bay(2)]);
        Assert.Equal((2L, 2L), (result.TechnicianId, result.ServiceBayId));
    }

    [Fact]
    public void AllEligibilityFailureClassesAreDistinguishable()
    {
        Assert.Equal(EligibilityReason.DealershipClosed, Select([Tech(1)], [Bay(1)], []).Reason);
        Assert.Equal(EligibilityReason.NoQualifiedTechnician, Select([], [Bay(1)]).Reason);
        Assert.Equal(EligibilityReason.TechnicianUnavailable, Select([Tech(1, hours: false)], [Bay(1)]).Reason);
        Assert.Equal(EligibilityReason.TechnicianUnavailable, Select([Tech(1, busy: true)], [Bay(1)]).Reason);
        Assert.Equal(EligibilityReason.BayUnavailable, Select([Tech(1)], []).Reason);
        Assert.Equal(EligibilityReason.BayUnavailable, Select([Tech(1)], [Bay(1, busy: true)]).Reason);
    }

    [Fact]
    public void DealerHoursPrecedeQualificationAndTechFailuresPrecedeBayFailures()
    {
        Assert.Equal(EligibilityReason.DealershipClosed, Select([], [], []).Reason);
        Assert.Equal(EligibilityReason.NoQualifiedTechnician, Select([], []).Reason);
        Assert.Equal(EligibilityReason.TechnicianUnavailable, Select([Tech(1, busy: true)], []).Reason);
    }

    [Fact]
    public void BaysHaveNoServiceCapabilityFilter() =>
        Assert.Equal(EligibilityReason.Available, Select([Tech(1)], [Bay(1)]).Reason);
}
