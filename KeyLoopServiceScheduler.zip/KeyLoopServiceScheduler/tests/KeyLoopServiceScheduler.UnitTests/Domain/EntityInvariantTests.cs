using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;

namespace KeyLoopServiceScheduler.UnitTests.Domain;

public sealed class EntityInvariantTests
{
    private static readonly DateTimeOffset Start = new(2030, 1, 7, 9, 0, 0, TimeSpan.FromHours(5.5));

    [Fact]
    public void ConfirmationSnapshotsBothResourcesAndElapsedDuration()
    {
        var id = Guid.NewGuid();
        var row = new Appointment(id, 1, 1, 1, 1, 2, 3, Start.AddTicks(1), 60, Start.AddDays(-1), "Case-Sensitive!");
        Assert.Equal(id, row.Id);
        Assert.Equal(2, row.TechnicianId);
        Assert.Equal(3, row.ServiceBayId);
        Assert.Equal("Confirmed", row.Status);
        Assert.Equal(row.StartUtc.AddMinutes(60), row.EndUtc);
        Assert.Equal(TimeSpan.Zero, row.StartUtc.Offset);
        Assert.Equal(TimeSpan.Zero, row.CreatedUtc.Offset);
        Assert.Equal(1, row.StartUtc.Ticks % TimeSpan.TicksPerSecond);
    }

    [Theory]
    [InlineData("")]
    [InlineData("a b")]
    [InlineData("a\n")]
    [InlineData("é")]
    public void InvalidPresentKeysAreRejected(string key) =>
        Assert.Throws<ArgumentException>(() => new Appointment(Guid.NewGuid(), 1, 1, 1, 1, 1, 1, Start, 60, Start, key));

    [Fact]
    public void KeyLengthsAndAbsentKeyHaveExplicitBoundaries()
    {
        Assert.Null(new Appointment(Guid.NewGuid(), 1, 1, 1, 1, 1, 1, Start, 60, Start).RequestKey);
        Assert.Equal(128, new Appointment(Guid.NewGuid(), 1, 1, 1, 1, 1, 1, Start, 60, Start, new string('!', 128)).RequestKey!.Length);
        Assert.Throws<ArgumentException>(() => new Appointment(Guid.NewGuid(), 1, 1, 1, 1, 1, 1, Start, 60, Start, new string('!', 129)));
    }

    [Fact]
    public void InvalidIdsAndDurationsCannotConstructReferenceEntities()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new Customer(0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new Vehicle(1, 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new Technician(1, 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new TechnicianQualification(0, 1));
        Assert.Throws<ArgumentOutOfRangeException>(() => new ServiceBay(1, 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new ServiceType(1, "service", 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new Appointment(Guid.NewGuid(), 1, 1, 1, 1, 0, 1, Start, 60, Start));
    }

    [Fact]
    public void TextAndScheduleConstraintsAreEnforced()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new Customer(1, new string('a', 201)));
        Assert.Throws<ArgumentException>(() => new Dealership(1, "", "Asia/Kolkata"));
        Assert.Throws<InvalidReferenceConfigurationException>(() => new Dealership(1, "dealer", "Missing/Zone"));
        var local = new DateTime(2030, 1, 7, 9, 0, 0);
        Assert.Throws<ArgumentException>(() => new DealershipOperatingWindow(1, 1, local, local));
        Assert.Throws<ArgumentException>(() => new TechnicianWorkingWindow(1, 1, DateTime.SpecifyKind(local, DateTimeKind.Utc), local.AddHours(1)));
    }
}
