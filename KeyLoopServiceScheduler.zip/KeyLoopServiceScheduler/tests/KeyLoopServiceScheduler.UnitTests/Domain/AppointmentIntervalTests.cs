using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Domain;

public sealed class AppointmentIntervalTests
{
    private static readonly DateTimeOffset Start = new(2030, 1, 7, 10, 0, 0, TimeSpan.Zero);

    [Theory]
    [InlineData(-60, 0, false)]
    [InlineData(60, 120, false)]
    [InlineData(-30, 30, true)]
    [InlineData(30, 90, true)]
    [InlineData(15, 45, true)]
    [InlineData(-30, 90, true)]
    [InlineData(0, 60, true)]
    public void HalfOpenOverlapIsSymmetric(int from, int to, bool expected)
    {
        var existing = new AppointmentInterval(Start, Start.AddMinutes(60));
        var requested = new AppointmentInterval(Start.AddMinutes(from), Start.AddMinutes(to));
        Assert.Equal(expected, existing.Overlaps(requested));
        Assert.Equal(expected, requested.Overlaps(existing));
    }

    [Fact]
    public void OneTickOverlapIsNotTruncated()
    {
        var interval = new AppointmentInterval(Start, Start.AddHours(1));
        Assert.True(interval.Overlaps(new AppointmentInterval(Start.AddHours(1).AddTicks(-1), Start.AddHours(2))));
    }

    [Fact]
    public void EquivalentOffsetsNormalizeToUtc()
    {
        var interval = new AppointmentInterval(Start.ToOffset(TimeSpan.FromHours(5.5)), Start.AddHours(1).ToOffset(TimeSpan.FromHours(-4)));
        Assert.Equal(Start, interval.StartUtc);
        Assert.Equal(TimeSpan.Zero, interval.StartUtc.Offset);
        Assert.Equal(TimeSpan.Zero, interval.EndUtc.Offset);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void EmptyOrNegativeIntervalIsRejected(int minutes) =>
        Assert.Throws<ArgumentException>(() => new AppointmentInterval(Start, Start.AddMinutes(minutes)));
}
