using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Domain;

public sealed class ScheduleCoverageTests
{
    private static DateTime Local(int hour, int minute = 0) => new(2030, 1, 7, hour, minute, 0, DateTimeKind.Unspecified);
    private static AppointmentInterval Utc(int from, int to) => new(new DateTimeOffset(Local(from), TimeSpan.Zero), new DateTimeOffset(Local(to), TimeSpan.Zero));

    [Fact]
    public void TouchingAndOverlappingWindowsAreUnioned()
    {
        LocalWindow[] windows = [new(Local(9), Local(11)), new(Local(10), Local(12)), new(Local(12), Local(17))];
        Assert.True(ScheduleCoverage.Covers(Utc(9, 17), windows, TimeZoneInfo.Utc));
        Assert.Single(ScheduleCoverage.ResolveAndMerge(windows, TimeZoneInfo.Utc));
    }

    [Fact]
    public void GapAndMissingHoursFailClosed()
    {
        LocalWindow[] windows = [new(Local(9), Local(12)), new(Local(13), Local(17))];
        Assert.False(ScheduleCoverage.Covers(Utc(11, 14), windows, TimeZoneInfo.Utc));
        Assert.False(ScheduleCoverage.Covers(Utc(9, 10), [], TimeZoneInfo.Utc));
    }

    [Fact]
    public void ExactScheduleBoundariesAreIncludedButPartialCoverageFails()
    {
        LocalWindow[] windows = [new(Local(9), Local(17))];
        Assert.True(ScheduleCoverage.Covers(Utc(9, 17), windows, TimeZoneInfo.Utc));
        Assert.False(ScheduleCoverage.Covers(Utc(8, 10), windows, TimeZoneInfo.Utc));
        Assert.False(ScheduleCoverage.Covers(Utc(16, 18), windows, TimeZoneInfo.Utc));
    }

    [Fact]
    public void CrossMidnightWindowRetainsItsEarlierStart()
    {
        var start = new DateTime(2030, 1, 7, 22, 0, 0);
        var end = start.AddHours(8);
        Assert.True(ScheduleCoverage.Covers(new(new DateTimeOffset(start, TimeSpan.Zero), new DateTimeOffset(end, TimeSpan.Zero)),
            [new(start, end)], TimeZoneInfo.Utc));
    }

    [Theory]
    [InlineData(2030, 3, 10, 2)]
    [InlineData(2030, 11, 3, 1)]
    public void InvalidOrRepeatedBoundaryExcludesOnlyThatWindow(int year, int month, int day, int hour)
    {
        var zone = new TimeZoneResolver().Resolve("America/New_York");
        var bad = new DateTime(year, month, day, hour, 30, 0);
        var validStart = new DateTime(year, month, day, 9, 0, 0);
        var validEnd = validStart.AddHours(2);
        LocalWindow valid = new(validStart, validEnd);
        var interval = new AppointmentInterval(TimeZoneInfo.ConvertTimeToUtc(validStart, zone), TimeZoneInfo.ConvertTimeToUtc(validEnd, zone));
        Assert.True(ScheduleCoverage.Covers(interval, [new(bad, bad.AddHours(3)), valid], zone));
        Assert.False(ScheduleCoverage.Covers(interval, [new(bad, bad.AddHours(3))], zone));
        Assert.Single(ScheduleCoverage.ResolveAndMerge([new(bad, bad.AddHours(3)), valid], zone));
        // Exercise the invalid boundary as an end as well as a start.
        Assert.Empty(ScheduleCoverage.ResolveAndMerge([new(bad.AddHours(-1), bad)], zone));
    }

    [Fact]
    public void TransitionInsideUnambiguousWindowIsAllowed()
    {
        var zone = new TimeZoneResolver().Resolve("America/New_York");
        LocalWindow window = new(new DateTime(2030, 3, 10, 0, 0, 0), new DateTime(2030, 3, 10, 4, 0, 0));
        var start = new DateTimeOffset(2030, 3, 10, 1, 30, 0, TimeSpan.FromHours(-5));
        Assert.True(ScheduleCoverage.Covers(new(start, new ServiceDuration(60).DeriveEnd(start)), [window], zone));
    }

    [Theory]
    [InlineData(1, -5)]
    [InlineData(7, -4)]
    public void NamedZoneFollowsSeasonalOffsets(int month, int offsetHours)
    {
        var zone = new TimeZoneResolver().Resolve("America/New_York");
        LocalWindow window = new(new DateTime(2030, month, 7, 9, 0, 0), new DateTime(2030, month, 7, 10, 0, 0));
        var start = new DateTimeOffset(2030, month, 7, 9, 0, 0, TimeSpan.FromHours(offsetHours));
        Assert.True(ScheduleCoverage.Covers(new(start.ToOffset(TimeSpan.FromHours(5.5)), start.AddHours(1)), [window], zone));
    }

    [Fact]
    public void UnknownZoneDoesNotFallBackToUtc() =>
        Assert.Throws<InvalidReferenceConfigurationException>(() => new TimeZoneResolver().Resolve("Missing/Zone"));
}
