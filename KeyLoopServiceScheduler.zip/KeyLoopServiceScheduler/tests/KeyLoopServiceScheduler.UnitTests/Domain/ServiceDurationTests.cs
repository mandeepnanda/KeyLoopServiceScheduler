using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Domain;

public sealed class ServiceDurationTests
{
    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void NonPositiveDurationIsRejected(int minutes) =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new ServiceDuration(minutes));

    [Fact]
    public void EndIsElapsedDurationWithoutBufferAndPreservesTicks()
    {
        var start = new DateTimeOffset(2030, 3, 10, 1, 30, 0, TimeSpan.FromHours(-5)).AddTicks(1);
        var end = new ServiceDuration(60).DeriveEnd(start);
        Assert.Equal(start.ToUniversalTime().AddMinutes(60), end);
        Assert.Equal(TimeSpan.Zero, end.Offset);
        Assert.Equal(1, end.Ticks % TimeSpan.TicksPerSecond);
    }

    [Fact]
    public void UnrepresentableEndIsRejectedBeforeArithmetic() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new ServiceDuration(1).DeriveEnd(DateTimeOffset.MaxValue));

    [Fact]
    public void LargePositiveMinutesDoNotOverflowTickArithmetic()
    {
        var start = DateTimeOffset.MinValue;
        Assert.Equal(start.AddMinutes(int.MaxValue), new ServiceDuration(int.MaxValue).DeriveEnd(start));
    }
}
