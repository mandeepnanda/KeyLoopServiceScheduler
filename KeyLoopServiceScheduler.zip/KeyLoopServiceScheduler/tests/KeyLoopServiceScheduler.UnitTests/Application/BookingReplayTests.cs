using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.UnitTests.Application;

public sealed class BookingReplayTests
{
    [Fact]
    public async Task ReplayNormalizesOffsetAndBypassesExpiredTimeReferencesAndResourceReads()
    {
        var f = new SchedulingFixture();
        var request = BookAppointmentTests.Request();
        var first = await BookAppointmentTests.Service(f).ExecuteAsync(request);
        f.Clock.Now = request.StartTime.AddDays(2);
        f.Customer = null; f.Service = null; f.Dealer = null; f.RejectResourceRead = true;
        var replay = await BookAppointmentTests.Service(f).ExecuteAsync(request with { StartTime = request.StartTime.ToOffset(TimeSpan.FromHours(5.5)) });
        Assert.True(replay.IsReplay);
        Assert.Equal(first.Appointment, replay.Appointment);
        Assert.Single(f.Rows);
    }

    [Theory]
    [InlineData("customer")]
    [InlineData("vehicle")]
    [InlineData("service")]
    [InlineData("tick")]
    public async Task ConfirmedKeyRejectsEveryChangedPayloadField(string field)
    {
        var f = new SchedulingFixture();
        var request = BookAppointmentTests.Request();
        await BookAppointmentTests.Service(f).ExecuteAsync(request);
        var changed = field switch
        {
            "customer" => request with { CustomerId = 2 },
            "vehicle" => request with { VehicleId = 2 },
            "service" => request with { ServiceTypeId = 2 },
            _ => request with { StartTime = request.StartTime.AddTicks(1) }
        };
        Assert.Equal(FailureCode.KEY_PAYLOAD_MISMATCH, (await BookAppointmentTests.Service(f).ExecuteAsync(changed)).Failure!.Code);
        Assert.Single(f.Rows);
    }

    [Fact]
    public async Task CaseSensitiveKeysUnkeyedRequestsAndFailedKeysAreIndependent()
    {
        var f = new SchedulingFixture();
        var service = BookAppointmentTests.Service(f);
        var request = BookAppointmentTests.Request();
        f.Snapshot = f.Snapshot with { Bays = [] };
        Assert.Equal(FailureCode.BAY_UNAVAILABLE, (await service.ExecuteAsync(request)).Failure!.Code);
        Assert.Empty(f.Rows);
        f.Snapshot = SchedulingFixture.Resources();
        Assert.Null((await service.ExecuteAsync(request with { StartTime = request.StartTime.AddMinutes(60) })).Failure);
        Assert.False((await service.ExecuteAsync(request with { RequestKey = "TEST-KEY" })).IsReplay);
        await service.ExecuteAsync(request with { RequestKey = null });
        await service.ExecuteAsync(request with { RequestKey = null });
        Assert.Equal(4, f.Rows.Count);
    }
}
