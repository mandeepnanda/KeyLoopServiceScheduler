using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Application;

public sealed class QueryAvailabilityTests
{
    [Theory]
    [InlineData("AVAILABLE")]
    [InlineData("DEALERSHIP_CLOSED")]
    [InlineData("NO_QUALIFIED_TECHNICIAN")]
    [InlineData("TECHNICIAN_UNAVAILABLE")]
    [InlineData("BAY_UNAVAILABLE")]
    public async Task ReportsFullIntervalReasonAndNoticeWithoutReservations(string expected)
    {
        var fixture = new SchedulingFixture();
        var original = fixture.Snapshot;
        fixture.Snapshot = expected switch
        {
            "DEALERSHIP_CLOSED" => original with { DealerWindows = [] },
            "NO_QUALIFIED_TECHNICIAN" => original with { Technicians = [] },
            "TECHNICIAN_UNAVAILABLE" => original with { Technicians = original.Technicians.Select(x => x with { Bookings = [new AppointmentInterval(SchedulingFixture.Start, SchedulingFixture.Start.AddMinutes(60))] }).ToArray() },
            "BAY_UNAVAILABLE" => original with { Bays = [] },
            _ => original
        };
        var result = await new QueryAvailability(fixture, fixture.Clock, new TimeZoneResolver())
            .ExecuteAsync(new(1, 1, SchedulingFixture.Start.ToOffset(TimeSpan.FromHours(5.5))));
        Assert.Null(result.Failure);
        Assert.NotNull(result.Details);
        Assert.Equal(expected, result.Details.ReasonCode);
        Assert.Equal(expected == "AVAILABLE", result.Details.Available);
        Assert.Equal(SchedulingFixture.Start, result.Details.StartTime);
        Assert.Equal(SchedulingFixture.Start.AddMinutes(60), result.Details.EndTime);
        Assert.Equal("Availability is provisional until booking confirmation succeeds.", result.Details.Notice);
        Assert.Empty(fixture.Rows);
        Assert.Equal(0, fixture.Transactions);
    }

    [Theory]
    [InlineData("dealer", FailureCode.UNKNOWN_DEALERSHIP)]
    [InlineData("service", FailureCode.UNKNOWN_SERVICE_TYPE)]
    [InlineData("past", FailureCode.INVALID_START_TIME)]
    [InlineData("overflow", FailureCode.INVALID_START_TIME)]
    [InlineData("zone", FailureCode.INVALID_REFERENCE_CONFIGURATION)]
    public async Task ValidationPrecedesResourceReads(string invalid, FailureCode expected)
    {
        var fixture = new SchedulingFixture();
        if (invalid == "dealer") fixture.Dealer = null;
        if (invalid == "service") fixture.Service = null;
        var start = invalid == "past" ? fixture.Clock.Now : invalid == "overflow" ? DateTimeOffset.MaxValue : SchedulingFixture.Start;
        var zones = invalid == "zone" ? (IZoneResolver)new InvalidZoneResolver() : new TimeZoneResolver();
        var result = await new QueryAvailability(fixture, fixture.Clock, zones).ExecuteAsync(new(1, 1, start));
        Assert.Equal(expected, result.Failure!.Code);
        Assert.Equal(0, fixture.ResourceReads);
    }

    private sealed class InvalidZoneResolver : IZoneResolver
    {
        public TimeZoneInfo Resolve(string zoneId) => throw new InvalidReferenceConfigurationException("Invalid test zone");
    }

    [Fact]
    public async Task FullIntervalRejectsDealerAndTechnicianGapsInOrder()
    {
        var f = new SchedulingFixture();
        LocalWindow[] gaps = [new(new(2030, 1, 7, 9, 0, 0), new(2030, 1, 7, 12, 0, 0)), new(new(2030, 1, 7, 13, 0, 0), new(2030, 1, 7, 17, 0, 0))];
        var start = new DateTimeOffset(2030, 1, 7, 6, 0, 0, TimeSpan.Zero); // Local 11:30–12:30.
        f.Snapshot = f.Snapshot with { Technicians = f.Snapshot.Technicians.Select(x => x with { WorkingWindows = gaps }).ToArray() };
        var service = new QueryAvailability(f, f.Clock, new TimeZoneResolver());
        Assert.Equal("TECHNICIAN_UNAVAILABLE", (await service.ExecuteAsync(new(1, 1, start))).Details!.ReasonCode);
        f.Snapshot = f.Snapshot with { DealerWindows = gaps };
        Assert.Equal("DEALERSHIP_CLOSED", (await service.ExecuteAsync(new(1, 1, start))).Details!.ReasonCode);
        Assert.Empty(f.Rows);
    }
}
