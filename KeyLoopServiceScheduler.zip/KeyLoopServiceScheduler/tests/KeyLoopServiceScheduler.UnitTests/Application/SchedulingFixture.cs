using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Application;

internal sealed class SchedulingFixture : IAvailabilityReader, IBookingStore, IBookingTransaction, IBookingAttempt
{
    public static DateTimeOffset Start => new(2030, 1, 7, 4, 30, 0, TimeSpan.Zero);
    public TestClock Clock { get; } = new();
    public Customer? Customer { get; set; } = new(1, null);
    public Vehicle? Vehicle { get; set; } = new(1, 1, null);
    public Dealership? Dealer { get; set; } = new(1, "Test", "Asia/Kolkata");
    public ServiceType? Service { get; set; } = new(1, "Service", 60);
    public ResourceSnapshot Snapshot { get; set; } = Resources();
    public List<Appointment> Rows { get; } = [];
    public Guid OperationId { get; private set; }
    public IBookingStore Store => this;
    public int Transactions { get; private set; }
    public int ResourceReads { get; private set; }
    public bool RejectResourceRead { get; set; }

    public static ResourceSnapshot Resources()
    {
        LocalWindow[] windows = [new(new(2030, 1, 7, 9, 0, 0), new(2030, 1, 7, 17, 0, 0))];
        return new(windows,
            [new(10, 1, new HashSet<long> { 1 }, windows, []), new(2, 1, new HashSet<long> { 1 }, windows, [])],
            [new(10, 1, []), new(2, 1, [])]);
    }

    public Task<AvailabilityReferences> ReadReferencesAsync(long dealershipId, long serviceTypeId, CancellationToken cancellationToken = default) =>
        Task.FromResult(new AvailabilityReferences(Dealer, Service));
    public Task<BookingReferences> ReadReferencesAsync(long customerId, long vehicleId, long dealershipId, long serviceTypeId, CancellationToken cancellationToken) =>
        Task.FromResult(new BookingReferences(Customer, Vehicle, Dealer, Service));
    public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken = default)
    {
        ResourceReads++;
        if (RejectResourceRead) throw new InvalidOperationException("Replay must bypass eligibility reads.");
        return Task.FromResult(Snapshot);
    }
    public Task<AppointmentProjection?> FindConfirmedAsync(long dealershipId, string requestKey, CancellationToken cancellationToken) =>
        Task.FromResult(Rows.Where(x => x.DealershipId == dealershipId && x.RequestKey == requestKey).Select(AppointmentProjection.From).SingleOrDefault());
    public Task AddAsync(Appointment appointment, CancellationToken cancellationToken) { Rows.Add(appointment); return Task.CompletedTask; }
    public async Task<TResult> ExecuteAsync<TResult>(long dealershipId, Guid operationId,
        Func<IBookingAttempt, CancellationToken, Task<TResult>> work, CancellationToken cancellationToken)
    {
        Transactions++;
        OperationId = operationId;
        return await work(this, cancellationToken);
    }
}

internal sealed class TestClock : TimeProvider
{
    public DateTimeOffset Now { get; set; } = new(2030, 1, 6, 0, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
}
