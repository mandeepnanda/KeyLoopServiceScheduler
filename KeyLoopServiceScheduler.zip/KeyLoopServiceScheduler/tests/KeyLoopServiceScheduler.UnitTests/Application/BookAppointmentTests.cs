using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.UnitTests.Application;

public sealed class BookAppointmentTests
{
    [Fact]
    public async Task SuccessHasBothLowestNumericAssignmentsAndDerivedDuration()
    {
        var f = new SchedulingFixture();
        var result = await Service(f).ExecuteAsync(Request());
        Assert.Null(result.Failure);
        var row = Assert.Single(f.Rows);
        Assert.Equal((2L, 2L), (row.TechnicianId, row.ServiceBayId));
        Assert.Equal(row.StartUtc.AddMinutes(60), row.EndUtc);
        Assert.Equal("Confirmed", row.Status);
        Assert.Equal(f.OperationId, result.Appointment!.Id);
    }

    [Theory]
    [InlineData("customer", FailureCode.UNKNOWN_CUSTOMER)]
    [InlineData("vehicle", FailureCode.UNKNOWN_VEHICLE)]
    [InlineData("dealer", FailureCode.UNKNOWN_DEALERSHIP)]
    [InlineData("service", FailureCode.UNKNOWN_SERVICE_TYPE)]
    [InlineData("ownership", FailureCode.VEHICLE_CUSTOMER_MISMATCH)]
    [InlineData("hours", FailureCode.DEALERSHIP_CLOSED)]
    [InlineData("qualification", FailureCode.NO_QUALIFIED_TECHNICIAN)]
    [InlineData("technician", FailureCode.TECHNICIAN_UNAVAILABLE)]
    [InlineData("bay", FailureCode.BAY_UNAVAILABLE)]
    [InlineData("past", FailureCode.INVALID_START_TIME)]
    [InlineData("overflow", FailureCode.INVALID_START_TIME)]
    public async Task RejectionsLeaveNoRowsOrKeys(string scenario, FailureCode expected)
    {
        var f = new SchedulingFixture();
        if (scenario == "customer") f.Customer = null;
        if (scenario == "vehicle") f.Vehicle = null;
        if (scenario == "dealer") f.Dealer = null;
        if (scenario == "service") f.Service = null;
        if (scenario == "ownership") f.Vehicle = new(1, 2, null);
        f.Snapshot = scenario switch
        {
            "hours" => f.Snapshot with { DealerWindows = [], Technicians = [], Bays = [] },
            "qualification" => f.Snapshot with { Technicians = [], Bays = [] },
            "technician" => f.Snapshot with { Technicians = f.Snapshot.Technicians.Select(x => x with { WorkingWindows = [] }).ToArray(), Bays = [] },
            "bay" => f.Snapshot with { Bays = [] },
            _ => f.Snapshot
        };
        var request = Request() with { StartTime = scenario == "past" ? f.Clock.Now : scenario == "overflow" ? DateTimeOffset.MaxValue : SchedulingFixture.Start };
        var result = await Service(f).ExecuteAsync(request);
        Assert.Equal(expected, result.Failure!.Code);
        Assert.Empty(f.Rows);
    }

    [Theory]
    [InlineData(0, true, false)]
    [InlineData(60, false, false)]
    [InlineData(-60, false, false)]
    [InlineData(30, true, false)]
    [InlineData(0, true, true)]
    [InlineData(60, false, true)]
    [InlineData(-60, false, true)]
    [InlineData(30, true, true)]
    public async Task OverlapRejectsButAdjacencyIsAllowed(int deltaMinutes, bool conflict, bool bay)
    {
        var f = new SchedulingFixture();
        var busy = new AppointmentInterval(SchedulingFixture.Start.AddMinutes(deltaMinutes), SchedulingFixture.Start.AddMinutes(deltaMinutes + 60));
        f.Snapshot = bay ? f.Snapshot with { Bays = f.Snapshot.Bays.Select(x => x with { Bookings = [busy] }).ToArray() }
            : f.Snapshot with { Technicians = f.Snapshot.Technicians.Select(x => x with { Bookings = [busy] }).ToArray() };
        var result = await Service(f).ExecuteAsync(Request());
        Assert.Equal(conflict, result.Failure?.Code == (bay ? FailureCode.BAY_UNAVAILABLE : FailureCode.TECHNICIAN_UNAVAILABLE));
        Assert.Equal(conflict ? 0 : 1, f.Rows.Count);
    }

    [Theory]
    [InlineData("")]
    [InlineData("a b")]
    [InlineData("é")]
    public async Task SyntaxIsCheckedBeforeTransaction(string key)
    {
        var f = new SchedulingFixture();
        Assert.Equal(FailureCode.INVALID_KEY, (await Service(f).ExecuteAsync(Request() with { RequestKey = key })).Failure!.Code);
        Assert.Equal(0, f.Transactions);
        Assert.Equal(FailureCode.INVALID_REQUEST, (await Service(f).ExecuteAsync(Request() with { CustomerId = 0 })).Failure!.Code);
    }

    internal static BookAppointment Service(SchedulingFixture f) => new(f, f.Clock, new TimeZoneResolver());

    [Fact]
    public async Task InvalidDurationAndZoneConfigurationPrecedePastTimeButFollowOwnership()
    {
        var f = new SchedulingFixture();
        typeof(KeyLoopServiceScheduler.Domain.Entities.ServiceType).GetProperty("DurationMinutes")!.SetValue(f.Service, 0);
        var request = Request() with { StartTime = f.Clock.Now };
        Assert.Equal(FailureCode.INVALID_REFERENCE_CONFIGURATION, (await Service(f).ExecuteAsync(request)).Failure!.Code);
        f.Vehicle = new(1, 2, null);
        Assert.Equal(FailureCode.VEHICLE_CUSTOMER_MISMATCH, (await Service(f).ExecuteAsync(request)).Failure!.Code);
        f.Vehicle = new(1, 1, null); f.Service = new(1, "Valid", 60);
        Assert.Equal(FailureCode.INVALID_REFERENCE_CONFIGURATION,
            (await new BookAppointment(f, f.Clock, new InvalidZones()).ExecuteAsync(request)).Failure!.Code);
        Assert.Empty(f.Rows);
    }

    [Fact]
    public async Task CrossMidnightAndTouchingWindowsCoverWholeElapsedInterval()
    {
        var f = new SchedulingFixture();
        f.Service = new(1, "Long", 120);
        LocalWindow[] windows = [new(new(2030, 1, 7, 23, 0, 0), new(2030, 1, 8, 0, 0, 0)), new(new(2030, 1, 8, 0, 0, 0), new(2030, 1, 8, 2, 0, 0))];
        f.Snapshot = f.Snapshot with { DealerWindows = windows, Technicians = f.Snapshot.Technicians.Select(x => x with { WorkingWindows = windows }).ToArray() };
        var request = Request() with { StartTime = new(2030, 1, 7, 23, 30, 0, TimeSpan.FromHours(5.5)) };
        var result = await Service(f).ExecuteAsync(request);
        Assert.Null(result.Failure);
        Assert.Equal(request.StartTime.ToUniversalTime().AddMinutes(120), result.Appointment!.EndTime);
        Assert.Equal(TimeSpan.Zero, result.Appointment.StartTime.Offset);
    }

    [Fact]
    public async Task EveryAsciiKeyCharacterAndBoundaryLengthFollowsExactContract()
    {
        foreach (var value in Enumerable.Range(0, 256))
        {
            var f = new SchedulingFixture();
            var result = await Service(f).ExecuteAsync(Request() with { RequestKey = ((char)value).ToString() });
            if (value is >= 33 and <= 126) Assert.Null(result.Failure);
            else Assert.Equal(FailureCode.INVALID_KEY, result.Failure!.Code);
        }
        var fixture = new SchedulingFixture();
        Assert.Null((await Service(fixture).ExecuteAsync(Request() with { RequestKey = new string('x', 128) })).Failure);
        Assert.Equal(FailureCode.INVALID_KEY, (await Service(fixture).ExecuteAsync(Request() with { RequestKey = new string('x', 129) })).Failure!.Code);
    }

    private sealed class InvalidZones : IZoneResolver
    {
        public TimeZoneInfo Resolve(string zoneId) => throw new InvalidReferenceConfigurationException("Invalid zone fixture");
    }
    internal static BookingRequest Request() => new(1, 1, 1, 1, SchedulingFixture.Start, "test-key");
}
