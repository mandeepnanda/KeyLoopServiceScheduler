using System.Net;
using System.Net.Http.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using KeyLoopServiceScheduler.ProcessTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.ProcessTests;

public sealed class BookingConcurrencyTests(ApiProcessFixture fixture) : IClassFixture<ApiProcessFixture>
{
    [SqlTheory]
    [InlineData("pair", "TECHNICIAN_UNAVAILABLE")]
    [InlineData("technician", "TECHNICIAN_UNAVAILABLE")]
    [InlineData("bay", "BAY_UNAVAILABLE")]
    public async Task HundredHealthyPairsAcrossTwoProcessesHaveOneConfirmationAndOneBusinessConflict(string variant, string code)
    {
        await fixture.SeedAsync();
        if (variant != "bay") await fixture.Database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1");
        if (variant != "technician") await fixture.Database.ExecuteAsync("DELETE FROM ServiceBay WHERE Id=2");
        for (var pair = 0; pair < 100; pair++)
        {
            await fixture.Database.ExecuteAsync("DELETE FROM Appointment");
            var gate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            async Task<HttpResponseMessage> Submit(HttpClient client)
            { await gate.Task; return await client.PostAsJsonAsync("/api/v1/appointments", Body()); }
            var tasks = new[] { Submit(fixture.First), Submit(fixture.Second) };
            gate.SetResult();
            var responses = await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(30));
            Assert.Single(responses, response => response.StatusCode == HttpStatusCode.Created);
            var rejected = Assert.Single(responses, response => response.StatusCode == HttpStatusCode.Conflict);
            var problem = await rejected.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>();
            Assert.Equal(code, problem.GetProperty("code").GetString());
            await using var context = fixture.Database.CreateContext();
            Assert.Equal(1, await context.Appointments.CountAsync());
            var saved = await context.Appointments.SingleAsync();
            Assert.True(saved.TechnicianId > 0 && saved.ServiceBayId > 0);
            Assert.Equal(saved.StartUtc.AddMinutes(saved.DurationMinutes), saved.EndUtc);
            foreach (var response in responses) response.Dispose();
        }
    }
    [SqlTheory]
    [InlineData(15, false)]
    [InlineData(60, true)]
    public async Task PartialOverlapAndAdjacencyAcrossTwoProcessesUseCommittedOnePair(int offsetMinutes, bool adjacent)
    {
        await fixture.SeedAsync();
        await fixture.Database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1");
        await fixture.Database.ExecuteAsync("DELETE FROM ServiceBay WHERE Id=2");
        for (var iteration = 0; iteration < 20; iteration++)
        {
            await fixture.Database.ExecuteAsync("DELETE FROM Appointment");
            var gate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var secondTime = new DateTimeOffset(2030, 1, 7, 3, 30, 0, TimeSpan.Zero).AddMinutes(offsetMinutes)
                .ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", System.Globalization.CultureInfo.InvariantCulture);
            async Task<HttpResponseMessage> Submit(HttpClient client, object body)
            {
                await gate.Task;
                return await client.PostAsJsonAsync("/api/v1/appointments", body);
            }
            // Alternate which process receives the earlier appointment.
            var earlierClient = iteration % 2 == 0 ? fixture.First : fixture.Second;
            var laterClient = iteration % 2 == 0 ? fixture.Second : fixture.First;
            var tasks = new[] { Submit(earlierClient, Body()), Submit(laterClient, Body(time: secondTime)) };
            gate.SetResult();
            var responses = await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(30));
            try
            {
                Assert.Equal(adjacent ? 2 : 1, responses.Count(response => response.StatusCode == HttpStatusCode.Created));
                if (!adjacent)
                {
                    var rejected = Assert.Single(responses, response => response.StatusCode == HttpStatusCode.Conflict);
                    var problem = await rejected.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>();
                    Assert.Equal("TECHNICIAN_UNAVAILABLE", problem.GetProperty("code").GetString());
                }
                await using var fresh = fixture.Database.CreateContext();
                var rows = await fresh.Appointments.AsNoTracking().OrderBy(row => row.StartUtc).ToListAsync();
                Assert.Equal(adjacent ? 2 : 1, rows.Count);
                Assert.All(rows, row =>
                {
                    Assert.Equal(1L, row.TechnicianId);
                    Assert.Equal(1L, row.ServiceBayId);
                    Assert.Equal("Confirmed", row.Status);
                    Assert.Equal(row.StartUtc.AddMinutes(row.DurationMinutes), row.EndUtc);
                });
                if (adjacent) Assert.Equal(rows[0].EndUtc, rows[1].StartUtc);
            }
            finally { foreach (var response in responses) response.Dispose(); }
        }
    }

    internal static object Body(long dealer = 1, string? time = null) => new
    {
        customerId = 1,
        vehicleId = 1,
        dealershipId = dealer,
        serviceTypeId = 1,
        startTime = time ?? (dealer == 1 ? "2030-01-07T03:30:00Z" : "2030-01-07T14:00:00Z")
    };
}
