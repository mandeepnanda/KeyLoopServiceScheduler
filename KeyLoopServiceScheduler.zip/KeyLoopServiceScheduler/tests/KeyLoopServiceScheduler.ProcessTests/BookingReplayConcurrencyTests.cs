using System.Net;
using System.Net.Http.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using KeyLoopServiceScheduler.ProcessTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.ProcessTests;

public sealed class BookingReplayConcurrencyTests(ApiProcessFixture fixture) : IClassFixture<ApiProcessFixture>
{
    [SqlTheory]
    [InlineData("same", 1)]
    [InlineData("offset", 1)]
    [InlineData("changed", 1)]
    [InlineData("distinct", 2)]
    [InlineData("dealers", 2)]
    public async Task KeysAcrossProcessesHaveOneBindingOrIndependentDealerScope(string scenario, int expectedRows)
    {
        await fixture.SeedAsync();
        var gate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        async Task<HttpResponseMessage> Send(HttpClient client, bool second)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/appointments")
            {
                Content = JsonContent.Create(BookingConcurrencyTests.Body(second && scenario == "dealers" ? 2 : 1,
                second && scenario == "offset" ? "2030-01-07T09:00:00+05:30" : second && scenario == "changed" ? "2030-01-07T03:30:00.0000001Z" : null))
            };
            request.Headers.Add("Idempotency-Key", second && scenario == "distinct" ? "second" : "same");
            await gate.Task;
            return await client.SendAsync(request);
        }
        var tasks = new[] { Send(fixture.First, false), Send(fixture.Second, true) };
        gate.SetResult();
        var responses = await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(30));
        if (scenario == "changed")
        {
            Assert.Single(responses, response => response.StatusCode == HttpStatusCode.Created);
            Assert.Single(responses, response => response.StatusCode == HttpStatusCode.Conflict);
        }
        else
        {
            Assert.All(responses, response => Assert.True(response.IsSuccessStatusCode));
            var rows = await Task.WhenAll(responses.Select(response => response.Content.ReadFromJsonAsync<AppointmentProjection>()));
            if (expectedRows == 1) Assert.Equal(rows[0]!.Id, rows[1]!.Id); else Assert.NotEqual(rows[0]!.Id, rows[1]!.Id);
        }
        await using var context = fixture.Database.CreateContext();
        Assert.Equal(expectedRows, await context.Appointments.CountAsync());
        foreach (var response in responses) response.Dispose();
    }
}
