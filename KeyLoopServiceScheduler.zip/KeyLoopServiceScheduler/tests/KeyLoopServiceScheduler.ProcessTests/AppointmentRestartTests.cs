using System.Net;
using System.Net.Http.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using KeyLoopServiceScheduler.ProcessTests.Fixtures;

namespace KeyLoopServiceScheduler.ProcessTests;

public sealed class AppointmentRestartTests(ApiProcessFixture fixture) : IClassFixture<ApiProcessFixture>
{
    [SqlFact]
    public async Task PastConfirmedKeyStillReplaysAfterRestartBeforeFutureValidation()
    {
        await fixture.SeedAsync();
        var options = KeyLoopServiceScheduler.Infrastructure.Configuration.SchedulerDatabaseOptions.Parse(fixture.Database.ConnectionString);
        var transaction = new KeyLoopServiceScheduler.Infrastructure.Transactions.BookingTransactionCoordinator(
            new KeyLoopServiceScheduler.Infrastructure.Transactions.BookingAttemptFactory(options, new KeyLoopServiceScheduler.Infrastructure.Transactions.DealershipApplicationLock()),
            new KeyLoopServiceScheduler.Infrastructure.Transactions.CommitOutcomeVerifier(options), new KeyLoopServiceScheduler.Infrastructure.Transactions.BookingRetryPolicy(), TimeProvider.System);
        var id = Guid.NewGuid();
        var start = new DateTimeOffset(2020, 1, 7, 3, 30, 0, TimeSpan.Zero);
        // Historical fixture insertion holds the same SQL lock; this is not a new past-time booking.
        await transaction.ExecuteAsync(1, id, async (attempt, token) =>
        { await attempt.Store.AddAsync(new(id, 1, 1, 1, 1, 1, 1, start, 60, start, "past-key"), token); return id; }, default);
        var before = await fixture.First.GetFromJsonAsync<AppointmentProjection>("/api/v1/appointments/" + id);
        await fixture.RestartFirstAsync();
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/appointments") { Content = JsonContent.Create(BookingConcurrencyTests.Body(time: "2020-01-07T03:30:00Z")) };
        request.Headers.Add("Idempotency-Key", "past-key");
        var replay = await fixture.First.SendAsync(request);
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        Assert.Equal(before, await replay.Content.ReadFromJsonAsync<AppointmentProjection>());
    }
    [SqlFact]
    public async Task RestartRetainsConfirmationResourcesAndKeyBinding()
    {
        await fixture.SeedAsync();
        await fixture.Database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1; DELETE FROM ServiceBay WHERE Id=2");
        async Task<HttpResponseMessage> Book()
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/appointments") { Content = JsonContent.Create(BookingConcurrencyTests.Body()) };
            request.Headers.Add("Idempotency-Key", "restart-key");
            return await fixture.First.SendAsync(request);
        }
        var created = await Book();
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var saved = await created.Content.ReadFromJsonAsync<AppointmentProjection>();
        await fixture.RestartFirstAsync();
        Assert.Equal(saved, await fixture.First.GetFromJsonAsync<AppointmentProjection>(created.Headers.Location));
        var replay = await Book();
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        Assert.Equal(saved, await replay.Content.ReadFromJsonAsync<AppointmentProjection>());
        Assert.Equal(HttpStatusCode.Conflict, (await fixture.Second.PostAsJsonAsync("/api/v1/appointments", BookingConcurrencyTests.Body())).StatusCode);
    }
}
