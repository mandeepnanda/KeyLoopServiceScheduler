using KeyLoopServiceScheduler.LoadHarness;
using System.Text.Json;

namespace KeyLoopServiceScheduler.ProcessTests;

public sealed class LoadProfileTests
{
    [Fact]
    public void DistributedBookingsRemainDistinctAcrossWarmupAndBeyondTheOldWrapBoundary()
    {
        var slots = new HashSet<(long, DateTimeOffset)>();
        for (var ordinal = 0; ordinal < LoadProfile.BookingCapacity; ordinal++)
        {
            var slot = LoadProfile.BookingSlot(ordinal, false);
            Assert.True(slots.Add(slot));
            var zone = TimeZoneInfo.FindSystemTimeZoneById(slot.Dealer == 1 ? "Asia/Kolkata" : "America/New_York");
            var local = TimeZoneInfo.ConvertTime(slot.Start, zone);
            Assert.InRange(local.Hour, 9, 16);
            Assert.True(local.Date < LoadProfile.BaseDate.AddDays(LoadProfile.Days));
        }
        Assert.Throws<InvalidOperationException>(() => LoadProfile.BookingSlot(LoadProfile.BookingCapacity, false));
    }
    [Fact]
    public void HotDealerDeliberatelyReusesTheSamePairInterval()
    {
        Assert.Equal(LoadProfile.BookingSlot(0, true), LoadProfile.BookingSlot(100_000, true));
        Assert.Equal(1, LoadProfile.BookingSlot(0, true).Dealer);
    }
    [Fact]
    public void TimingSummaryCombinesProcessesAndExcludesWarmupAndLateRecords()
    {
        var first = Path.Combine(Path.GetTempPath(), "scheduler-timing-" + Guid.NewGuid().ToString("N"));
        var second = first + "-second";
        var start = new DateTime(2030, 1, 7, 0, 0, 0, DateTimeKind.Utc);
        string Row(DateTime timestamp, double duration) => JsonSerializer.Serialize(new LoadTimingSample("booking.lock.wait", timestamp, timestamp.AddMilliseconds(duration), duration, "trace"));
        try
        {
            File.WriteAllLines(first, [Row(start.AddSeconds(-1), 10), Row(start.AddSeconds(1), 10)]);
            File.WriteAllLines(second, [Row(start.AddSeconds(2), 30), Row(start.AddSeconds(20), 100)]);
            var summary = Assert.Single(LoadTimingReport.Read([first, second], start, start.AddSeconds(10)));
            Assert.Equal(2, summary.Count);
            Assert.Equal(40, summary.TotalMs);
            Assert.Equal(10, summary.P50Ms);
            Assert.Equal(30, summary.P95Ms);
        }
        finally { File.Delete(first); File.Delete(second); }
    }
}
