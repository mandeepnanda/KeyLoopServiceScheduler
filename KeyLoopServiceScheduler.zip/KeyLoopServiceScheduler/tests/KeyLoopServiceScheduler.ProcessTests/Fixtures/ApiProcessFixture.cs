using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.ProcessTests.Fixtures;

public sealed class ApiProcessFixture : IAsyncLifetime
{
    public SqlDatabaseFixture Database { get; } = new();
    private readonly List<Process> processes = [];
    public ConcurrentQueue<string> Diagnostics { get; } = new();
    private readonly List<HttpClient> clients = [];
    private string? loadCaptureDirectory;
    public List<string> LoadCaptureFiles { get; } = [];
    public HttpClient First => clients[0];
    public HttpClient Second => clients[1];
    public Task InitializeAsync() => InitializeAsync(null);
    public async Task InitializeAsync(Func<SqlDatabaseFixture, Task>? prepare, string? captureDirectory = null)
    {
        loadCaptureDirectory = captureDirectory;
        if (captureDirectory is not null) Directory.CreateDirectory(captureDirectory);
        await Database.InitializeAsync();
        if (string.IsNullOrEmpty(Database.ConnectionString)) return;
        await SeedAsync();
        if (prepare is not null) await prepare(Database);
        clients.Add(await StartAsync());
        clients.Add(await StartAsync());
    }
    public async Task SeedAsync()
    {
        await Database.ResetAsync();
        await using var context = Database.CreateContext();
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), new FixtureClock(Database.Now));
        await context.Appointments.ExecuteDeleteAsync();
    }
    public async Task RestartFirstAsync()
    {
        Stop(processes[0]);
        clients[0].Dispose();
        var previousCount = processes.Count;
        clients[0] = await StartAsync();
        processes[0] = processes[previousCount];
        processes.RemoveAt(previousCount);
    }
    private async Task<HttpClient> StartAsync()
    {
        DirectoryInfo? root = new DirectoryInfo(AppContext.BaseDirectory);
        while (root is not null && !File.Exists(Path.Combine(root.FullName, "KeyLoopServiceScheduler.slnx"))) root = root.Parent;
        if (root is null) throw new InvalidOperationException("Cannot locate repository root.");
        var dll = Path.Combine(root.FullName, "src", "KeyLoopServiceScheduler.Api", "bin", "Release", "net10.0", "KeyLoopServiceScheduler.Api.dll");
        if (!File.Exists(dll)) throw new InvalidOperationException("Build the Release API before process tests.");
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        var start = new ProcessStartInfo("dotnet")
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = Path.Combine(root.FullName, "src", "KeyLoopServiceScheduler.Api")
        };
        start.ArgumentList.Add(dll); start.ArgumentList.Add("--urls"); start.ArgumentList.Add("http://127.0.0.1:" + port);
        start.Environment["ASPNETCORE_ENVIRONMENT"] = "Development";
        start.Environment["Scheduler__StorageMode"] = "SqlServer";
        start.Environment["ConnectionStrings__Scheduler"] = Database.ConnectionString;
        start.Environment.Remove("Telemetry__OtlpEndpoint");
        start.Environment.Remove("Telemetry__LoadCaptureFile");
        if (loadCaptureDirectory is not null)
        {
            var capture = Path.GetFullPath(Path.Combine(loadCaptureDirectory, $"api-{processes.Count}-{Guid.NewGuid():N}.jsonl"));
            LoadCaptureFiles.Add(capture);
            start.Environment["Telemetry__LoadCaptureFile"] = capture;
        }
        var process = Process.Start(start) ?? throw new InvalidOperationException("Could not launch API process.");
        process.OutputDataReceived += (_, args) => { if (args.Data is not null && Diagnostics.Count < 200) Diagnostics.Enqueue(args.Data); };
        process.ErrorDataReceived += (_, args) => { if (args.Data is not null && Diagnostics.Count < 200) Diagnostics.Enqueue(args.Data); };
        process.BeginOutputReadLine(); process.BeginErrorReadLine();
        processes.Add(process);
        var client = new HttpClient { BaseAddress = new("http://127.0.0.1:" + port), Timeout = TimeSpan.FromSeconds(20) };
        using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        try
        {
            while (!budget.IsCancellationRequested)
            {
                if (process.HasExited) throw new InvalidOperationException("API process exited: " + string.Join(Environment.NewLine, Diagnostics));
                try { if ((await client.GetAsync("/health/ready", budget.Token)).IsSuccessStatusCode) return client; }
                catch (HttpRequestException) { }
                await Task.Delay(100, budget.Token);
            }
            throw new TimeoutException("API readiness timed out.");
        }
        catch { client.Dispose(); throw; }
    }
    private static void Stop(Process process)
    {
        if (!process.HasExited) { process.Kill(entireProcessTree: true); process.WaitForExit(5000); }
        process.Dispose();
    }
    public async Task DisposeAsync()
    {
        foreach (var client in clients) client.Dispose();
        foreach (var process in processes) Stop(process);
        await Database.DisposeAsync();
    }
    private sealed class FixtureClock(DateTimeOffset now) : TimeProvider { public override DateTimeOffset GetUtcNow() => now; }
}
