using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Availability;

public sealed class StaleAvailabilityTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlFact]
    public async Task PositiveQueryDoesNotReservePairAndStaleBookingRechecksUnderSqlLock()
    {
        await BookingScenario.SeedAsync(database);
        await database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1; DELETE FROM ServiceBay WHERE Id=2");
        await using var context = database.CreateContext();
        var query = new QueryAvailability(new AvailabilityReader(context, new ResourceQueries(context)), new FixedTimeProvider(database.Now), new TimeZoneResolver());
        var request = BookingScenario.Request("original");
        Assert.True((await query.ExecuteAsync(new(request.DealershipId, request.ServiceTypeId, request.StartTime))).Details!.Available);
        Assert.Null((await BookingScenario.Service(database).ExecuteAsync(request with { RequestKey = "winner" })).Failure);
        var stale = await BookingScenario.Service(database).ExecuteAsync(request);
        Assert.Equal(FailureCode.TECHNICIAN_UNAVAILABLE, stale.Failure!.Code);
        Assert.Equal(1, await context.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(context);
    }
}
