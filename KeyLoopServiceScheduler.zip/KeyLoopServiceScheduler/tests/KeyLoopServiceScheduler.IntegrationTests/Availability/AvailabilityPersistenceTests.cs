using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Availability;

public sealed class AvailabilityPersistenceTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData(4, 30, "AVAILABLE")]
    [InlineData(6, 30, "AVAILABLE")]
    [InlineData(11, 30, "DEALERSHIP_CLOSED")]
    public async Task DerivedIntervalUsesCommittedSchedulesAndNeverWrites(int hour, int minute, string expected)
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        var clock = new FixedTimeProvider(database.Now);
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), clock);
        context.ChangeTracker.Clear();
        var before = await context.Appointments.CountAsync();
        var service = new QueryAvailability(new AvailabilityReader(context, new ResourceQueries(context)), clock, new TimeZoneResolver());
        var result = await service.ExecuteAsync(new(1, 1, new DateTimeOffset(2030, 1, 7, hour, minute, 0, TimeSpan.Zero)));
        Assert.Null(result.Failure);
        Assert.Equal(expected, result.Details!.ReasonCode);
        Assert.Equal(before, await context.Appointments.CountAsync());
        Assert.Empty(context.ChangeTracker.Entries());
    }

    [SqlTheory]
    [InlineData("qualification", "NO_QUALIFIED_TECHNICIAN")]
    [InlineData("technician", "TECHNICIAN_UNAVAILABLE")]
    [InlineData("bay", "BAY_UNAVAILABLE")]
    [InlineData("hours", "DEALERSHIP_CLOSED")]
    [InlineData("gap", "TECHNICIAN_UNAVAILABLE")]
    public async Task MissingResourcesAndShiftGapsAreReadOnlyUnavailableResults(string scenario, string expected)
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        var clock = new FixedTimeProvider(database.Now);
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), clock);
        await context.Appointments.ExecuteDeleteAsync();
        if (scenario == "qualification") await context.TechnicianQualifications.Where(x => x.TechnicianId == 1 || x.TechnicianId == 2).ExecuteDeleteAsync();
        if (scenario == "technician") await context.TechnicianWorkingWindows.Where(x => x.TechnicianId == 1 || x.TechnicianId == 2).ExecuteDeleteAsync();
        if (scenario == "bay") await context.ServiceBays.Where(x => x.DealershipId == 1).ExecuteDeleteAsync();
        if (scenario == "hours") await context.DealershipOperatingWindows.Where(x => x.DealershipId == 1).ExecuteDeleteAsync();
        if (scenario == "gap") await context.TechnicianQualifications.Where(x => x.TechnicianId == 2 && x.ServiceTypeId == 1).ExecuteDeleteAsync();
        context.ChangeTracker.Clear();
        var before = await context.Appointments.CountAsync();
        var service = new QueryAvailability(new AvailabilityReader(context, new ResourceQueries(context)), clock, new TimeZoneResolver());
        var result = await service.ExecuteAsync(new(1, 1, new DateTimeOffset(2030, 1, 7, scenario == "gap" ? 6 : 4, scenario == "gap" ? 0 : 30, 0, TimeSpan.Zero)));
        Assert.Null(result.Failure);
        Assert.False(result.Details!.Available);
        Assert.Equal(expected, result.Details.ReasonCode);
        Assert.Equal(before, await context.Appointments.CountAsync());
        Assert.Empty(context.ChangeTracker.Entries());
    }
}
