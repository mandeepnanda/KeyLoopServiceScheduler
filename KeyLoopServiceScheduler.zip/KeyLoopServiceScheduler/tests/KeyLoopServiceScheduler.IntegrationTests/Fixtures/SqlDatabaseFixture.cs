using System.Data;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Fixtures;

public sealed class SqlFactAttribute : FactAttribute
{
    public SqlFactAttribute()
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("SCHEDULER_TEST_CONNECTION")))
            Skip = "Real SQL Server unavailable: supply SCHEDULER_TEST_CONNECTION. No InMemory/SQLite fallback.";
    }
}
public sealed class SqlTheoryAttribute : TheoryAttribute
{
    public SqlTheoryAttribute()
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("SCHEDULER_TEST_CONNECTION")))
            Skip = "Real SQL Server unavailable: supply SCHEDULER_TEST_CONNECTION. No InMemory/SQLite fallback.";
    }
}

/// <summary>One disposable database per test class; no outer transaction hides actual persistence.</summary>
public sealed class SqlDatabaseFixture : IAsyncLifetime
{
    public string DatabaseName { get; } = "KeyLoopScheduler_Test_" + Guid.NewGuid().ToString("N");
    private string? masterConnection;
    private bool created;
    public string ConnectionString { get; private set; } = "";
    public DateTimeOffset Now { get; } = new(2030, 1, 6, 0, 0, 0, TimeSpan.Zero);

    public SchedulerDbContext CreateContext() => new(new DbContextOptionsBuilder<SchedulerDbContext>()
        .UseSqlServer(ConnectionString, sql => sql.UseCompatibilityLevel(160).CommandTimeout(5)).Options);

    public async Task InitializeAsync()
    {
        var supplied = Environment.GetEnvironmentVariable("SCHEDULER_TEST_CONNECTION");
        if (string.IsNullOrWhiteSpace(supplied)) return;
        var builder = new SqlConnectionStringBuilder(supplied)
        {
            InitialCatalog = "master",
            MultipleActiveResultSets = false,
            ConnectRetryCount = 0,
            ConnectTimeout = 3
        };
        masterConnection = builder.ConnectionString;
        await using var master = new SqlConnection(masterConnection);
        await master.OpenAsync();
        await using var create = new SqlCommand($"CREATE DATABASE [{DatabaseName}]", master) { CommandTimeout = 30 };
        await create.ExecuteNonQueryAsync();
        created = true;
        builder.InitialCatalog = DatabaseName;
        ConnectionString = builder.ConnectionString;
        await using var context = CreateContext();
        await context.Database.MigrateAsync();
    }

    public async Task<int> ExecuteAsync(string sql, params SqlParameter[] parameters)
    {
        await using var connection = new SqlConnection(ConnectionString);
        await connection.OpenAsync();
        await using var command = new SqlCommand(sql, connection) { CommandTimeout = 5 };
        command.Parameters.AddRange(parameters);
        return await command.ExecuteNonQueryAsync();
    }

    public Task<int> ResetAsync() => ExecuteAsync("DELETE FROM Appointment; DELETE FROM DealershipOperatingWindow; " +
        "DELETE FROM TechnicianWorkingWindow; DELETE FROM ServiceBay; DELETE FROM TechnicianQualification; " +
        "DELETE FROM Vehicle; DELETE FROM ServiceType; DELETE FROM Technician; DELETE FROM Customer; DELETE FROM Dealership;");

    public Task<int> InsertAppointmentAsync(IReadOnlyDictionary<string, object?>? overrides = null)
    {
        var start = new DateTimeOffset(2030, 1, 7, 4, 30, 0, TimeSpan.Zero).AddTicks(1);
        var values = new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["CustomerId"] = 1L,
            ["VehicleId"] = 1L,
            ["DealershipId"] = 1L,
            ["ServiceTypeId"] = 1L,
            ["TechnicianId"] = 1L,
            ["ServiceBayId"] = 1L,
            ["StartUtc"] = start,
            ["EndUtc"] = start.AddMinutes(60),
            ["DurationMinutes"] = 60,
            ["Status"] = "Confirmed",
            ["RequestKey"] = null,
            ["CreatedUtc"] = Now
        };
        if (overrides is not null)
            foreach (var (key, value) in overrides) values[key] = value;
        var types = new Dictionary<string, SqlDbType>
        {
            ["Id"] = SqlDbType.UniqueIdentifier,
            ["CustomerId"] = SqlDbType.BigInt,
            ["VehicleId"] = SqlDbType.BigInt,
            ["DealershipId"] = SqlDbType.BigInt,
            ["ServiceTypeId"] = SqlDbType.BigInt,
            ["TechnicianId"] = SqlDbType.BigInt,
            ["ServiceBayId"] = SqlDbType.BigInt,
            ["StartUtc"] = SqlDbType.DateTimeOffset,
            ["EndUtc"] = SqlDbType.DateTimeOffset,
            ["DurationMinutes"] = SqlDbType.Int,
            ["Status"] = SqlDbType.VarChar,
            ["RequestKey"] = SqlDbType.VarChar,
            ["CreatedUtc"] = SqlDbType.DateTimeOffset
        };
        var parameters = values.Select(pair => new SqlParameter("@" + pair.Key, types[pair.Key])
        { Value = pair.Value ?? DBNull.Value }).ToArray();
        return ExecuteAsync($"INSERT INTO [Appointment] ({string.Join(", ", values.Keys.Select(key => $"[{key}]"))}) " +
            $"VALUES ({string.Join(", ", values.Keys.Select(key => "@" + key))})", parameters);
    }

    public async Task DisposeAsync()
    {
        if (!created || masterConnection is null) return;
        if (!DatabaseName.StartsWith("KeyLoopScheduler_Test_", StringComparison.Ordinal) ||
            !Guid.TryParseExact(DatabaseName["KeyLoopScheduler_Test_".Length..], "N", out _))
            throw new InvalidOperationException("Refusing to drop a database outside the fixture namespace.");
        // Fixture-owned contexts/processes finish before disposal; leave other databases' pools alone.
        using (var fixtureConnection = new SqlConnection(ConnectionString)) SqlConnection.ClearPool(fixtureConnection);
        await using var connection = new SqlConnection(masterConnection);
        await connection.OpenAsync();
        await using var drop = new SqlCommand(
            $"ALTER DATABASE [{DatabaseName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{DatabaseName}]", connection)
        { CommandTimeout = 30 };
        await drop.ExecuteNonQueryAsync();
    }
}
