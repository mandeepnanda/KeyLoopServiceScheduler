using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure.Transactions;

namespace KeyLoopServiceScheduler.IntegrationTests.Fixtures;

public enum BookingFaultPoint { BeforeSave, BeforeCommit, AfterActualCommit }

/// <summary>Test-only wrapper; after-commit fault is simulated acknowledgement loss following a real SQL commit.</summary>
public sealed class BookingFaultDecorator(IBookingAttemptFactory inner, BookingFaultPoint point) : IBookingAttemptFactory
{
    public int Created { get; private set; }
    public int Disposed { get; private set; }
    public IBookingAttemptUnit Create(Guid operationId)
    {
        Created++;
        return new FaultUnit(inner.Create(operationId), point, () => Disposed++);
    }
    private sealed class FaultUnit(IBookingAttemptUnit inner, BookingFaultPoint point, Action disposed) : IBookingAttemptUnit
    {
        public Guid OperationId => inner.OperationId;
        public IBookingStore Store => new FaultStore(inner.Store, point);
        public bool WriteAttempted => inner.WriteAttempted;
        public bool CommitStarted => inner.CommitStarted;
        public Task AcquireAsync(long dealershipId, BookingDeadline deadline) => inner.AcquireAsync(dealershipId, deadline);
        public async Task CommitAsync(CancellationToken cancellationToken)
        {
            if (point == BookingFaultPoint.BeforeCommit) throw new InvalidOperationException("Test-only before-commit failure");
            await inner.CommitAsync(cancellationToken);
            if (point == BookingFaultPoint.AfterActualCommit) throw new IOException("Simulated acknowledgement loss after real SQL commit");
        }
        public Task<bool> RollbackAsync(CancellationToken cancellationToken) => inner.RollbackAsync(cancellationToken);
        public async ValueTask DisposeAsync() { try { await inner.DisposeAsync(); } finally { disposed(); } }
    }
    private sealed class FaultStore(IBookingStore inner, BookingFaultPoint point) : IBookingStore
    {
        public Task<AppointmentProjection?> FindConfirmedAsync(long dealershipId, string requestKey, CancellationToken cancellationToken) => inner.FindConfirmedAsync(dealershipId, requestKey, cancellationToken);
        public Task<BookingReferences> ReadReferencesAsync(long customerId, long vehicleId, long dealershipId, long serviceTypeId, CancellationToken cancellationToken) => inner.ReadReferencesAsync(customerId, vehicleId, dealershipId, serviceTypeId, cancellationToken);
        public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken) => inner.ReadResourcesAsync(dealershipId, serviceTypeId, interval, cancellationToken);
        public Task AddAsync(Appointment appointment, CancellationToken cancellationToken) => point == BookingFaultPoint.BeforeSave
            ? throw new InvalidOperationException("Test-only before-save failure") : inner.AddAsync(appointment, cancellationToken);
    }
}
