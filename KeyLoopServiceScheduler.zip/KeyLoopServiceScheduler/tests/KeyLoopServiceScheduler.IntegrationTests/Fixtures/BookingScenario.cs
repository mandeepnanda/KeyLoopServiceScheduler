using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Fixtures;

internal static class BookingScenario
{
    public static BookingRequest Request(string? key = null, long dealer = 1) => new(1, 1, dealer, 1,
        dealer == 1 ? new(2030, 1, 7, 3, 30, 0, TimeSpan.Zero) : new(2030, 1, 7, 14, 0, 0, TimeSpan.Zero), key);
    public static SchedulerDatabaseOptions Options(SqlDatabaseFixture database) => SchedulerDatabaseOptions.Parse(database.ConnectionString);
    public static BookAppointment Service(SqlDatabaseFixture database, IBookingAttemptFactory? factory = null, ICommitOutcomeVerifier? verifier = null)
    {
        var options = Options(database);
        var clock = new FixedTimeProvider(database.Now);
        return new(new BookingTransactionCoordinator(factory ?? new BookingAttemptFactory(options, new DealershipApplicationLock()),
            verifier ?? new CommitOutcomeVerifier(options), new BookingRetryPolicy(), clock), clock, new TimeZoneResolver());
    }
    public static async Task SeedAsync(SqlDatabaseFixture database, bool removeHistory = true)
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), new FixedTimeProvider(database.Now));
        if (removeHistory) await context.Appointments.ExecuteDeleteAsync();
    }
    public static async Task AssertAtomicNoOverlapAsync(SchedulerDbContext context)
    {
        var rows = await context.Appointments.AsNoTracking().ToListAsync();
        Assert.All(rows, row =>
        {
            Assert.True(row.TechnicianId > 0 && row.ServiceBayId > 0);
            Assert.Equal("Confirmed", row.Status);
            Assert.Equal(row.StartUtc.AddMinutes(row.DurationMinutes), row.EndUtc);
        });
        foreach (var first in rows)
            foreach (var second in rows.Where(x => x.Id != first.Id && (x.TechnicianId == first.TechnicianId || x.ServiceBayId == first.ServiceBayId)))
                Assert.False(first.StartUtc < second.EndUtc && first.EndUtc > second.StartUtc);
    }
}
