using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

// These contract checks use explicit mock adapters; SQL journey checks are separate.
public sealed class BookingContractTests
{
    internal static async Task<string> SampleBody(HttpClient client)
    {
        var demo = await client.GetFromJsonAsync<JsonElement>("/demo");
        var booking = demo.GetProperty("exampleBooking");
        return JsonSerializer.Serialize(new
        {
            customerId = 1,
            vehicleId = 1,
            dealershipId = 1,
            serviceTypeId = 1,
            startTime = booking.GetProperty("startTime").GetString()
        });
    }
    internal static async Task<HttpResponseMessage> Post(HttpClient client, string body, string? key = "contract-key")
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/appointments")
        { Content = new StringContent(body, Encoding.UTF8, "application/json") };
        if (key is not null) request.Headers.TryAddWithoutValidation("Idempotency-Key", key);
        request.Headers.Add("X-Correlation-ID", "contract-01");
        return await client.SendAsync(request);
    }
    [Fact]
    public async Task CreationReplayRetrievalAndCapacityHaveContractHeadersAndUtcBodies()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        var body = await SampleBody(client);
        var created = await Post(client, body);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        Assert.Equal("contract-01", Assert.Single(created.Headers.GetValues("X-Correlation-ID")));
        var saved = await created.Content.ReadFromJsonAsync<JsonElement>();
        Assert.EndsWith("Z", saved.GetProperty("startTime").GetString());
        Assert.EndsWith("Z", saved.GetProperty("endTime").GetString());
        Assert.False(saved.TryGetProperty("requestKey", out _));
        var replay = await Post(client, body);
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        Assert.Equal(created.Headers.Location, replay.Headers.Location);
        Assert.Equal(await created.Content.ReadAsStringAsync(), await replay.Content.ReadAsStringAsync());
        Assert.Equal(await created.Content.ReadAsStringAsync(), await client.GetStringAsync(created.Headers.Location));
        var mismatch = await Post(client, body.Replace("\"vehicleId\":1", "\"vehicleId\":2"));
        await AssertProblem(mismatch, HttpStatusCode.Conflict, "KEY_PAYLOAD_MISMATCH");
        Assert.Equal(HttpStatusCode.Created, (await Post(client, body, "second")).StatusCode);
        await AssertProblem(await Post(client, body, "third"), HttpStatusCode.Conflict, "TECHNICIAN_UNAVAILABLE");
    }
    [Theory]
    [InlineData("2030-01-07T09:00:00", "INVALID_START_TIME")]
    [InlineData("2030-02-30T09:00:00Z", "INVALID_START_TIME")]
    [InlineData("2030-01-07T09:00:00.12345678Z", "INVALID_START_TIME")]
    [InlineData("2030-01-07T09:00:00+14:01", "INVALID_START_TIME")]
    [InlineData("0001-01-01T00:00:00+14:00", "INVALID_START_TIME")]
    [InlineData("9999-12-31T23:59:59Z", "INVALID_START_TIME")]
    public async Task InvalidTimestampsHaveStableProblemCode(string timestamp, string code)
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        var body = JsonSerializer.Serialize(new { customerId = 1, vehicleId = 1, dealershipId = 1, serviceTypeId = 1, startTime = timestamp });
        await AssertProblem(await Post(client, body), HttpStatusCode.BadRequest, code);
    }
    [Theory]
    [InlineData("{}")]
    [InlineData("null")]
    [InlineData("[]")]
    [InlineData("{\"customerId\":9223372036854775808,\"vehicleId\":1,\"dealershipId\":1,\"serviceTypeId\":1,\"startTime\":\"2030-01-07T09:00:00Z\"}")]
    [InlineData("{\"customerId\":1,\"vehicleId\":1,\"dealershipId\":1,\"serviceTypeId\":1,\"startTime\":\"2030-01-07T09:00:00Z\",\"durationMinutes\":60}")]
    [InlineData("{\"customerId\":1,\"customerId\":2,\"vehicleId\":1,\"dealershipId\":1,\"serviceTypeId\":1,\"startTime\":\"2030-01-07T09:00:00Z\"}")]
    public async Task InvalidShapeOrReferencesAreRejected(string body)
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        await AssertProblem(await Post(client, body), HttpStatusCode.BadRequest, "INVALID_REQUEST");
    }
    [Theory]
    [InlineData("contains space")]
    [InlineData("é")]
    public async Task PresentInvalidKeyIsRejected(string key)
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        await AssertProblem(await Post(client, await SampleBody(client), key), HttpStatusCode.BadRequest, "INVALID_KEY");
    }
    [Fact]
    public void EmptyHeaderIsInvalidWhenPresentAtTheServerBoundary()
    {
        // HttpClient omits empty outgoing values; exercise the actual server header collection.
        var headers = new Microsoft.AspNetCore.Http.HeaderDictionary { ["Idempotency-Key"] = "" };
        Assert.False(KeyLoopServiceScheduler.Api.Validation.RequestKeyValidator.TryRead(headers, out _));
    }
    internal static async Task AssertProblem(HttpResponseMessage response, HttpStatusCode status, string code)
    {
        Assert.Equal(status, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType!.MediaType);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Equal(code, problem.GetProperty("code").GetString());
        Assert.Equal("urn:keyloop:problem:" + code, problem.GetProperty("type").GetString());
        Assert.Equal(Assert.Single(response.Headers.GetValues("X-Correlation-ID")), problem.GetProperty("correlationId").GetString());
        Assert.False(problem.TryGetProperty("exception", out _));
    }
}
