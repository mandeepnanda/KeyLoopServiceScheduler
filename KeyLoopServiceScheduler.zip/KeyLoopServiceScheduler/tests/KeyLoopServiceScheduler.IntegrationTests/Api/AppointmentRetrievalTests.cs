using System.Net;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class AppointmentRetrievalTests
{
    [Fact]
    public async Task SeededRetrievalIsIndependentAndIdentifiersDistinguish400From404()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/api/v1/appointments/" + SchedulerSeedData.HistoryId)).StatusCode);
        await BookingContractTests.AssertProblem(await client.GetAsync("/api/v1/appointments/not-a-guid"), HttpStatusCode.BadRequest, "INVALID_REQUEST");
        await BookingContractTests.AssertProblem(await client.GetAsync("/api/v1/appointments/" + Guid.NewGuid()), HttpStatusCode.NotFound, "APPOINTMENT_NOT_FOUND");
    }
}
