using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using KeyLoopServiceScheduler.IntegrationTests.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class AvailabilityContractTests
{
    [Fact]
    public async Task QueryIsProvisionalThenReflectsBookingsWithoutReservingCapacity()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        var demo = await client.GetFromJsonAsync<JsonElement>("/demo");
        var url = demo.GetProperty("availabilityUrl").GetString()!.Replace("/demo/", "/api/v1/");
        for (var i = 0; i < 2; i++)
        {
            var details = await client.GetFromJsonAsync<JsonElement>(url);
            Assert.True(details.GetProperty("available").GetBoolean());
            Assert.Equal("Availability is provisional until booking confirmation succeeds.", details.GetProperty("notice").GetString());
        }
        var body = await BookingContractTests.SampleBody(client);
        Assert.Equal(HttpStatusCode.Created, (await BookingContractTests.Post(client, body, "one")).StatusCode);
        Assert.Equal(HttpStatusCode.Created, (await BookingContractTests.Post(client, body, "two")).StatusCode);
        var unavailable = await client.GetFromJsonAsync<JsonElement>(url);
        Assert.False(unavailable.GetProperty("available").GetBoolean());
        Assert.Equal("TECHNICIAN_UNAVAILABLE", unavailable.GetProperty("reasonCode").GetString());
        await BookingContractTests.AssertProblem(await client.GetAsync(url + "&surprise=1"), HttpStatusCode.BadRequest, "INVALID_REQUEST");
    }
}
