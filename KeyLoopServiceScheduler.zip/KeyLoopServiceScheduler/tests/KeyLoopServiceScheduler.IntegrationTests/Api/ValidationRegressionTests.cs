using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Mock;
using KeyLoopServiceScheduler.Api.Validation;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class ValidationRegressionTests
{
    [Fact]
    public async Task MalformedJsonAndUnsupportedBodyMediaTypeUseSafeValidationContract()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        await BookingContractTests.AssertProblem(await BookingContractTests.Post(client, "{"), HttpStatusCode.BadRequest, "INVALID_REQUEST");
        await BookingContractTests.AssertProblem(await client.PostAsync("/api/v1/appointments", new StringContent("{}")), HttpStatusCode.BadRequest, "INVALID_REQUEST");
    }
    [Fact]
    public void KeysAcceptExactlyVisibleAsciiAndTimestampsPreserveHundredNanoseconds()
    {
        for (var code = 0; code < 256; code++) Assert.Equal(code is >= 33 and <= 126, RequestKeyValidator.Valid(((char)code).ToString()));
        Assert.True(RequestKeyValidator.Valid(new string('x', 128)));
        Assert.False(RequestKeyValidator.Valid(new string('x', 129)));
        Assert.True(OffsetTimestampJsonConverter.TryParse("2030-01-07T09:00:00.0000001+05:30", out var time));
        Assert.Equal(1, time.Ticks % TimeSpan.TicksPerSecond);
    }
    [Theory]
    [InlineData(FailureCode.BOOKING_BUSY, PersistenceOutcome.NotCommitted)]
    [InlineData(FailureCode.REQUEST_TIMEOUT, PersistenceOutcome.NotCommitted)]
    [InlineData(FailureCode.BOOKING_OUTCOME_UNKNOWN, PersistenceOutcome.Unknown)]
    public async Task TechnicalResponsesPreserveSafeOutcomeAndExposeNoProviderMessage(FailureCode code, PersistenceOutcome outcome)
    {
        using var factory = new TechnicalFactory(new(code, outcome));
        using var client = factory.CreateClient();
        var result = await BookingContractTests.Post(client, await BookingContractTests.SampleBody(client));
        await BookingContractTests.AssertProblem(result, HttpStatusCode.ServiceUnavailable, code.ToString());
        Assert.Contains(outcome == PersistenceOutcome.Unknown ? "unknown" : "not_committed", await result.Content.ReadAsStringAsync());
    }
    [Theory]
    [InlineData(true, PersistenceOutcome.Unknown, "original request key")]
    [InlineData(false, PersistenceOutcome.Unknown, "duplicate")]
    [InlineData(true, PersistenceOutcome.NotCommitted, "not confirmed")]
    [InlineData(false, PersistenceOutcome.NotCommitted, "not confirmed")]
    public async Task RetryGuidanceDistinguishesKeyPresenceAndKnownPersistenceOutcome(bool keyed, PersistenceOutcome outcome, string expected)
    {
        var code = outcome == PersistenceOutcome.Unknown ? FailureCode.BOOKING_OUTCOME_UNKNOWN : FailureCode.DATABASE_UNAVAILABLE;
        using var factory = new TechnicalFactory(new(code, outcome));
        using var client = factory.CreateClient();
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/appointments")
        { Content = new StringContent(await BookingContractTests.SampleBody(client), System.Text.Encoding.UTF8, "application/json") };
        if (keyed) request.Headers.Add("Idempotency-Key", "original-key");
        using var response = await client.SendAsync(request);
        Assert.Equal(HttpStatusCode.ServiceUnavailable, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>();
        var detail = problem.GetProperty("detail").GetString()!;
        Assert.Contains(expected, detail);
        if (!keyed && outcome == PersistenceOutcome.Unknown)
        {
            Assert.Contains("may already", detail);
            Assert.Contains("new key cannot recover", detail);
        }
        Assert.Equal(outcome == PersistenceOutcome.Unknown ? "unknown" : "not_committed", problem.GetProperty("outcome").GetString());
    }
    [Fact]
    public async Task RetrievalTechnicalFailureHasNoBookingKeyAdvice()
    {
        using var factory = new TechnicalReaderFactory();
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/v1/appointments/11111111-1111-1111-1111-111111111111");
        Assert.Equal(HttpStatusCode.ServiceUnavailable, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>();
        Assert.DoesNotContain("key", problem.GetProperty("detail").GetString()!);
        Assert.False(problem.TryGetProperty("outcome", out _));
    }
    private sealed class TechnicalReaderFactory : MockModeTests.MockApiFactory
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            base.ConfigureWebHost(builder);
            builder.ConfigureServices(services => { services.RemoveAll<IAppointmentReader>(); services.AddScoped<IAppointmentReader, TechnicalReader>(); });
        }
    }
    private sealed class TechnicalReader : IAppointmentReader
    {
        public Task<AppointmentProjection?> GetAsync(Guid id, CancellationToken cancellationToken = default) =>
            throw new BookingTransactionException(new(FailureCode.DATABASE_UNAVAILABLE));
    }
    private sealed class TechnicalFactory(Failure failure) : MockModeTests.MockApiFactory
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            base.ConfigureWebHost(builder);
            builder.ConfigureServices(services => { services.RemoveAll<IBookingTransaction>(); services.AddScoped<IBookingTransaction>(_ => new TechnicalTransaction(failure)); });
        }
    }
    private sealed class TechnicalTransaction(Failure failure) : IBookingTransaction
    {
        public Task<T> ExecuteAsync<T>(long dealer, Guid operation, Func<IBookingAttempt, CancellationToken, Task<T>> work, CancellationToken token) => throw new BookingTransactionException(failure);
    }
}
