using System.Net;
using System.Net.Http.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class SqlHttpJourneyTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlFact]
    public async Task BookingReplayRetrievalAndProvisionalQueryUseCommittedSqlRows()
    {
        await BookingScenario.SeedAsync(database);
        using var factory = new SchedulerApiFactory(database.ConnectionString, database.Now);
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-Correlation-ID", "sql-journey");
        var request = BookingScenario.Request("sql-key");
        var query = "/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=" + Uri.EscapeDataString(request.StartTime.ToString("O"));
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync(query)).StatusCode);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
        var body = System.Text.Json.JsonSerializer.Serialize(new { customerId = 1, vehicleId = 1, dealershipId = 1, serviceTypeId = 1, startTime = request.StartTime });
        var created = await BookingContractTests.Post(client, body, request.RequestKey);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var saved = await created.Content.ReadFromJsonAsync<AppointmentProjection>();
        Assert.NotNull(saved);
        Assert.Equal(saved, await client.GetFromJsonAsync<AppointmentProjection>(created.Headers.Location));
        var replay = await BookingContractTests.Post(client, body, request.RequestKey);
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        Assert.Equal(created.Headers.Location, replay.Headers.Location);
        Assert.Equal(saved, await replay.Content.ReadFromJsonAsync<AppointmentProjection>());
        Assert.Equal(1, await context.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(context);
    }
    [SqlFact]
    public async Task SeededRetrievalNeedsNoBookingAndInvalidRequestsChangeNoRows()
    {
        await BookingScenario.SeedAsync(database, removeHistory: false);
        using var factory = new SchedulerApiFactory(database.ConnectionString, database.Now);
        using var client = factory.CreateClient();
        var row = await client.GetFromJsonAsync<AppointmentProjection>("/api/v1/appointments/" + SchedulerSeedData.HistoryId);
        Assert.Equal(SchedulerSeedData.HistoryId, row!.Id);
        await BookingContractTests.AssertProblem(await BookingContractTests.Post(client, "{}"), HttpStatusCode.BadRequest, "INVALID_REQUEST");
        await using var context = database.CreateContext();
        Assert.Equal(1, await context.Appointments.CountAsync());
    }
    [SqlTheory]
    [InlineData("qualification", "NO_QUALIFIED_TECHNICIAN")]
    [InlineData("technician", "TECHNICIAN_UNAVAILABLE")]
    [InlineData("bay", "BAY_UNAVAILABLE")]
    public async Task SqlResourceConflictsHaveSpecific409AndDoNotPersist(string unavailable, string code)
    {
        await BookingScenario.SeedAsync(database);
        await database.ExecuteAsync(unavailable switch
        {
            "qualification" => "DELETE FROM TechnicianQualification WHERE TechnicianId IN (1,2)",
            "technician" => "DELETE FROM TechnicianWorkingWindow WHERE TechnicianId IN (1,2)",
            _ => "DELETE FROM ServiceBay WHERE DealershipId=1"
        });
        using var factory = new SchedulerApiFactory(database.ConnectionString, database.Now);
        using var client = factory.CreateClient();
        var body = "{\"customerId\":1,\"vehicleId\":1,\"dealershipId\":1,\"serviceTypeId\":1,\"startTime\":\"2030-01-07T03:30:00Z\"}";
        await BookingContractTests.AssertProblem(await BookingContractTests.Post(client, body), HttpStatusCode.Conflict, code);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
    }
}
