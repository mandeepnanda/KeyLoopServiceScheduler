using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class SqlScheduleContractTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData(3, 10, 2, "-05:00")]
    [InlineData(11, 3, 1, "-04:00")]
    public async Task InvalidDstBoundaryIsExcludedButAnUnaffectedWindowCanCoverElapsedService(int month, int day, int invalidHour, string offset)
    {
        await BookingScenario.SeedAsync(database);
        await using var context = database.CreateContext();
        var date = new DateTime(2030, month, day);
        context.DealershipOperatingWindows.Add(new(9001, 2, date.AddHours(invalidHour).AddMinutes(30), date.AddHours(4)));
        context.TechnicianWorkingWindows.Add(new(9001, 3, date, date.AddHours(4)));
        await context.SaveChangesAsync();
        using var factory = new SchedulerApiFactory(database.ConnectionString, database.Now);
        using var client = factory.CreateClient();
        var time = $"2030-{month:D2}-{day:D2}T01:30:00{offset}";
        var body = JsonSerializer.Serialize(new { customerId = 1, vehicleId = 1, dealershipId = 2, serviceTypeId = 1, startTime = time });
        await BookingContractTests.AssertProblem(await BookingContractTests.Post(client, body), HttpStatusCode.Conflict, "DEALERSHIP_CLOSED");
        context.DealershipOperatingWindows.Add(new(9002, 2, date, date.AddHours(4)));
        await context.SaveChangesAsync();
        var confirmed = await BookingContractTests.Post(client, body);
        Assert.Equal(HttpStatusCode.Created, confirmed.StatusCode);
        var saved = await confirmed.Content.ReadFromJsonAsync<AppointmentProjection>();
        Assert.Equal(TimeSpan.FromMinutes(60), saved!.EndTime - saved.StartTime);
    }
    [SqlFact]
    public async Task CrossMidnightWindowIsIncludedForBothQueryAndBooking()
    {
        await BookingScenario.SeedAsync(database);
        await using var context = database.CreateContext();
        var opening = new DateTime(2030, 1, 7, 22, 0, 0);
        context.DealershipOperatingWindows.Add(new(9001, 1, opening, opening.AddHours(4)));
        context.TechnicianWorkingWindows.Add(new(9001, 1, opening, opening.AddHours(4)));
        await context.SaveChangesAsync();
        using var factory = new SchedulerApiFactory(database.ConnectionString, database.Now);
        using var client = factory.CreateClient();
        var query = await client.GetFromJsonAsync<JsonElement>("/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=2030-01-07T18:00:00Z");
        Assert.True(query.GetProperty("available").GetBoolean());
        var body = "{\"customerId\":1,\"vehicleId\":1,\"dealershipId\":1,\"serviceTypeId\":1,\"startTime\":\"2030-01-07T18:00:00Z\"}";
        Assert.Equal(HttpStatusCode.Created, (await BookingContractTests.Post(client, body)).StatusCode);
    }
}
