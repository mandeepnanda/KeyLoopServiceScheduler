using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using KeyLoopServiceScheduler.IntegrationTests.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Api;

public sealed class OpenApiContractTests
{
    [Fact]
    public async Task DevelopmentDocumentAndHealthDescribeAllThreeJourneysAndHeaders()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        var document = await client.GetFromJsonAsync<JsonElement>("/openapi/v1.json");
        var paths = document.GetProperty("paths");
        Assert.Equal(5, paths.EnumerateObject().Count());
        var responses = paths.GetProperty("/api/v1/appointments").GetProperty("post").GetProperty("responses");
        foreach (var status in new[] { "200", "201" })
        {
            Assert.True(responses.GetProperty(status).GetProperty("headers").TryGetProperty("Location", out _));
            Assert.True(responses.GetProperty(status).GetProperty("headers").TryGetProperty("X-Correlation-ID", out _));
        }
        Assert.True(document.GetProperty("components").GetProperty("schemas").TryGetProperty("Problem", out _));
        using var stream = typeof(Program).Assembly.GetManifestResourceStream("Scheduler.Contract.json")!;
        var approved = await JsonNode.ParseAsync(stream);
        var runtime = JsonNode.Parse(document.GetRawText());
        // OpenAPI serialization omits optional-parameter required:false (the standard default).
        foreach (var path in approved!["paths"]!.AsObject()) foreach (var operation in path.Value!.AsObject())
            if (operation.Value?["parameters"] is JsonArray parameters)
                foreach (var parameter in parameters) if (parameter?["required"]?.GetValue<bool>() == false) parameter.AsObject().Remove("required");
        Assert.True(JsonNode.DeepEquals(approved!["components"], runtime!["components"]), "Runtime schema components differ from the approved contract.");
        Assert.True(JsonNode.DeepEquals(approved["paths"], runtime["paths"]), "Runtime operations differ from the approved contract.");
        foreach (var endpoint in new[] { "/health/live", "/health/ready" })
        {
            var response = await client.GetAsync(endpoint);
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Single(response.Headers.GetValues("X-Correlation-ID"));
        }
    }
}
