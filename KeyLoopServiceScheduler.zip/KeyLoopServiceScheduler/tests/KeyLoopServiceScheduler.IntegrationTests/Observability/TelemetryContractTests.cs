using System.Diagnostics.Metrics;
using System.Net;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Observability;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Mock;
using KeyLoopServiceScheduler.IntegrationTests.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Observability;

[CollectionDefinition("Telemetry", DisableParallelization = true)]
public sealed class TelemetryCollection;

[Collection("Telemetry")]
public sealed class TelemetryContractTests
{
    [Fact]
    public async Task RequestsReplayAndBusinessConflictHaveLogicalDenominatorsWithoutIdentifierLabels()
    {
        var counts = new Dictionary<string, long>();
        var labels = new List<string>();
        using var listener = new MeterListener();
        listener.InstrumentPublished = (instrument, observer) => { if (instrument.Meter.Name == SchedulerTelemetry.Name) observer.EnableMeasurementEvents(instrument); };
        listener.SetMeasurementEventCallback<long>((instrument, value, tags, _) =>
        {
            counts[instrument.Name] = counts.GetValueOrDefault(instrument.Name) + value;
            foreach (var tag in tags) labels.Add(tag.Key);
        });
        listener.Start();
        using var database = new MockDatabase(TimeProvider.System);
        var booking = new BookAppointment(new MockBookingTransaction(database, TimeProvider.System), TimeProvider.System, new TimeZoneResolver());
        var request = new BookingRequest(1, 1, 1, 1, database.ExampleStart, "sensitive-key");
        await booking.ExecuteAsync(request);
        await booking.ExecuteAsync(request);
        await booking.ExecuteAsync(request with { RequestKey = "second" });
        await booking.ExecuteAsync(request with { RequestKey = "third" });
        Assert.Equal(4, counts["booking.requests"]);
        Assert.Equal(2, counts["booking.confirmations"]);
        Assert.Equal(1, counts["booking.replays"]);
        Assert.Equal(1, counts["booking.conflicts"]);
        Assert.All(labels, label => Assert.DoesNotContain(label, new[] { "dealerId", "customerId", "key", "id" }));
    }
    [Fact]
    public async Task CorrelationIsReturnedOnValidationHealthAndUnknownRoutesAndInvalidTokensAreReplaced()
    {
        using var factory = new MockModeTests.MockApiFactory();
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-Correlation-ID", "test-correlation");
        foreach (var route in new[] { "/health/live", "/api/v1/availability", "/missing" })
            Assert.Equal("test-correlation", Assert.Single((await client.GetAsync(route)).Headers.GetValues("X-Correlation-ID")));
        client.DefaultRequestHeaders.Remove("X-Correlation-ID");
        client.DefaultRequestHeaders.TryAddWithoutValidation("X-Correlation-ID", "invalid token");
        var response = await client.GetAsync("/health/live");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.NotEqual("invalid token", Assert.Single(response.Headers.GetValues("X-Correlation-ID")));
    }
}
