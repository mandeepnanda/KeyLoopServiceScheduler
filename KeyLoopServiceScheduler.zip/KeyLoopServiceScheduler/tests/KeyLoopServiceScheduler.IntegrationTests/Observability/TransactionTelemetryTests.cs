using System.Diagnostics.Metrics;
using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Application.Observability;
using KeyLoopServiceScheduler.Infrastructure.Transactions;

namespace KeyLoopServiceScheduler.IntegrationTests.Observability;

[Collection("Telemetry")]
public sealed class TransactionTelemetryTests
{
    [Fact]
    public async Task RetryAddsAttemptsAndEmitsOnlyAfterUnitDisposalWhileTechnicalFailuresAreNotConflicts()
    {
        var factory = new Factory();
        var counts = new Dictionary<string, long>();
        var disposedAtEmission = new List<bool>();
        using var listener = new MeterListener();
        listener.InstrumentPublished = (instrument, observer) => { if (instrument.Meter.Name == SchedulerTelemetry.Name) observer.EnableMeasurementEvents(instrument); };
        listener.SetMeasurementEventCallback<long>((instrument, value, _, _) =>
        {
            counts[instrument.Name] = counts.GetValueOrDefault(instrument.Name) + value;
            if (instrument.Name == "booking.attempts") disposedAtEmission.Add(factory.Units.All(unit => unit.Disposed));
        });
        listener.Start();
        var coordinator = new BookingTransactionCoordinator(factory, new Verifier(), new BookingRetryPolicy(), TimeProvider.System);
        Assert.Equal(1, await coordinator.ExecuteAsync(1, Guid.NewGuid(), (_, _) => Task.FromResult(1), default));
        SchedulerTelemetry.Booking(BookingResult.Rejected(FailureCode.BOOKING_BUSY));
        SchedulerTelemetry.Booking(BookingResult.Rejected(FailureCode.REQUEST_TIMEOUT));
        SchedulerTelemetry.Booking(BookingResult.Rejected(FailureCode.DATABASE_UNAVAILABLE));
        Assert.Equal(2, counts["booking.attempts"]);
        Assert.Equal(3, counts["booking.requests"]);
        Assert.Equal(0, counts.GetValueOrDefault("booking.conflicts"));
        Assert.Equal(2, disposedAtEmission.Count);
        Assert.All(disposedAtEmission, observed => Assert.True(observed));
    }
    private sealed class Factory : IBookingAttemptFactory
    {
        public List<Unit> Units { get; } = [];
        public IBookingAttemptUnit Create(Guid id) { var unit = new Unit(id, Units.Count == 0); Units.Add(unit); return unit; }
    }
    private sealed class Unit(Guid id, bool fail) : IBookingAttemptUnit
    {
        public bool Disposed { get; private set; }
        public Guid OperationId => id;
        public IBookingStore Store => throw new NotSupportedException("Read-only lifecycle probe");
        public bool WriteAttempted => false;
        public bool CommitStarted => false;
        public Task AcquireAsync(long dealer, BookingDeadline deadline) => fail ? throw new DealershipLockException(-3) : Task.CompletedTask;
        public Task CommitAsync(CancellationToken token) => throw new NotSupportedException("Read-only lifecycle probe");
        public Task<bool> RollbackAsync(CancellationToken token) => Task.FromResult(true);
        public ValueTask DisposeAsync() { Disposed = true; return ValueTask.CompletedTask; }
    }
    private sealed class Verifier : ICommitOutcomeVerifier
    { public Task<AppointmentProjection?> FindAsync(Guid id, CancellationToken token) => throw new NotSupportedException("No commit uncertainty in this probe"); }
}
