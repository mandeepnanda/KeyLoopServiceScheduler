using System.Diagnostics;
using KeyLoopServiceScheduler.Api.Observability;
using KeyLoopServiceScheduler.Application.Observability;
using OpenTelemetry;
using OpenTelemetry.Trace;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using KeyLoopServiceScheduler.IntegrationTests.Mock;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.FileProviders;
using System.Diagnostics.Metrics;

namespace KeyLoopServiceScheduler.IntegrationTests.Observability;

[Collection("Telemetry")]
public sealed class LoadTimingExporterTests
{
    [Fact]
    public async Task ConfiguredDevelopmentHostCapturesARealBookingWithoutSql()
    {
        var path = Path.Combine(Path.GetTempPath(), "scheduler-host-capture-" + Guid.NewGuid().ToString("N") + ".jsonl");
        try
        {
            using var factory = new CaptureFactory(path);
            using var client = factory.CreateClient();
            using var response = await Api.BookingContractTests.Post(client, await Api.BookingContractTests.SampleBody(client));
            Assert.Equal(System.Net.HttpStatusCode.Created, response.StatusCode);
            Assert.True(factory.Services.GetRequiredService<TracerProvider>().ForceFlush(2000));
            var records = File.ReadAllLines(path);
            Assert.Contains(records, record => record.Contains("\"operation\":\"booking\"", StringComparison.Ordinal));
            Assert.All(records, record => Assert.DoesNotContain("contract-key", record));
        }
        finally { if (File.Exists(path)) File.Delete(path); }
    }
    private sealed class CaptureFactory(string path) : MockModeTests.MockApiFactory
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            base.ConfigureWebHost(builder);
            builder.ConfigureAppConfiguration((_, configuration) => configuration.AddInMemoryCollection(
                new Dictionary<string, string?> { ["Telemetry:LoadCaptureFile"] = path }));
        }
    }
    [Fact]
    public void BatchCaptureRetainsMeasuredTimingsAndExcludesSensitiveFieldsAndUnknownOperations()
    {
        var path = Path.Combine(Path.GetTempPath(), "scheduler-capture-" + Guid.NewGuid().ToString("N") + ".jsonl");
        try
        {
            using var provider = Sdk.CreateTracerProviderBuilder().AddSource(SchedulerTelemetry.Name)
                .AddProcessor(new BatchActivityExportProcessor(new LoadTimingExporter(path), scheduledDelayMilliseconds: 100)).Build();
            using (var activity = SchedulerTelemetry.Activities.StartActivity("booking.db.resources"))
            {
                Assert.NotNull(activity);
                activity.SetTag("sql", "secret-sql");
                activity.AddBaggage("key", "secret-key");
                activity.AddEvent(new ActivityEvent("secret-event"));
            }
            using (SchedulerTelemetry.Activities.StartActivity("secret-operation")) { }
            Assert.True(provider.ForceFlush(2000));
            var records = File.ReadAllLines(path);
            var record = Assert.Single(records);
            Assert.Contains("booking.db.resources", record);
            Assert.Contains("durationMs", record);
            Assert.DoesNotContain("secret", record);
        }
        finally { if (File.Exists(path)) File.Delete(path); }
    }
    [Fact]
    public void CaptureFailureCannotChangeACompletedOperation()
    {
        long drops = 0;
        using var listener = new MeterListener();
        listener.InstrumentPublished = (instrument, observer) =>
        { if (instrument.Name == "telemetry.dropped") observer.EnableMeasurementEvents(instrument); };
        listener.SetMeasurementEventCallback<long>((_, value, _, _) => drops = value);
        listener.Start();
        listener.RecordObservableInstruments();
        var before = drops;
        using var provider = Sdk.CreateTracerProviderBuilder().AddSource(SchedulerTelemetry.Name)
            .AddProcessor(new BatchActivityExportProcessor(new LoadTimingExporter(Path.GetTempPath()), scheduledDelayMilliseconds: 100)).Build();
        using (SchedulerTelemetry.Activities.StartActivity("booking")) { }
        Assert.True(provider.ForceFlush(2000));
        listener.RecordObservableInstruments();
        Assert.True(drops > before);
    }
    [Fact]
    public void LocalCaptureIsRejectedOutsideDevelopment()
    {
        var services = new ServiceCollection();
        services.AddSingleton<IHostEnvironment>(new TestEnvironment());
        services.AddSchedulerOpenTelemetry(new ConfigurationBuilder().AddInMemoryCollection(
            new Dictionary<string, string?> { ["Telemetry:LoadCaptureFile"] = "should-not-exist.jsonl" }).Build());
        using var provider = services.BuildServiceProvider();
        var error = Assert.Throws<InvalidOperationException>(() => provider.GetRequiredService<TracerProvider>());
        Assert.Contains("Development-only", error.Message);
    }
    private sealed class TestEnvironment : IHostEnvironment
    {
        public string EnvironmentName { get; set; } = "Production";
        public string ApplicationName { get; set; } = "CaptureTest";
        public string ContentRootPath { get; set; } = "";
        public IFileProvider ContentRootFileProvider { get; set; } = new NullFileProvider();
    }
}
