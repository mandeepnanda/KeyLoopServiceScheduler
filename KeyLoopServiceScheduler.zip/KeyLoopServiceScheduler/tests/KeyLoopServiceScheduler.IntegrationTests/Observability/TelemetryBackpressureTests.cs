using System.Diagnostics;
using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using KeyLoopServiceScheduler.IntegrationTests.Mock;
using KeyLoopServiceScheduler.Api.Observability;
using Serilog.Events;
using Serilog.Parsing;

namespace KeyLoopServiceScheduler.IntegrationTests.Observability;

[Collection("Telemetry")]
public sealed class TelemetryBackpressureTests
{
    [Fact]
    public async Task ConfiguredLoggerEmitsSafeEphemeralStorageStartupWarning()
    {
        var records = new ConcurrentQueue<string>();
        using var sink = new BoundedLogSink(write: records.Enqueue);
        using (var factory = new StartupFactory(sink))
        using (var client = factory.CreateClient())
            Assert.True((await client.GetAsync("/health/live")).IsSuccessStatusCode);
        await sink.DrainAsync(TimeSpan.FromSeconds(2));
        var startup = Assert.Single(records.Select(text => JsonSerializer.Deserialize<JsonElement>(text)),
            record => record.TryGetProperty("operation", out var operation) && operation.GetString() == "startup");
        Assert.Equal("MOCK_STORAGE_EPHEMERAL", startup.GetProperty("reasonCode").GetString());
        Assert.Equal("Warning", startup.GetProperty("level").GetString());
        Assert.False(startup.TryGetProperty("exception", out _));
        Assert.False(startup.TryGetProperty("message", out _));
    }
    private sealed class StartupFactory(BoundedLogSink sink) : MockModeTests.MockApiFactory
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            base.ConfigureWebHost(builder);
            builder.ConfigureServices(services => { services.RemoveAll<BoundedLogSink>(); services.AddSingleton(sink); });
        }
    }
    [Fact]
    public async Task StalledSinkDropsWithoutBlockingAndProjectsOnlySafeFields()
    {
        using var entered = new ManualResetEventSlim();
        using var release = new ManualResetEventSlim();
        var written = new List<string>();
        using var sink = new BoundedLogSink(2, text => { entered.Set(); release.Wait(TimeSpan.FromSeconds(5)); lock (written) written.Add(text); });
        var record = new LogEvent(DateTimeOffset.UtcNow, LogEventLevel.Information, new Exception("secret-password"),
            new MessageTemplateParser().Parse("sensitive-body"), [new("operation", new ScalarValue("booking")), new("rawKey", new ScalarValue("secret-key"))]);
        sink.Emit(record);
        Assert.True(entered.Wait(TimeSpan.FromSeconds(2)));
        var watch = Stopwatch.StartNew();
        for (var i = 0; i < 100; i++) sink.Emit(record);
        Assert.True(watch.Elapsed < TimeSpan.FromSeconds(1));
        Assert.True(sink.Dropped > 0);
        using (var database = new KeyLoopServiceScheduler.Infrastructure.Mock.MockDatabase(TimeProvider.System))
        {
            var booking = new KeyLoopServiceScheduler.Application.Booking.BookAppointment(
                new KeyLoopServiceScheduler.Infrastructure.Mock.MockBookingTransaction(database, TimeProvider.System), TimeProvider.System,
                new KeyLoopServiceScheduler.Domain.Scheduling.TimeZoneResolver());
            Assert.Null((await booking.ExecuteAsync(new(1, 1, 1, 1, database.ExampleStart))).Failure);
        }
        release.Set();
        await sink.DrainAsync(TimeSpan.FromSeconds(2));
        Assert.NotEmpty(written);
        Assert.All(written, text => { Assert.Contains("booking", text); Assert.DoesNotContain("secret", text); Assert.DoesNotContain("sensitive-body", text); });
    }
    [Fact]
    public async Task SinkFailureIsContainedAndSubsequentRecordsCanBeProcessed()
    {
        using var sink = new BoundedLogSink(4, _ => throw new IOException("injected exporter failure"));
        var record = new LogEvent(DateTimeOffset.UtcNow, LogEventLevel.Information, null, new MessageTemplateParser().Parse("event"), []);
        sink.Emit(record);
        await sink.DrainAsync(TimeSpan.FromSeconds(2));
        Assert.True(sink.Dropped > 0);
    }
}
