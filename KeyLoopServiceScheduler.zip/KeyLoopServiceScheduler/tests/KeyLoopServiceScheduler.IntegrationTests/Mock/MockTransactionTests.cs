using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Mock;

namespace KeyLoopServiceScheduler.IntegrationTests.Mock;

public sealed class MockTransactionTests
{
    [Fact]
    public async Task ExceptionAfterStagingDiscardsTheRowAndReleasesTheGate()
    {
        using var database = new MockDatabase(TimeProvider.System);
        var transaction = new MockBookingTransaction(database, TimeProvider.System);
        var id = Guid.NewGuid();
        await Assert.ThrowsAsync<InvalidOperationException>(() => transaction.ExecuteAsync<int>(1, id, async (attempt, token) =>
        {
            await attempt.Store.AddAsync(new Appointment(id, 1, 1, 1, 1, 1, 1, database.ExampleStart, 60, DateTimeOffset.UtcNow, "discard"), token);
            throw new InvalidOperationException("Injected failure before commit");
        }, default));
        Assert.Null(await database.GetAsync(id));
        var service = new BookAppointment(transaction, TimeProvider.System, new TimeZoneResolver());
        Assert.Null((await service.ExecuteAsync(new(1, 1, 1, 1, database.ExampleStart, "after-failure"))).Failure);
    }

    [Fact]
    public async Task ConcurrentBookingsRespectCapacityAndReplayIdentity()
    {
        using var database = new MockDatabase(TimeProvider.System);
        var service = new BookAppointment(new MockBookingTransaction(database, TimeProvider.System), TimeProvider.System, new TimeZoneResolver());
        var request = new BookingRequest(1, 1, 1, 1, database.ExampleStart, "shared");
        var replays = await Task.WhenAll(Enumerable.Range(0, 8).Select(_ => Task.Run(() => service.ExecuteAsync(request))));
        Assert.All(replays, result => Assert.Null(result.Failure));
        Assert.Single(replays.Select(result => result.Appointment!.Id).Distinct());
        var competitors = await Task.WhenAll(Enumerable.Range(0, 8).Select(index => Task.Run(() => service.ExecuteAsync(request with { RequestKey = "competitor-" + index }))));
        Assert.Single(competitors, result => result.Failure is null);
        Assert.Equal(7, competitors.Count(result => result.Failure?.Code == FailureCode.TECHNICIAN_UNAVAILABLE));
    }
}
