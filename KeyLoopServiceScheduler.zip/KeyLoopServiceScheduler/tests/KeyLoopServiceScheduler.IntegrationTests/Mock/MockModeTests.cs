using System.Net;
using System.Net.Http.Json;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace KeyLoopServiceScheduler.IntegrationTests.Mock;

public sealed class MockModeTests
{
    [Fact]
    public async Task MockHostStartsWithoutSqlAndPublishesSeedManifest()
    {
        using var factory = new MockApiFactory();
        using var client = factory.CreateClient();
        var manifest = await client.GetFromJsonAsync<Manifest>("/demo");
        Assert.NotNull(manifest);
        Assert.Equal("Mock", manifest.Mode);
        Assert.Contains("restart", manifest.Notice, StringComparison.OrdinalIgnoreCase);
        Assert.True(manifest.ExampleBooking.StartTime > DateTimeOffset.UtcNow);
        Assert.Equal(HttpStatusCode.BadRequest, (await client.GetAsync("/api/v1/availability")).StatusCode);
    }

    [Fact]
    public async Task BookingRetrievalReplayAndConflictUseSharedMockState()
    {
        using var factory = new MockApiFactory();
        using var client = factory.CreateClient();
        var manifest = (await client.GetFromJsonAsync<Manifest>("/demo"))!;
        Assert.True((await client.GetFromJsonAsync<AvailabilityBody>(manifest.AvailabilityUrl))!.Available);
        var firstResponse = await client.PostAsJsonAsync("/demo/appointments", manifest.ExampleBooking);
        Assert.True(firstResponse.StatusCode == HttpStatusCode.Created, await firstResponse.Content.ReadAsStringAsync());
        var first = (await firstResponse.Content.ReadFromJsonAsync<AppointmentProjection>())!;
        Assert.Equal(first, await client.GetFromJsonAsync<AppointmentProjection>(firstResponse.Headers.Location));
        var replay = await client.PostAsJsonAsync("/demo/appointments", manifest.ExampleBooking);
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        Assert.Equal(first, await replay.Content.ReadFromJsonAsync<AppointmentProjection>());
        Assert.Equal(HttpStatusCode.Conflict, (await client.PostAsJsonAsync("/demo/appointments",
            manifest.ExampleBooking with { VehicleId = 2 })).StatusCode);
        Assert.Equal(HttpStatusCode.Created, (await client.PostAsJsonAsync("/demo/appointments",
            manifest.ExampleBooking with { RequestKey = "second" })).StatusCode);
        var conflict = await client.PostAsJsonAsync("/demo/appointments", manifest.ExampleBooking with { RequestKey = "third" });
        Assert.Equal(HttpStatusCode.Conflict, conflict.StatusCode);
        Assert.Equal("TECHNICIAN_UNAVAILABLE", (await conflict.Content.ReadFromJsonAsync<ErrorBody>())!.Code);
        Assert.False((await client.GetFromJsonAsync<AvailabilityBody>(manifest.AvailabilityUrl))!.Available);
    }

    [Fact]
    public async Task SeparateHostsStartWithIndependentEphemeralData()
    {
        using var firstFactory = new MockApiFactory();
        using var firstClient = firstFactory.CreateClient();
        var manifest = (await firstClient.GetFromJsonAsync<Manifest>("/demo"))!;
        var response = await firstClient.PostAsJsonAsync("/demo/appointments", manifest.ExampleBooking);
        var saved = (await response.Content.ReadFromJsonAsync<AppointmentProjection>())!;
        using var secondFactory = new MockApiFactory();
        using var secondClient = secondFactory.CreateClient();
        Assert.Equal(HttpStatusCode.NotFound, (await secondClient.GetAsync("/demo/appointments/" + saved.Id)).StatusCode);
    }

    [Fact]
    public void MockModeRequiresExplicitDevelopmentEnvironment()
    {
        using var factory = new MockApiFactory("Production");
        var error = Assert.Throws<InvalidOperationException>(() => factory.CreateClient());
        Assert.Contains("Development", error.Message);
    }

    private sealed record Manifest(string Mode, string Notice, BookingRequest ExampleBooking, string AvailabilityUrl);
    private sealed record AvailabilityBody(bool Available);
    private sealed record ErrorBody(string Code);
    internal class MockApiFactory(string environment = "Development") : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment(environment);
            builder.ConfigureAppConfiguration((_, configuration) => configuration.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Scheduler:StorageMode"] = "Mock",
                ["ConnectionStrings:Scheduler"] = null
            }));
        }
    }
}
