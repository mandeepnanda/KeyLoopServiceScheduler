using System.Data.Common;
using System.Text.Json;
using KeyLoopServiceScheduler.Api.Bootstrap;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure;
using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;

namespace KeyLoopServiceScheduler.IntegrationTests.Persistence;

internal sealed class FixedSeedClock(DateTimeOffset now) : TimeProvider
{
    public override DateTimeOffset GetUtcNow() => now;
}

public sealed class SeedConfigurationTests
{
    private static readonly DateTimeOffset Now = new(2030, 1, 6, 0, 0, 0, TimeSpan.Zero);

    [Fact]
    public void SeedIsDeterministicDatedAndContainsBothZonesAndExceptions()
    {
        var first = SchedulerSeedData.Create(new(2030, 1, 7), new FixedSeedClock(Now));
        var second = SchedulerSeedData.Create(new(2030, 1, 7), new FixedSeedClock(Now));
        Assert.Equal(JsonSerializer.Serialize(first), JsonSerializer.Serialize(second));
        Assert.Equal(30, first.DealerWindows.Count);
        Assert.Equal(75, first.WorkingWindows.Count);
        Assert.Equal(new[] { "Asia/Kolkata", "America/New_York" }, first.Dealerships.Select(x => x.TimeZoneId));
        Assert.DoesNotContain(first.Qualifications, x => x.TechnicianId == 2 && x.ServiceTypeId == 2);
        Assert.DoesNotContain(first.Qualifications, x => x.TechnicianId == 4);
        Assert.True(first.History.StartUtc > Now);
        Assert.Equal(first.History.StartUtc.AddMinutes(60), first.History.EndUtc);
        Assert.Throws<ArgumentOutOfRangeException>(() => SchedulerSeedData.Create(new(2030, 1, 6), new FixedSeedClock(Now)));
        Assert.Throws<ArgumentOutOfRangeException>(() => SchedulerSeedData.Create(DateOnly.MaxValue, new FixedSeedClock(Now)));
    }

    [Theory]
    [InlineData("--seed-only")]
    [InlineData("--seed-base-date", "2030-01-07")]
    [InlineData("--seed-only", "--seed-base-date", "bad")]
    [InlineData("--seed-only", "--seed-only", "--seed-base-date", "2030-01-07")]
    public void InvalidSeedCommandsFailBeforeHosting(params string[] args) => Assert.Throws<ArgumentException>(() => SeedCommand.Parse(args));

    [Fact]
    public void SeedSwitchesAreRemovedFromHostConfiguration()
    {
        var parsed = SeedCommand.Parse(["--seed-only", "--seed-base-date", "2030-01-07", "--urls", "http://localhost:5010"]);
        Assert.True(parsed.SeedOnly);
        Assert.Equal(new DateOnly(2030, 1, 7), parsed.BaseDate);
        Assert.Equal(new[] { "--urls", "http://localhost:5010" }, parsed.HostArguments);
        Assert.False(SeedCommand.Parse([]).SeedOnly);
    }

    [Fact]
    public void PersistenceUsesBoundedCommandsAndNoAutomaticRetries()
    {
        var services = new ServiceCollection();
        services.AddSchedulerPersistence(SchedulerDatabaseOptions.Parse("Server=localhost;Database=ModelOnly;Integrated Security=True;Connect Timeout=3;ConnectRetryCount=0;MultipleActiveResultSets=False"));
        using var provider = services.BuildServiceProvider();
        using var scope = provider.CreateScope();
        using var context = scope.ServiceProvider.GetRequiredService<SchedulerDbContext>();
        Assert.Equal(5, context.Database.GetCommandTimeout());
        Assert.False(context.Database.CreateExecutionStrategy().RetriesOnFailure);
        Assert.False(context.Database.HasPendingModelChanges());
    }

    [Fact]
    public async Task FoundationHostHasNoBookingEndpointAndNeedsNoDatabaseAtStartup()
    {
        using var factory = new SchedulerApiFactory("Server=localhost;Database=ModelOnly;Integrated Security=True;Connect Timeout=3;ConnectRetryCount=0;MultipleActiveResultSets=False", Now);
        using var client = factory.CreateClient();
        Assert.Equal(System.Net.HttpStatusCode.NotFound, (await client.GetAsync("/appointments/" + SchedulerSeedData.HistoryId)).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.NotFound, (await client.PostAsync("/appointments", new StringContent("{}"))).StatusCode);
    }

    [Fact]
    public async Task SeedCommandRejectsPastDateBeforeOpeningDatabase()
    {
        var services = new ServiceCollection();
        services.AddSchedulerPersistence(SchedulerDatabaseOptions.Parse("Server=localhost;Database=ModelOnly;Integrated Security=True;Connect Timeout=3;ConnectRetryCount=0;MultipleActiveResultSets=False"));
        services.AddSingleton<TimeProvider>(new FixedSeedClock(Now));
        await using var provider = services.BuildServiceProvider();
        var command = SeedCommand.Parse(["--seed-only", "--seed-base-date", "2030-01-06"]);
        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => command.ExecuteAsync(provider));
    }
}

public sealed class SeedAndQueryTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    private async Task SeedAsync()
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), new FixedSeedClock(database.Now));
    }

    [SqlFact]
    public async Task RepeatSeedIsNoOpDifferentBaseDateFailsWithoutChanges()
    {
        await SeedAsync();
        await using var context = database.CreateContext();
        var before = await context.Appointments.AsNoTracking().Select(x => new { x.Id, x.StartUtc, x.EndUtc, x.CreatedUtc }).ToListAsync();
        await SchedulerSeedData.ApplyAsync(context, new(2030, 1, 7), new FixedSeedClock(database.Now));
        await Assert.ThrowsAsync<InvalidOperationException>(() => SchedulerSeedData.ApplyAsync(context, new(2030, 1, 8), new FixedSeedClock(database.Now)));
        var after = await context.Appointments.AsNoTracking().Select(x => new { x.Id, x.StartUtc, x.EndUtc, x.CreatedUtc }).ToListAsync();
        Assert.Equal(JsonSerializer.Serialize(before), JsonSerializer.Serialize(after));
        Assert.Equal(30, await context.DealershipOperatingWindows.CountAsync());
    }

    [SqlFact]
    public async Task ExplicitSeedCommandUsesFixedClockAndPreservesExistingHistory()
    {
        await database.ResetAsync();
        var services = new ServiceCollection();
        services.AddSchedulerPersistence(SchedulerDatabaseOptions.Parse(database.ConnectionString));
        services.AddSingleton<TimeProvider>(new FixedSeedClock(database.Now));
        await using var provider = services.BuildServiceProvider();
        var command = SeedCommand.Parse(["--seed-only", "--seed-base-date", "2030-01-07"]);
        await command.ExecuteAsync(provider);
        await command.ExecuteAsync(provider);
        await using var context = database.CreateContext();
        var saved = Assert.Single(await context.Appointments.AsNoTracking().ToListAsync());
        Assert.Equal(SchedulerSeedData.HistoryId, saved.Id);
        Assert.Equal(database.Now, saved.CreatedUtc);
    }

    [SqlFact]
    public async Task PartialReferenceDataIsRejectedWithoutAddingRows()
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        context.Customers.Add(new Customer(1, "Sample customer one"));
        await context.SaveChangesAsync();
        await Assert.ThrowsAsync<InvalidOperationException>(() => SchedulerSeedData.ApplyAsync(context,
            new(2030, 1, 7), new FixedSeedClock(database.Now)));
        Assert.Equal(1, await context.Customers.CountAsync());
        Assert.Equal(0, await context.Dealerships.CountAsync());
        Assert.Equal(0, await context.Appointments.CountAsync());
    }

    [SqlFact]
    public async Task BatchedReadsAreUntrackedOrderedAndHalfOpenIncludingEarlierWindows()
    {
        await SeedAsync();
        await using (var admin = database.CreateContext())
        {
            admin.DealershipOperatingWindows.Add(new(9999, 1, new(2030, 1, 6, 23, 0, 0), new(2030, 1, 7, 10, 0, 0)));
            admin.TechnicianWorkingWindows.Add(new(9999, 1, new(2030, 1, 6, 23, 0, 0), new(2030, 1, 7, 10, 0, 0)));
            await admin.SaveChangesAsync();
        }
        var counter = new CommandCounter();
        await using var context = new SchedulerDbContext(new DbContextOptionsBuilder<SchedulerDbContext>()
            .UseSqlServer(database.ConnectionString, x => x.UseCompatibilityLevel(160).CommandTimeout(5))
            .AddInterceptors(counter).Options);
        var before = await context.Appointments.CountAsync();
        var saved = await new AppointmentReader(context).GetAsync(SchedulerSeedData.HistoryId);
        Assert.NotNull(saved);
        Assert.Equal((1L, 1L, 1L, 1L, 1L, 1L), (saved.CustomerId, saved.VehicleId, saved.DealershipId, saved.ServiceTypeId, saved.TechnicianId, saved.ServiceBayId));
        Assert.Null(await new AppointmentReader(context).GetAsync(Guid.NewGuid()));
        var queries = new ResourceQueries(context);
        counter.Commands.Clear();
        var adjacent = await queries.ReadAsync(1, 1, new AppointmentInterval(saved.EndTime, saved.EndTime.AddMinutes(60)));
        Assert.Equal(6, counter.Commands.Count);
        Assert.All(adjacent.Technicians, x => Assert.Empty(x.Bookings));
        Assert.Equal(new long[] { 1, 2 }, adjacent.Technicians.Select(x => x.Id));
        Assert.Contains(counter.Commands, sql => sql.Contains("[StartUtc] < @", StringComparison.Ordinal) && sql.Contains("[EndUtc] > @", StringComparison.Ordinal));
        var overlapping = await queries.ReadAsync(1, 1, new AppointmentInterval(saved.StartTime, saved.EndTime));
        Assert.Single(overlapping.Technicians.Single(x => x.Id == 1).Bookings);
        Assert.Single(overlapping.Bays.Single(x => x.Id == 1).Bookings);
        Assert.Contains(overlapping.DealerWindows, x => x.LocalStart.Date == new DateTime(2030, 1, 6));
        Assert.Contains(overlapping.Technicians.Single(x => x.Id == 1).WorkingWindows, x => x.LocalStart.Date == new DateTime(2030, 1, 6));
        var diagnostics = await queries.ReadAsync(1, 2, new AppointmentInterval(saved.EndTime, saved.EndTime.AddMinutes(30)));
        Assert.Equal(1L, Assert.Single(diagnostics.Technicians).Id);
        Assert.All(counter.Commands, sql => Assert.DoesNotContain("INSERT", sql, StringComparison.OrdinalIgnoreCase));
        Assert.Empty(context.ChangeTracker.Entries());
        Assert.Equal(before, await context.Appointments.CountAsync());
        await using (var admin = database.CreateContext())
        {
            for (long id = 10; id < 60; id++)
            {
                admin.Technicians.Add(new(id, 1, null));
                admin.TechnicianQualifications.Add(new(id, 1));
                admin.ServiceBays.Add(new(id, 1, null));
            }
            await admin.SaveChangesAsync();
        }
        counter.Commands.Clear();
        var many = await queries.ReadAsync(1, 1, new AppointmentInterval(saved.EndTime, saved.EndTime.AddMinutes(60)));
        Assert.Equal(6, counter.Commands.Count);
        Assert.Equal(52, many.Technicians.Count);
        Assert.Equal(many.Technicians.Select(x => x.Id).Order(), many.Technicians.Select(x => x.Id));
        Assert.Empty(context.ChangeTracker.Entries());
    }

    private sealed class CommandCounter : DbCommandInterceptor
    {
        public List<string> Commands { get; } = [];
        public override ValueTask<InterceptionResult<DbDataReader>> ReaderExecutingAsync(DbCommand command,
            CommandEventData eventData, InterceptionResult<DbDataReader> result, CancellationToken cancellationToken = default)
        {
            Commands.Add(command.CommandText);
            return ValueTask.FromResult(result);
        }
    }
}
