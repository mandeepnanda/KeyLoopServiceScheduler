using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;

namespace KeyLoopServiceScheduler.IntegrationTests.Persistence;

public sealed class SchemaModelTests
{
    private static SchedulerDbContext Context() => new(new DbContextOptionsBuilder<SchedulerDbContext>()
        .UseSqlServer("Server=localhost;Database=ModelOnly;Integrated Security=True;ConnectRetryCount=0;Connect Timeout=3").Options);

    [Fact]
    public void GeneratedSqlContainsDurationEqualityAndOwnershipQualificationBackstops()
    {
        using var context = Context();
        var sql = context.Database.GenerateCreateScript();
        Assert.Contains("EndUtc] = DATEADD(minute, [DurationMinutes], [StartUtc])", sql);
        Assert.Contains("FOREIGN KEY ([VehicleId], [CustomerId])", sql);
        Assert.Contains("FOREIGN KEY ([TechnicianId], [ServiceTypeId])", sql);
        Assert.Contains("FOREIGN KEY ([TechnicianId], [DealershipId])", sql);
        Assert.Contains("FOREIGN KEY ([ServiceBayId], [DealershipId])", sql);
        Assert.Contains("WHERE [RequestKey] IS NOT NULL", sql);
        Assert.Contains("Latin1_General_100_BIN2", sql);
    }

    [Fact]
    public void RequiredFieldsAndExactLengthsRemainInTheModel()
    {
        using var context = Context();
        var model = context.GetService<IDesignTimeModel>().Model;
        var appointment = model.FindEntityType(typeof(Appointment))!;
        foreach (var property in appointment.GetProperties().Where(p => p.Name != nameof(Appointment.RequestKey)))
            Assert.False(property.IsNullable);
        Assert.True(appointment.FindProperty(nameof(Appointment.RequestKey))!.IsNullable);
        Assert.Equal(128, appointment.FindProperty(nameof(Appointment.RequestKey))!.GetMaxLength());
        Assert.Equal(16, appointment.FindProperty(nameof(Appointment.Status))!.GetMaxLength());
        Assert.Equal(7, appointment.FindProperty(nameof(Appointment.StartUtc))!.GetPrecision());
        Assert.Equal(200, model.FindEntityType(typeof(Dealership))!.FindProperty(nameof(Dealership.Name))!.GetMaxLength());
        Assert.Equal(100, model.FindEntityType(typeof(Dealership))!.FindProperty(nameof(Dealership.TimeZoneId))!.GetMaxLength());
        foreach (var type in new[] { typeof(DealershipOperatingWindow), typeof(TechnicianWorkingWindow) })
            Assert.All(model.FindEntityType(type)!.GetProperties(), property => Assert.False(property.IsNullable));
        Assert.All(model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()), fk => Assert.Equal(DeleteBehavior.Restrict, fk.DeleteBehavior));
    }

    [Fact]
    public void IndexesCoverQualificationReplayWindowsAndBothResourceOverlaps()
    {
        using var context = Context();
        var sql = context.Database.GenerateCreateScript();
        Assert.Contains("([TechnicianId], [StartUtc]) INCLUDE ([EndUtc], [Status]) WHERE [Status] = 'Confirmed'", sql);
        Assert.Contains("([ServiceBayId], [StartUtc]) INCLUDE ([EndUtc], [Status]) WHERE [Status] = 'Confirmed'", sql);
        Assert.Contains("UNIQUE INDEX [UX_Appointment_Dealer_RequestKey]", sql);
        Assert.Contains("([ServiceTypeId], [TechnicianId])", sql);
        Assert.Contains("([DealershipId], [LocalStart]) INCLUDE ([LocalEnd])", sql);
        Assert.Contains("([TechnicianId], [LocalStart]) INCLUDE ([LocalEnd])", sql);
    }
}

public sealed class SchemaConstraintTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    private async Task SeedAsync()
    {
        await database.ResetAsync();
        await using var context = database.CreateContext();
        await SchedulerSeedData.ApplyAsync(context, new DateOnly(2030, 1, 7), new FixedSeedClock(database.Now));
    }

    [SqlTheory]
    [InlineData("Id")]
    [InlineData("CustomerId")]
    [InlineData("VehicleId")]
    [InlineData("DealershipId")]
    [InlineData("ServiceTypeId")]
    [InlineData("TechnicianId")]
    [InlineData("ServiceBayId")]
    [InlineData("StartUtc")]
    [InlineData("EndUtc")]
    [InlineData("DurationMinutes")]
    [InlineData("Status")]
    [InlineData("CreatedUtc")]
    public async Task RequiredAppointmentColumnsRejectNull(string column)
    {
        await SeedAsync();
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?> { [column] = null }));
    }

    [SqlTheory]
    [InlineData("Status", "Pending")]
    [InlineData("Status", "confirmed")]
    [InlineData("Status", "Confirmed ")]
    [InlineData("RequestKey", "")]
    [InlineData("RequestKey", "a b")]
    [InlineData("RequestKey", "é")]
    public async Task InvalidStateOrKeyIsRejected(string column, string value)
    {
        await SeedAsync();
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?> { [column] = value }));
    }

    [SqlTheory]
    [InlineData("CustomerId", 999)]
    [InlineData("VehicleId", 2)]
    [InlineData("TechnicianId", 3)]
    [InlineData("ServiceBayId", 3)]
    [InlineData("DurationMinutes", 0)]
    [InlineData("DurationMinutes", -1)]
    public async Task InvalidRelationshipsOrDurationAreRejected(string column, int value)
    {
        await SeedAsync();
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?> { [column] = value }));
    }

    [SqlFact]
    public async Task UnqualifiedTechnicianCannotBeAssigned()
    {
        await SeedAsync();
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(
            new Dictionary<string, object?> { ["TechnicianId"] = 2L, ["ServiceTypeId"] = 2L }));
    }

    [SqlFact]
    public async Task EndDurationMismatchAndOverflowAreRejected()
    {
        await SeedAsync();
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?>
        { ["EndUtc"] = new DateTimeOffset(2030, 1, 7, 5, 0, 0, TimeSpan.Zero) }));
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?>
        { ["StartUtc"] = DateTimeOffset.MaxValue.AddTicks(-1), ["EndUtc"] = DateTimeOffset.MaxValue, ["DurationMinutes"] = 1 }));
    }

    [SqlFact]
    public async Task ValidHundredNanosecondIntervalPersists()
    {
        await SeedAsync();
        var id = Guid.NewGuid();
        Assert.Equal(1, await database.InsertAppointmentAsync(new Dictionary<string, object?> { ["Id"] = id }));
        await using var context = database.CreateContext();
        var saved = await context.Appointments.AsNoTracking().SingleAsync(x => x.Id == id);
        Assert.Equal(1, saved.StartUtc.Ticks % TimeSpan.TicksPerSecond);
        Assert.Equal(saved.StartUtc.AddMinutes(60), saved.EndUtc);
    }

    [SqlFact]
    public async Task RequiredScheduleColumnsRejectNull()
    {
        await SeedAsync();
        foreach (var (table, parent) in new[] { ("DealershipOperatingWindow", "DealershipId"), ("TechnicianWorkingWindow", "TechnicianId") })
            foreach (var column in new[] { "Id", parent, "LocalStart", "LocalEnd" })
            {
                var fields = new Dictionary<string, string>
                { ["Id"] = "999999", [parent] = "1", ["LocalStart"] = "'2030-01-07T09:00:00'", ["LocalEnd"] = "'2030-01-07T17:00:00'" };
                fields[column] = "NULL";
                await Assert.ThrowsAsync<SqlException>(() => database.ExecuteAsync(
                    $"INSERT INTO [{table}] ({string.Join(",", fields.Keys.Select(f => $"[{f}]"))}) VALUES ({string.Join(",", fields.Values)})"));
            }
    }

    [SqlFact]
    public async Task KeyUniquenessIsDealerScopedCaseSensitiveAndAllowsAbsentKeys()
    {
        await SeedAsync();
        var key = "schema-" + Guid.NewGuid().ToString("N");
        Assert.Equal(1, await database.InsertAppointmentAsync(new Dictionary<string, object?> { ["RequestKey"] = key }));
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?> { ["RequestKey"] = key }));
        Assert.Equal(1, await database.InsertAppointmentAsync(new Dictionary<string, object?> { ["RequestKey"] = key.ToUpperInvariant() }));
        Assert.Equal(1, await database.InsertAppointmentAsync(new Dictionary<string, object?>
        { ["RequestKey"] = key, ["DealershipId"] = 2L, ["TechnicianId"] = 3L, ["ServiceBayId"] = 3L }));
        Assert.Equal(1, await database.InsertAppointmentAsync());
        Assert.Equal(1, await database.InsertAppointmentAsync());
    }

    [SqlFact]
    public async Task PositiveIdsLengthsBoundsUtcAndRestrictedDeletesAreEnforced()
    {
        await SeedAsync();
        await using var context = database.CreateContext();
        var before = await context.Appointments.CountAsync();
        foreach (var sql in new[]
        {
            "INSERT INTO Customer(Id) VALUES(0)",
            "INSERT INTO Customer(Id,DisplayName) VALUES(999,REPLICATE(N'x',201))",
            "INSERT INTO Vehicle(Id,CustomerId,Description) VALUES(999,1,REPLICATE(N'x',201))",
            "INSERT INTO Dealership(Id,Name,TimeZoneId) VALUES(999,REPLICATE(N'x',201),N'UTC')",
            "INSERT INTO Dealership(Id,Name,TimeZoneId) VALUES(999,N'x',REPLICATE(N'x',101))",
            "INSERT INTO ServiceType(Id,Name,DurationMinutes) VALUES(999,REPLICATE(N'x',101),60)",
            "INSERT INTO ServiceType(Id,Name,DurationMinutes) VALUES(999,N'x',0)",
            "INSERT INTO Technician(Id,DealershipId,DisplayName) VALUES(999,1,REPLICATE(N'x',201))",
            "INSERT INTO ServiceBay(Id,DealershipId,Name) VALUES(999,1,REPLICATE(N'x',101))",
            "INSERT INTO DealershipOperatingWindow(Id,DealershipId,LocalStart,LocalEnd) VALUES(999,1,'2030-01-07','2030-01-07')",
            "INSERT INTO TechnicianWorkingWindow(Id,TechnicianId,LocalStart,LocalEnd) VALUES(999,1,'2030-01-08','2030-01-07')",
            "DELETE FROM Customer WHERE Id=1",
            "DELETE FROM TechnicianQualification WHERE TechnicianId=1 AND ServiceTypeId=1"
        }) await Assert.ThrowsAsync<SqlException>(() => database.ExecuteAsync(sql));
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?>
        { ["CreatedUtc"] = database.Now.ToOffset(TimeSpan.FromHours(1)) }));
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?>
        { ["RequestKey"] = new string('x', 129) }));
        Assert.Equal(before, await context.Appointments.CountAsync());
    }

    [SqlTheory]
    [InlineData("StartUtc")]
    [InlineData("EndUtc")]
    [InlineData("CreatedUtc")]
    public async Task AllPersistedInstantsMustHaveZeroOffset(string column)
    {
        await SeedAsync();
        var start = new DateTimeOffset(2030, 1, 7, 4, 30, 0, TimeSpan.Zero).AddTicks(1);
        var value = column == "EndUtc" ? start.AddMinutes(60) : column == "CreatedUtc" ? database.Now : start;
        await Assert.ThrowsAsync<SqlException>(() => database.InsertAppointmentAsync(new Dictionary<string, object?>
        { [column] = value.ToOffset(TimeSpan.FromHours(1)) }));
    }
}
