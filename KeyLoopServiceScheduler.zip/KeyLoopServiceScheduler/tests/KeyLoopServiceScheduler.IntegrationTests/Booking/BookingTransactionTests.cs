using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingTransactionTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlFact]
    public async Task CompleteConfirmationReplayMismatchAndFreshReaderPreserveSavedRow()
    {
        await BookingScenario.SeedAsync(database, false);
        var request = BookingScenario.Request("durable-key");
        var first = await BookingScenario.Service(database).ExecuteAsync(request);
        Assert.Null(first.Failure);
        Assert.False(first.IsReplay);
        var replay = await BookingScenario.Service(database).ExecuteAsync(request with { StartTime = request.StartTime.ToOffset(TimeSpan.FromHours(5.5)) });
        Assert.True(replay.IsReplay);
        Assert.Equal(first.Appointment, replay.Appointment);
        var mismatch = await BookingScenario.Service(database).ExecuteAsync(request with { VehicleId = 2 });
        Assert.Equal(FailureCode.KEY_PAYLOAD_MISMATCH, mismatch.Failure!.Code);
        await using var fresh = database.CreateContext();
        Assert.Equal(first.Appointment, await new AppointmentReader(fresh).GetAsync(first.Appointment!.Id));
        Assert.Equal(2, await fresh.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
    }

    [SqlFact]
    public async Task FailedKeyHasNoDurableBindingAndAllowsCorrectedRequest()
    {
        await BookingScenario.SeedAsync(database);
        var service = BookingScenario.Service(database);
        var request = BookingScenario.Request("failed-key");
        Assert.Equal(FailureCode.VEHICLE_CUSTOMER_MISMATCH, (await service.ExecuteAsync(request with { VehicleId = 2 })).Failure!.Code);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
        Assert.Null((await service.ExecuteAsync(request)).Failure);
        Assert.Equal(1, await context.Appointments.CountAsync());
    }
}
