using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingAcceptanceTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData("customer", FailureCode.UNKNOWN_CUSTOMER)]
    [InlineData("vehicle", FailureCode.UNKNOWN_VEHICLE)]
    [InlineData("dealer", FailureCode.UNKNOWN_DEALERSHIP)]
    [InlineData("service", FailureCode.UNKNOWN_SERVICE_TYPE)]
    [InlineData("ownership", FailureCode.VEHICLE_CUSTOMER_MISMATCH)]
    [InlineData("hours", FailureCode.DEALERSHIP_CLOSED)]
    [InlineData("qualification", FailureCode.NO_QUALIFIED_TECHNICIAN)]
    [InlineData("technician", FailureCode.TECHNICIAN_UNAVAILABLE)]
    [InlineData("bay", FailureCode.BAY_UNAVAILABLE)]
    [InlineData("past", FailureCode.INVALID_START_TIME)]
    [InlineData("zone", FailureCode.INVALID_REFERENCE_CONFIGURATION)]
    public async Task ValidationAndUnavailableScenariosHaveStableReasonsAndZeroRows(string scenario, FailureCode expected)
    {
        await BookingScenario.SeedAsync(database);
        var request = BookingScenario.Request("acceptance-key");
        request = scenario switch
        {
            "customer" => request with { CustomerId = 999 },
            "vehicle" => request with { VehicleId = 999 },
            "dealer" => request with { DealershipId = 999 },
            "service" => request with { ServiceTypeId = 999 },
            "ownership" => request with { VehicleId = 2 },
            "past" => request with { StartTime = database.Now },
            _ => request
        };
        if (scenario == "hours") await database.ExecuteAsync("DELETE FROM DealershipOperatingWindow WHERE DealershipId=1");
        if (scenario == "qualification") await database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId IN(1,2)");
        if (scenario == "technician") await database.ExecuteAsync("DELETE FROM TechnicianWorkingWindow WHERE TechnicianId IN(1,2)");
        if (scenario == "bay") await database.ExecuteAsync("DELETE FROM ServiceBay WHERE DealershipId=1");
        if (scenario == "zone") await database.ExecuteAsync("UPDATE Dealership SET TimeZoneId=N'not/a-zone' WHERE Id=1");
        var result = await BookingScenario.Service(database).ExecuteAsync(request);
        Assert.Equal(expected, result.Failure!.Code);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
    }

    [SqlFact]
    public async Task AlternatePairAdjacencyServiceCompatibilityAndRetainedReplayUseSavedResults()
    {
        await BookingScenario.SeedAsync(database);
        var request = BookingScenario.Request("first");
        var service = BookingScenario.Service(database);
        var first = await service.ExecuteAsync(request);
        Assert.Equal((1L, 1L), (first.Appointment!.TechnicianId, first.Appointment.ServiceBayId));
        var second = await service.ExecuteAsync(request with { RequestKey = "second" });
        Assert.Equal((2L, 2L), (second.Appointment!.TechnicianId, second.Appointment.ServiceBayId));
        var unavailable = await service.ExecuteAsync(request with { RequestKey = "third", StartTime = request.StartTime.AddMinutes(30) });
        Assert.Equal(FailureCode.TECHNICIAN_UNAVAILABLE, unavailable.Failure!.Code);
        var adjacent = await service.ExecuteAsync(request with { RequestKey = "adjacent", StartTime = first.Appointment.EndTime, ServiceTypeId = 2 });
        Assert.Null(adjacent.Failure);
        Assert.Equal(30, adjacent.Appointment!.DurationMinutes);
        Assert.Equal((1L, 1L), (adjacent.Appointment.TechnicianId, adjacent.Appointment.ServiceBayId));
        var options = BookingScenario.Options(database);
        var future = new FixedTimeProvider(database.Now.AddDays(5));
        var later = new BookAppointment(new BookingTransactionCoordinator(new BookingAttemptFactory(options, new DealershipApplicationLock()),
            new CommitOutcomeVerifier(options), new BookingRetryPolicy(), future), future, new TimeZoneResolver());
        var replay = await later.ExecuteAsync(request);
        Assert.True(replay.IsReplay);
        Assert.Equal(first.Appointment, replay.Appointment);
        await using var fresh = database.CreateContext();
        Assert.Equal(first.Appointment, await new AppointmentReader(fresh).GetAsync(first.Appointment.Id));
        Assert.Equal(3, await fresh.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
    }

    [SqlTheory]
    [InlineData(6, 0, FailureCode.TECHNICIAN_UNAVAILABLE)]
    [InlineData(11, 0, FailureCode.DEALERSHIP_CLOSED)]
    public async Task FullIntervalRejectsShiftGapOrEndAfterClosing(int utcHour, int utcMinute, FailureCode expected)
    {
        await BookingScenario.SeedAsync(database);
        await database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1");
        var request = BookingScenario.Request() with { StartTime = new(2030, 1, 7, utcHour, utcMinute, 0, TimeSpan.Zero) };
        Assert.Equal(expected, (await BookingScenario.Service(database).ExecuteAsync(request)).Failure!.Code);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
    }

    [SqlTheory]
    [InlineData(3, 10, -5, 2)]
    [InlineData(11, 3, -4, 1)]
    public async Task DstBoundaryWindowIsExcludedUnaffectedWindowCanCoverElapsedService(int month, int day, int offset, int invalidHour)
    {
        await BookingScenario.SeedAsync(database);
        await using var context = database.CreateContext();
        var date = new DateTime(2030, month, day);
        context.DealershipOperatingWindows.Add(new(9001, 2, date.AddHours(invalidHour).AddMinutes(30), date.AddHours(4)));
        context.TechnicianWorkingWindows.Add(new(9001, 3, date, date.AddHours(4)));
        await context.SaveChangesAsync();
        var request = BookingScenario.Request(dealer: 2) with { StartTime = new(2030, month, day, 1, 30, 0, TimeSpan.FromHours(offset)), RequestKey = "dst" };
        Assert.Equal(FailureCode.DEALERSHIP_CLOSED, (await BookingScenario.Service(database).ExecuteAsync(request)).Failure!.Code);
        context.DealershipOperatingWindows.Add(new(9002, 2, date, date.AddHours(4)));
        await context.SaveChangesAsync();
        var result = await BookingScenario.Service(database).ExecuteAsync(request);
        Assert.Null(result.Failure);
        Assert.Equal(request.StartTime.ToUniversalTime().AddMinutes(60), result.Appointment!.EndTime);
        var replay = await BookingScenario.Service(database).ExecuteAsync(request with { StartTime = request.StartTime.ToUniversalTime() });
        Assert.Equal(result.Appointment, replay.Appointment);
    }
}
