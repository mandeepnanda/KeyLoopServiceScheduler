using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingRecoveryTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData(BookingFaultPoint.BeforeSave)]
    [InlineData(BookingFaultPoint.BeforeCommit)]
    public async Task RealRollbackRemovesBothAssignmentsAndKey(BookingFaultPoint point)
    {
        await BookingScenario.SeedAsync(database);
        var faults = Faults(point);
        var result = await BookingScenario.Service(database, faults).ExecuteAsync(BookingScenario.Request("rollback"));
        Assert.Equal(FailureCode.INTERNAL_ERROR, result.Failure!.Code);
        Assert.Equal(PersistenceOutcome.NotCommitted, result.Failure.Outcome);
        Assert.Equal(1, faults.Created);
        Assert.Equal(1, faults.Disposed);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
        Assert.Null((await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("rollback"))).Failure);
    }

    [SqlTheory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task RealCommitFollowedBySimulatedAcknowledgementLossIsRecoveredOrReportedUnknown(bool verifierFails)
    {
        await BookingScenario.SeedAsync(database);
        var faults = Faults(BookingFaultPoint.AfterActualCommit);
        var result = await BookingScenario.Service(database, faults, verifierFails ? new FailingVerifier() : null)
            .ExecuteAsync(BookingScenario.Request("lost-ack"));
        if (verifierFails) Assert.Equal(FailureCode.BOOKING_OUTCOME_UNKNOWN, result.Failure!.Code);
        else Assert.Null(result.Failure);
        Assert.Equal(1, faults.Created);
        Assert.Equal(1, faults.Disposed);
        await using var context = database.CreateContext();
        Assert.Equal(1, await context.Appointments.CountAsync());
        var replay = await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("lost-ack"));
        Assert.True(replay.IsReplay);
        Assert.Equal((await context.Appointments.SingleAsync()).Id, replay.Appointment!.Id);
        await BookingScenario.AssertAtomicNoOverlapAsync(context);
    }

    [SqlFact]
    public async Task LockAndStoresUseOneReadCommittedConnectionAndTransaction()
    {
        await BookingScenario.SeedAsync(database);
        var probe = new ConnectionProbe();
        var factory = new BookingAttemptFactory(BookingScenario.Options(database), probe);
        var coordinator = new BookingTransactionCoordinator(factory, new CommitOutcomeVerifier(BookingScenario.Options(database)), new BookingRetryPolicy(), new FixedTimeProvider(database.Now));
        var id = Guid.NewGuid();
        var result = await coordinator.ExecuteAsync(1, id, async (attempt, token) =>
        {
            var context = Assert.IsType<SchedulerDbContext>(probe.Context);
            Assert.Same(probe.Transaction, context.Database.CurrentTransaction!.GetDbTransaction());
            var refs = await attempt.Store.ReadReferencesAsync(1, 1, 1, 1, token);
            Assert.NotNull(refs.Customer);
            await attempt.Store.AddAsync(new(id, 1, 1, 1, 1, 1, 1, BookingScenario.Request().StartTime, 60, database.Now), token);
            Assert.Equal(id, Assert.Single(context.Appointments.Local).Id);
            Assert.Same(probe.Connection, context.Database.GetDbConnection());
            return id;
        }, CancellationToken.None);
        Assert.Equal(id, result);
        await using var fresh = database.CreateContext();
        Assert.Equal(1, await fresh.Appointments.CountAsync());
    }

    private BookingFaultDecorator Faults(BookingFaultPoint point) => new(new BookingAttemptFactory(BookingScenario.Options(database), new DealershipApplicationLock()), point);

    [SqlTheory]
    [InlineData(-1, FailureCode.BOOKING_BUSY)]
    [InlineData(-2, FailureCode.REQUEST_TIMEOUT)]
    [InlineData(-999, FailureCode.INVALID_REFERENCE_CONFIGURATION)]
    public async Task InjectedNegativeLockCodesRollBackRealTransactionsBeforeDelegate(int code, FailureCode expected)
    {
        await BookingScenario.SeedAsync(database);
        var scripted = new ScriptedLock(code);
        var factory = new BookingAttemptFactory(BookingScenario.Options(database), scripted);
        var result = await BookingScenario.Service(database, factory).ExecuteAsync(BookingScenario.Request("negative"));
        Assert.Equal(expected, result.Failure!.Code);
        Assert.Equal(System.Data.ConnectionState.Closed, Assert.Single(scripted.Connections).State);
        await using var context = database.CreateContext();
        Assert.Equal(0, await context.Appointments.CountAsync());
    }

    [SqlFact]
    public async Task InjectedDeadlockResultRetriesOnlyAfterDisposingRealAttemptWithFreshContext()
    {
        await BookingScenario.SeedAsync(database);
        var scripted = new ScriptedLock(-3);
        var factory = new BookingAttemptFactory(BookingScenario.Options(database), scripted);
        var result = await BookingScenario.Service(database, factory).ExecuteAsync(BookingScenario.Request("retry"));
        Assert.Null(result.Failure);
        Assert.Equal(2, scripted.Contexts.Count);
        Assert.NotSame(scripted.Contexts[0], scripted.Contexts[1]);
        Assert.NotSame(scripted.Connections[0], scripted.Connections[1]);
        Assert.All(scripted.Connections, connection => Assert.Equal(System.Data.ConnectionState.Closed, connection.State));
        await using var fresh = database.CreateContext();
        Assert.Equal(1, await fresh.Appointments.CountAsync());
    }

    private sealed class ScriptedLock(int firstCode) : IDealershipApplicationLock
    {
        public List<SchedulerDbContext> Contexts { get; } = [];
        public List<System.Data.Common.DbConnection> Connections { get; } = [];
        public async Task AcquireAsync(SchedulerDbContext context, long dealershipId, BookingDeadline deadline)
        {
            Assert.All(Connections, connection => Assert.Equal(System.Data.ConnectionState.Closed, connection.State));
            Contexts.Add(context); Connections.Add(context.Database.GetDbConnection());
            if (Contexts.Count == 1) throw new DealershipLockException(firstCode);
            await new DealershipApplicationLock().AcquireAsync(context, dealershipId, deadline);
        }
    }
    private sealed class FailingVerifier : ICommitOutcomeVerifier
    {
        public Task<AppointmentProjection?> FindAsync(Guid operationId, CancellationToken cancellationToken) => throw new IOException("Test-only verification failure");
    }
    private sealed class ConnectionProbe : IDealershipApplicationLock
    {
        public SchedulerDbContext? Context { get; private set; }
        public System.Data.Common.DbConnection? Connection { get; private set; }
        public System.Data.Common.DbTransaction? Transaction { get; private set; }
        public async Task AcquireAsync(SchedulerDbContext context, long dealershipId, BookingDeadline deadline)
        {
            Context = context; Connection = context.Database.GetDbConnection(); Transaction = context.Database.CurrentTransaction!.GetDbTransaction();
            Assert.Equal(System.Data.IsolationLevel.ReadCommitted, Transaction.IsolationLevel);
            await new DealershipApplicationLock().AcquireAsync(context, dealershipId, deadline);
        }
    }
}
