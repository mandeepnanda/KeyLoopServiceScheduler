using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingRaceReviewTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task WaitingOverlapRechecksAfterUncommittedInsertCommitsOrRollsBack(bool rollback)
    {
        await RestrictToOnePairAsync();
        var gate = new CommitGateFactory(BookingScenario.Options(database), rollback);
        var waitingLock = new ObservedLock();
        var waitingFactory = new BookingAttemptFactory(BookingScenario.Options(database), waitingLock);
        using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        var first = BookingScenario.Service(database, gate).ExecuteAsync(BookingScenario.Request("first"), budget.Token);
        Task<BookingResult>? second = null;
        try
        {
            // SaveChanges has finished, but the real SQL transaction and application lock remain held.
            await gate.BeforeCommit.Task.WaitAsync(budget.Token);
            second = BookingScenario.Service(database, waitingFactory).ExecuteAsync(
                BookingScenario.Request("second") with { StartTime = BookingScenario.Request().StartTime.AddMinutes(15) }, budget.Token);
            // The contender has opened a separate context/transaction and entered the real lock call.
            await waitingLock.Attempting.Task.WaitAsync(budget.Token);
        }
        finally
        {
            gate.Release.TrySetResult();
            // Always drain started operations before the fixture can drop its database.
            await first.WaitAsync(TimeSpan.FromSeconds(15));
            if (second is not null) await second.WaitAsync(TimeSpan.FromSeconds(15));
        }

        var firstResult = await first;
        var secondResult = await second!;
        Assert.NotSame(gate.Context, waitingLock.Context);
        Assert.NotNull(gate.Context);
        Assert.NotNull(waitingLock.Context);
        Assert.NotNull(gate.Connection);
        Assert.NotNull(waitingLock.Connection);
        Assert.NotSame(gate.Connection, waitingLock.Connection);
        if (rollback)
        {
            Assert.Equal(FailureCode.INTERNAL_ERROR, firstResult.Failure!.Code);
            Assert.Equal(PersistenceOutcome.NotCommitted, firstResult.Failure.Outcome);
            Assert.Null(secondResult.Failure);
        }
        else
        {
            Assert.Null(firstResult.Failure);
            Assert.Equal(FailureCode.TECHNICIAN_UNAVAILABLE, secondResult.Failure!.Code);
        }

        // A third context reads committed state, rather than either attempt's tracked entities.
        await using var fresh = database.CreateContext();
        var saved = Assert.Single(await fresh.Appointments.AsNoTracking().ToListAsync());
        Assert.Equal(rollback ? "second" : "first", saved.RequestKey);
        Assert.Equal(rollback ? secondResult.Appointment!.Id : firstResult.Appointment!.Id, saved.Id);
        await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
        if (rollback)
        {
            Assert.False(await fresh.Appointments.AnyAsync(row => row.Id == gate.OperationId || row.RequestKey == "first"));
            var corrected = await BookingScenario.Service(database).ExecuteAsync(
                BookingScenario.Request("first") with { StartTime = BookingScenario.Request().StartTime.AddHours(2) });
            Assert.Null(corrected.Failure);
            Assert.False(corrected.IsReplay);
            Assert.Equal(2, await fresh.Appointments.CountAsync());
            await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
        }
    }

    [SqlFact]
    public async Task SimultaneousAdjacentBookingsShareOnePairWithoutOverlap()
    {
        await RestrictToOnePairAsync();
        var start = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        async Task<BookingResult> Submit(BookingRequest request)
        {
            await start.Task;
            return await BookingScenario.Service(database).ExecuteAsync(request, budget.Token);
        }
        var first = BookingScenario.Request("adjacent-first");
        var tasks = new[] { Submit(first), Submit(first with { RequestKey = "adjacent-second", StartTime = first.StartTime.AddMinutes(60) }) };
        start.SetResult();
        var results = await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(25));
        Assert.All(results, result => Assert.Null(result.Failure));
        Assert.NotEqual(results[0].Appointment!.Id, results[1].Appointment!.Id);
        await using var fresh = database.CreateContext();
        var rows = await fresh.Appointments.AsNoTracking().OrderBy(row => row.StartUtc).ToListAsync();
        Assert.Equal(2, rows.Count);
        Assert.Equal(rows[0].EndUtc, rows[1].StartUtc);
        Assert.Equal(rows[0].TechnicianId, rows[1].TechnicianId);
        Assert.Equal(rows[0].ServiceBayId, rows[1].ServiceBayId);
        await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
    }

    private async Task RestrictToOnePairAsync()
    {
        await BookingScenario.SeedAsync(database);
        await database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1");
        await database.ExecuteAsync("DELETE FROM ServiceBay WHERE Id=2");
    }

    private sealed class ObservedLock : IDealershipApplicationLock
    {
        public TaskCompletionSource Attempting { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public SchedulerDbContext? Context { get; private set; }
        public System.Data.Common.DbConnection? Connection { get; private set; }
        public Task AcquireAsync(SchedulerDbContext context, long dealershipId, BookingDeadline deadline)
        {
            Context = context;
            Connection = context.Database.GetDbConnection();
            var acquiring = new DealershipApplicationLock().AcquireAsync(context, dealershipId, deadline);
            Attempting.TrySetResult();
            return acquiring;
        }
    }

    private sealed class CommitGateFactory(SchedulerDatabaseOptions options, bool rollback) : IBookingAttemptFactory
    {
        public TaskCompletionSource BeforeCommit { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public SchedulerDbContext? Context { get; private set; }
        public System.Data.Common.DbConnection? Connection { get; private set; }
        public Guid OperationId { get; private set; }
        public IBookingAttemptUnit Create(Guid operationId)
        {
            OperationId = operationId;
            // Capture the context via an observed real lock, without replacing SQL locking or storage.
            var observed = new ObservedLock();
            var unit = new BookingAttemptFactory(options, observed).Create(operationId);
            return new GatedUnit(unit, this, observed, rollback);
        }

        private sealed class GatedUnit(IBookingAttemptUnit innerUnit, CommitGateFactory gate, ObservedLock observed, bool rollback) : IBookingAttemptUnit
        {
            public Guid OperationId => innerUnit.OperationId;
            public IBookingStore Store => innerUnit.Store;
            public bool WriteAttempted => innerUnit.WriteAttempted;
            public bool CommitStarted => innerUnit.CommitStarted;
            public Task AcquireAsync(long dealershipId, BookingDeadline deadline) => innerUnit.AcquireAsync(dealershipId, deadline);
            public async Task CommitAsync(CancellationToken cancellationToken)
            {
                gate.Context = observed.Context;
                gate.Connection = observed.Connection;
                gate.BeforeCommit.TrySetResult();
                await gate.Release.Task.WaitAsync(cancellationToken);
                if (rollback) throw new InvalidOperationException("Test-only failure after save and before commit.");
                await innerUnit.CommitAsync(cancellationToken);
            }
            public Task<bool> RollbackAsync(CancellationToken cancellationToken) => innerUnit.RollbackAsync(cancellationToken);
            public ValueTask DisposeAsync() => innerUnit.DisposeAsync();
        }
    }
}
