using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingConcurrencyTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData("pair", FailureCode.TECHNICIAN_UNAVAILABLE)]
    [InlineData("technician", FailureCode.TECHNICIAN_UNAVAILABLE)]
    [InlineData("bay", FailureCode.BAY_UNAVAILABLE)]
    public async Task IndependentConnectionsCannotConfirmCompetingSharedResources(string variant, FailureCode expected)
    {
        await BookingScenario.SeedAsync(database);
        if (variant != "bay") await database.ExecuteAsync("DELETE FROM TechnicianQualification WHERE TechnicianId=2 AND ServiceTypeId=1");
        if (variant != "technician") await database.ExecuteAsync("DELETE FROM ServiceBay WHERE Id=2");
        var request = BookingScenario.Request();
        var outcomes = await RaceAsync(request, request with { StartTime = request.StartTime.AddMinutes(15) });
        Assert.Single(outcomes, x => x.Appointment is not null);
        Assert.Equal(expected, Assert.Single(outcomes, x => x.Failure is not null).Failure!.Code);
        await using var context = database.CreateContext();
        Assert.Equal(1, await context.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(context);
    }

    [SqlTheory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task SameKeyRacesBindOnceWithSparePairsOrRejectChangedPayload(bool changed)
    {
        await BookingScenario.SeedAsync(database);
        var request = BookingScenario.Request("race-key");
        var outcomes = await RaceAsync(request, changed ? request with { StartTime = request.StartTime.AddTicks(1) } : request);
        if (changed)
        {
            Assert.Single(outcomes, x => x.Appointment is not null);
            Assert.Equal(FailureCode.KEY_PAYLOAD_MISMATCH, Assert.Single(outcomes, x => x.Failure is not null).Failure!.Code);
        }
        else
        {
            Assert.All(outcomes, x => Assert.Null(x.Failure));
            Assert.Equal(outcomes[0].Appointment!.Id, outcomes[1].Appointment!.Id);
            Assert.Single(outcomes, x => x.IsReplay);
        }
        await using var context = database.CreateContext();
        Assert.Equal(1, await context.Appointments.CountAsync());
    }

    [SqlTheory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task DistinctKeysUseSparePairsAndSameKeyAtSeparateDealersIsIndependent(bool separateDealers)
    {
        await BookingScenario.SeedAsync(database);
        var outcomes = await RaceAsync(BookingScenario.Request("one"),
            separateDealers ? BookingScenario.Request("one", 2) : BookingScenario.Request("two"));
        Assert.All(outcomes, x => Assert.Null(x.Failure));
        Assert.NotEqual(outcomes[0].Appointment!.Id, outcomes[1].Appointment!.Id);
        await using var context = database.CreateContext();
        Assert.Equal(2, await context.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(context);
    }

    private async Task<BookingResult[]> RaceAsync(BookingRequest first, BookingRequest second)
    {
        var start = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        async Task<BookingResult> Run(BookingRequest request)
        {
            await start.Task;
            // Each coordinator creates independent connection/context/transaction attempts.
            return await BookingScenario.Service(database).ExecuteAsync(request);
        }
        var tasks = new[] { Run(first), Run(second) };
        start.SetResult();
        return await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(25));
    }
}
