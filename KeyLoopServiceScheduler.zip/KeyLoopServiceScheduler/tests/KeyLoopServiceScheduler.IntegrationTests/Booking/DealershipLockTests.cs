using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class DealershipLockTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlFact]
    public async Task HeldLockProducesFiniteBusyOtherDealerProceedsAndRollbackReleasesLock()
    {
        await BookingScenario.SeedAsync(database);
        await using var holder = database.CreateContext();
        await holder.Database.OpenConnectionAsync();
        await using var transaction = await holder.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadCommitted);
        using var deadline = new BookingDeadline(TimeProvider.System, CancellationToken.None);
        await new DealershipApplicationLock().AcquireAsync(holder, 1, deadline);
        var busy = await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("blocked"))
            .WaitAsync(TimeSpan.FromSeconds(15));
        Assert.Equal(FailureCode.BOOKING_BUSY, busy.Failure!.Code);
        Assert.Equal(PersistenceOutcome.NotCommitted, busy.Failure.Outcome);
        Assert.Equal(0, await holder.Appointments.CountAsync());
        var other = await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("other", 2));
        Assert.Null(other.Failure);
        await transaction.RollbackAsync();
        await transaction.DisposeAsync();
        Assert.Null((await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("blocked"))).Failure);
        await using var fresh = database.CreateContext();
        Assert.Equal(2, await fresh.Appointments.CountAsync());
        await BookingScenario.AssertAtomicNoOverlapAsync(fresh);
    }
}
