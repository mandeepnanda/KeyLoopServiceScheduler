using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.IntegrationTests.Fixtures;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

public sealed class BookingCancellationTests(SqlDatabaseFixture database) : IClassFixture<SqlDatabaseFixture>
{
    [SqlTheory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task CancellationBeforeCommitRollsBackAndAfterActualCommitDoesNotClaimRollback(bool afterActualCommit)
    {
        await BookingScenario.SeedAsync(database);
        using var cancel = new CancellationTokenSource();
        var factory = new CancelFactory(new BookingAttemptFactory(BookingScenario.Options(database), new DealershipApplicationLock()), cancel, afterActualCommit);
        var result = await BookingScenario.Service(database, factory).ExecuteAsync(BookingScenario.Request("cancel-key"), cancel.Token);
        Assert.Equal(afterActualCommit ? FailureCode.BOOKING_OUTCOME_UNKNOWN : FailureCode.REQUEST_TIMEOUT, result.Failure!.Code);
        Assert.Equal(afterActualCommit ? PersistenceOutcome.Unknown : PersistenceOutcome.NotCommitted, result.Failure.Outcome);
        await using var context = database.CreateContext();
        Assert.Equal(afterActualCommit ? 1 : 0, await context.Appointments.CountAsync());
        var retry = await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("cancel-key"));
        Assert.Null(retry.Failure);
        Assert.Equal(afterActualCommit, retry.IsReplay);
    }
    private sealed class CancelFactory(IBookingAttemptFactory inner, CancellationTokenSource cancel, bool after) : IBookingAttemptFactory
    {
        public IBookingAttemptUnit Create(Guid id) => new CancelUnit(inner.Create(id), cancel, after);
    }
    private sealed class CancelUnit(IBookingAttemptUnit inner, CancellationTokenSource cancel, bool after) : IBookingAttemptUnit
    {
        public Guid OperationId => inner.OperationId;
        public KeyLoopServiceScheduler.Application.Abstractions.IBookingStore Store => inner.Store;
        public bool WriteAttempted => inner.WriteAttempted;
        public bool CommitStarted => inner.CommitStarted;
        public Task AcquireAsync(long dealer, BookingDeadline deadline) => inner.AcquireAsync(dealer, deadline);
        public async Task CommitAsync(CancellationToken token)
        {
            if (!after) { cancel.Cancel(); await inner.CommitAsync(token); return; }
            await inner.CommitAsync(token);
            cancel.Cancel();
            throw new IOException("Test-only cancellation after acknowledged SQL commit; simulates loss before coordinator receives it.");
        }
        public Task<bool> RollbackAsync(CancellationToken token) => inner.RollbackAsync(token);
        public ValueTask DisposeAsync() => inner.DisposeAsync();
    }
    [SqlFact]
    public async Task CancellationDuringHeldLockWaitLeavesNoRowAndLaterBookingCanProceed()
    {
        await BookingScenario.SeedAsync(database);
        await using var holder = database.CreateContext();
        await holder.Database.OpenConnectionAsync();
        await using var transaction = await holder.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadCommitted);
        using var deadline = new BookingDeadline(TimeProvider.System, default);
        await new DealershipApplicationLock().AcquireAsync(holder, 1, deadline);
        using var cancel = new CancellationTokenSource(TimeSpan.FromMilliseconds(250));
        var result = await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("cancelled"), cancel.Token).WaitAsync(TimeSpan.FromSeconds(15));
        Assert.Equal(FailureCode.REQUEST_TIMEOUT, result.Failure!.Code);
        Assert.Equal(PersistenceOutcome.NotCommitted, result.Failure.Outcome);
        Assert.Equal(0, await holder.Appointments.CountAsync());
        await transaction.RollbackAsync();
        await transaction.DisposeAsync();
        Assert.Null((await BookingScenario.Service(database).ExecuteAsync(BookingScenario.Request("cancelled"))).Failure);
    }
}
