using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using KeyLoopServiceScheduler.Infrastructure;
using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Application.Booking;

namespace KeyLoopServiceScheduler.IntegrationTests.Booking;

/// <summary>Lifecycle policy tests with fake units. These do not establish SQL atomicity or concurrency.</summary>
public sealed class BookingCoordinatorTests
{
    [Theory]
    [InlineData(-1, FailureCode.BOOKING_BUSY, 1)]
    [InlineData(-2, FailureCode.REQUEST_TIMEOUT, 1)]
    [InlineData(-3, FailureCode.DATABASE_UNAVAILABLE, 2)]
    [InlineData(-999, FailureCode.INVALID_REFERENCE_CONFIGURATION, 1)]
    public async Task EveryNegativeLockOutcomeAbortsDelegateAndDisposes(int code, FailureCode expected, int attempts)
    {
        var factory = new FakeFactory { LockFailure = code };
        var verifier = new FakeVerifier();
        var coordinator = Coordinator(factory, verifier);
        var calls = 0;
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => coordinator.ExecuteAsync(1, Guid.NewGuid(),
            (_, _) => { calls++; return Task.FromResult(1); }, CancellationToken.None));
        Assert.Equal(expected, error.Failure.Code);
        Assert.Equal(PersistenceOutcome.NotCommitted, error.Failure.Outcome);
        Assert.Equal(0, calls);
        Assert.Equal(attempts, factory.Units.Count);
        Assert.All(factory.Units, x => Assert.True(x.Disposed));
        Assert.Equal(0, verifier.Calls);
    }

    [Fact]
    public async Task KnownRollbackRetriesWholeDelegateOnceOnFreshDisposedUnitWithSameGuid()
    {
        var factory = new FakeFactory();
        var id = Guid.NewGuid();
        var calls = 0;
        var result = await Coordinator(factory, new()).ExecuteAsync(1, id, async (unit, token) =>
        {
            await unit.Store.AddAsync(Row(id), token);
            if (++calls == 1) throw new TestTransientException();
            return id;
        }, CancellationToken.None);
        Assert.Equal(id, result);
        Assert.Equal(2, calls);
        Assert.Equal(2, factory.Units.Count);
        Assert.All(factory.Units, unit => { Assert.True(unit.Disposed); Assert.Equal(id, unit.OperationId); });
        Assert.True(factory.Units[0].RolledBack);
        Assert.True(factory.Units[1].Committed);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task AmbiguousCommitVerifiesOnceAfterDisposalAndNeverReinserts(bool found)
    {
        var factory = new FakeFactory { CommitFailure = true };
        var id = Guid.NewGuid();
        var verifier = new FakeVerifier { Saved = found ? AppointmentProjection.From(Row(id)) : null, Factory = factory };
        var task = Coordinator(factory, verifier).ExecuteAsync(1, id, async (unit, token) => { await unit.Store.AddAsync(Row(id), token); return id; }, CancellationToken.None);
        if (found) Assert.Equal(id, (await Assert.ThrowsAsync<CommitRecoveredException>(() => task)).Appointment.Id);
        else
        {
            var failure = await Assert.ThrowsAsync<BookingTransactionException>(() => task);
            Assert.Equal(FailureCode.BOOKING_OUTCOME_UNKNOWN, failure.Failure.Code);
            Assert.Equal(PersistenceOutcome.Unknown, failure.Failure.Outcome);
        }
        Assert.Single(factory.Units);
        Assert.Equal(1, verifier.Calls);
        Assert.False(factory.Units[0].RolledBack);
    }

    [Fact]
    public async Task ExhaustedCommitBudgetNeverStartsVerification()
    {
        var clock = new ManualClock();
        var factory = new FakeFactory { CommitFailure = true, OnCommit = () => clock.Elapsed = TimeSpan.FromSeconds(11) };
        var verifier = new FakeVerifier();
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => new BookingTransactionCoordinator(factory, verifier, new FakeRetry(), clock)
            .ExecuteAsync(1, Guid.NewGuid(), async (unit, token) => { await unit.Store.AddAsync(Row(unit.OperationId), token); return 1; }, CancellationToken.None));
        Assert.Equal(FailureCode.BOOKING_OUTCOME_UNKNOWN, error.Failure.Code);
        Assert.Equal(0, verifier.Calls);
    }

    [Fact]
    public async Task CancelledRequestNeverBeginsAttempt()
    {
        var factory = new FakeFactory();
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => Coordinator(factory, new())
            .ExecuteAsync(1, Guid.NewGuid(), (_, _) => Task.FromResult(1), new CancellationToken(true)));
        Assert.Equal(FailureCode.REQUEST_TIMEOUT, error.Failure.Code);
        Assert.Empty(factory.Units);
    }

    [Fact]
    public void CanonicalLockResourceUsesInvariantPositiveBigintAndDifferentDealersDiffer()
    {
        Assert.Equal("scheduler:dealership:9223372036854775807", DealershipApplicationLock.ResourceName(long.MaxValue));
        Assert.NotEqual(DealershipApplicationLock.ResourceName(1), DealershipApplicationLock.ResourceName(2));
        Assert.Throws<ArgumentOutOfRangeException>(() => DealershipApplicationLock.ResourceName(0));
        var retry = new BookingRetryPolicy();
        Assert.False(retry.IsTransient(new InvalidOperationException()));
        Assert.False(retry.IsTransient(new DealershipLockException(-1)));
        Assert.True(retry.IsTransient(new DealershipLockException(-3)));
        Assert.InRange(retry.Jitter.TotalMilliseconds, 100, 250);
        Assert.Throws<InvalidOperationException>(() => KeyLoopServiceScheduler.Infrastructure.Configuration.SchedulerDatabaseOptions.Parse(
            "Server=localhost;Database=ModelOnly;Integrated Security=True;ApplicationIntent=ReadOnly;ConnectRetryCount=0;Connect Timeout=3"));
    }

    [Fact]
    public async Task FailedRollbackAfterWritesNeverRetriesOrClaimsNotCommitted()
    {
        var factory = new FakeFactory { RollbackFails = true };
        var verifier = new FakeVerifier();
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => Coordinator(factory, verifier).ExecuteAsync<int>(1, Guid.NewGuid(),
            async (unit, token) => { await unit.Store.AddAsync(Row(unit.OperationId), token); throw new TestTransientException(); }, CancellationToken.None));
        Assert.Equal(FailureCode.BOOKING_OUTCOME_UNKNOWN, error.Failure.Code);
        Assert.Equal(PersistenceOutcome.Unknown, error.Failure.Outcome);
        Assert.Single(factory.Units);
        Assert.Equal(0, verifier.Calls);
    }

    [Fact]
    public async Task ReadOnlyBusinessOutcomeRollsBackWithoutCommitOrRetry()
    {
        var factory = new FakeFactory();
        var result = await Coordinator(factory, new()).ExecuteAsync(1, Guid.NewGuid(), (_, _) => Task.FromResult("BAY_UNAVAILABLE"), CancellationToken.None);
        Assert.Equal("BAY_UNAVAILABLE", result);
        var unit = Assert.Single(factory.Units);
        Assert.True(unit.RolledBack);
        Assert.False(unit.CommitStarted);
        Assert.True(unit.Disposed);
    }

    [Fact]
    public async Task AttemptPortsAreUnavailableBeforeLockAndStoreRejectsDifferentDealerOrOperationBeforeSql()
    {
        var options = KeyLoopServiceScheduler.Infrastructure.Configuration.SchedulerDatabaseOptions.Parse(
            "Server=localhost;Database=ModelOnly;Integrated Security=True;ConnectRetryCount=0;Connect Timeout=3");
        await using var unit = new BookingAttemptFactory(options, new DealershipApplicationLock()).Create(Guid.NewGuid());
        Assert.Throws<InvalidOperationException>(() => { _ = unit.Store; });
        await using var context = new SchedulerDbContext(new DbContextOptionsBuilder<SchedulerDbContext>().UseSqlServer(options.ConnectionString).Options);
        var writes = 0;
        var store = new BookingStore(context, 1, Guid.NewGuid(), () => writes++);
        await Assert.ThrowsAsync<InvalidOperationException>(() => store.FindConfirmedAsync(2, "key", CancellationToken.None));
        await Assert.ThrowsAsync<InvalidOperationException>(() => store.AddAsync(Row(Guid.NewGuid()), CancellationToken.None));
        Assert.Equal(0, writes);
        Assert.Empty(context.ChangeTracker.Entries());
    }

    [Fact]
    public async Task RetryIsLimitedToTwoTotalAttemptsEvenWhenBothFailuresAreTransient()
    {
        var factory = new FakeFactory();
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => Coordinator(factory, new()).ExecuteAsync<int>(1, Guid.NewGuid(),
            async (unit, token) => { await unit.Store.AddAsync(Row(unit.OperationId), token); throw new TestTransientException(); }, CancellationToken.None));
        Assert.Equal(FailureCode.DATABASE_UNAVAILABLE, error.Failure.Code);
        Assert.Equal(2, factory.Units.Count);
        Assert.All(factory.Units, unit => Assert.True(unit.RolledBack && unit.Disposed));
    }

    [Fact]
    public async Task CallerCancellationAfterSaveUsesIndependentCleanupAndNeverCommits()
    {
        var factory = new FakeFactory();
        using var caller = new CancellationTokenSource();
        var error = await Assert.ThrowsAsync<BookingTransactionException>(() => Coordinator(factory, new()).ExecuteAsync(1, Guid.NewGuid(),
            async (unit, token) => { await unit.Store.AddAsync(Row(unit.OperationId), token); caller.Cancel(); return 1; }, caller.Token));
        Assert.Equal(FailureCode.REQUEST_TIMEOUT, error.Failure.Code);
        Assert.Equal(PersistenceOutcome.NotCommitted, error.Failure.Outcome);
        var unit = Assert.Single(factory.Units);
        Assert.True(unit.RolledBack);
        Assert.False(unit.CleanupCancelledAtEntry);
        Assert.False(unit.CommitStarted);
    }

    [Fact]
    public void SharedMonotonicDeadlineCapsLockWaitAndHasIndependentCleanupTimer()
    {
        var clock = new ManualClock();
        using var deadline = new BookingDeadline(clock, CancellationToken.None);
        Assert.Equal(TimeSpan.FromSeconds(10), deadline.Remaining);
        Assert.Equal(2000, deadline.LockWaitMilliseconds);
        clock.Elapsed = TimeSpan.FromMilliseconds(9500);
        Assert.Equal(500, deadline.LockWaitMilliseconds);
        using var cleanup = deadline.CleanupToken();
        Assert.True(cleanup.Token.CanBeCanceled);
        Assert.False(cleanup.Token.IsCancellationRequested);
        clock.Elapsed = TimeSpan.FromSeconds(10);
        Assert.False(deadline.CanStartWork);
        Assert.Equal(0, deadline.LockWaitMilliseconds);
    }

    [Fact]
    public void ProductionCompositionValidatesLifetimesAndDoesNotRegisterFaultDecorator()
    {
        var services = new ServiceCollection();
        services.AddSchedulerPersistence(KeyLoopServiceScheduler.Infrastructure.Configuration.SchedulerDatabaseOptions.Parse(
            "Server=localhost;Database=ModelOnly;Integrated Security=True;ConnectRetryCount=0;Connect Timeout=3"));
        using var provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true, ValidateOnBuild = true });
        Assert.Throws<InvalidOperationException>(() => provider.GetRequiredService<BookAppointment>());
        using var scope = provider.CreateScope();
        Assert.IsType<BookAppointment>(scope.ServiceProvider.GetRequiredService<BookAppointment>());
        Assert.IsType<QueryAvailability>(scope.ServiceProvider.GetRequiredService<QueryAvailability>());
        Assert.IsType<BookingAttemptFactory>(scope.ServiceProvider.GetRequiredService<IBookingAttemptFactory>());
        Assert.IsType<BookingTransactionCoordinator>(scope.ServiceProvider.GetRequiredService<IBookingTransaction>());
    }

    private static BookingTransactionCoordinator Coordinator(FakeFactory factory, FakeVerifier verifier) => new(factory, verifier, new FakeRetry(), TimeProvider.System);
    private static Appointment Row(Guid id) => new(id, 1, 1, 1, 1, 1, 1, new(2030, 1, 7, 4, 30, 0, TimeSpan.Zero), 60, DateTimeOffset.UtcNow);
    private sealed class TestTransientException : Exception;
    private sealed class FakeRetry : IBookingRetryPolicy
    {
        public TimeSpan Jitter => TimeSpan.FromMilliseconds(100);
        public bool IsTransient(Exception exception) => exception is TestTransientException or DealershipLockException { Result: -3 };
    }
    private sealed class ManualClock : TimeProvider
    {
        public TimeSpan Elapsed { get; set; }
        public override long TimestampFrequency => TimeSpan.TicksPerSecond;
        public override long GetTimestamp() => Elapsed.Ticks;
    }
    private sealed class FakeFactory : IBookingAttemptFactory
    {
        public List<FakeUnit> Units { get; } = [];
        public int? LockFailure { get; init; }
        public bool CommitFailure { get; init; }
        public bool RollbackFails { get; init; }
        public Action? OnCommit { get; init; }
        public IBookingAttemptUnit Create(Guid operationId)
        {
            Assert.All(Units, x => Assert.True(x.Disposed));
            var unit = new FakeUnit(operationId, this);
            Units.Add(unit);
            return unit;
        }
    }
    private sealed class FakeVerifier : ICommitOutcomeVerifier
    {
        public AppointmentProjection? Saved { get; init; }
        public FakeFactory? Factory { get; init; }
        public int Calls { get; private set; }
        public Task<AppointmentProjection?> FindAsync(Guid operationId, CancellationToken cancellationToken)
        {
            Calls++;
            if (Factory is not null) Assert.All(Factory.Units, x => Assert.True(x.Disposed));
            return Task.FromResult(Saved);
        }
    }
    private sealed class FakeUnit(Guid id, FakeFactory factory) : IBookingAttemptUnit, IBookingStore
    {
        public Guid OperationId => id;
        public IBookingStore Store => this;
        public bool WriteAttempted { get; private set; }
        public bool CommitStarted { get; private set; }
        public bool Committed { get; private set; }
        public bool RolledBack { get; private set; }
        public bool Disposed { get; private set; }
        public bool CleanupCancelledAtEntry { get; private set; }
        public Task AcquireAsync(long dealershipId, BookingDeadline deadline)
        { if (factory.LockFailure is int code) throw new DealershipLockException(code); return Task.CompletedTask; }
        public Task CommitAsync(CancellationToken cancellationToken)
        {
            CommitStarted = true;
            factory.OnCommit?.Invoke();
            if (factory.CommitFailure) throw new IOException("Simulated acknowledgement loss; no real SQL commit in this policy test.");
            Committed = true;
            return Task.CompletedTask;
        }
        public Task<bool> RollbackAsync(CancellationToken cancellationToken)
        {
            CleanupCancelledAtEntry = cancellationToken.IsCancellationRequested;
            RolledBack = !factory.RollbackFails;
            return Task.FromResult(!factory.RollbackFails);
        }
        public ValueTask DisposeAsync() { Disposed = true; return ValueTask.CompletedTask; }
        public Task AddAsync(Appointment appointment, CancellationToken cancellationToken) { WriteAttempted = true; return Task.CompletedTask; }
        public Task<AppointmentProjection?> FindConfirmedAsync(long dealershipId, string requestKey, CancellationToken cancellationToken) => throw new NotSupportedException();
        public Task<BookingReferences> ReadReferencesAsync(long customerId, long vehicleId, long dealershipId, long serviceTypeId, CancellationToken cancellationToken) => throw new NotSupportedException();
        public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken) => throw new NotSupportedException();
    }
}
