﻿# Keyloop Unified Service Scheduler — System Design

As of 2026-10-10. This document describes the implemented system. Source delivery does not establish final acceptance: real SQL concurrency, durability, recovery and performance verification remain open. Proposed extensions are explicitly identified below.

## 1. Business context and problem

Dealership customers need reliable service appointments for their existing vehicles. A confirmation must reserve a qualified technician and a service bay at the selected dealership for the entire service interval. Concurrent callers must not receive overlapping reservations for either resource. Availability informs a customer’s choice; only a committed booking confirms capacity.

The delivered scope is a REST backend with booking, retrieval and provisional availability. Business intent and acceptance rules are in the [specification](../specs/001-service-scheduler/spec.md).

## 2. Mandatory requirements and assumptions

**Mandatory:** validate references and vehicle ownership; derive the end from the configured service duration; enforce dealership and technician hours, qualification and locality; assign both resources atomically; exclude overlaps; persist confirmed appointments; support retrieval and safe concurrent requests. Errors, operational telemetry and verification evidence must be explicit.

**Documented assumptions:** reference data is seeded and immutable while serving; durations are positive elapsed minutes without buffers; every bay supports every service; selection uses the lowest eligible numeric technician and bay IDs. Hours are dated local windows interpreted in the dealership’s named time zone. Windows with ambiguous or nonexistent boundary times are excluded. Intervals are half-open `[start,end)`, so adjacent bookings are permitted. Optional request keys are case-sensitive, dealership-scoped and retained with the appointment. Cancellation, rescheduling and calendar administration are outside this scope.

## 3. Architecture

```mermaid
flowchart TB
    Client[HTTP client] --> API[ASP.NET Core API]
    API --> App[Application use cases]
    App --> Domain[Domain eligibility and interval policies]
    App --> Ports[Transaction and persistence ports]
    Infra[Infrastructure adapters] -. implements .-> Ports
    API --> Infra
    Infra --> SQL[(SQL Server primary)]
    Infra --> Mock[Development-only ephemeral store]
    API --> Obs[Bounded Serilog and OpenTelemetry]
    App --> Obs
    Infra --> Obs
```

One deployable modular monolith contains four projects. Application depends on Domain; Infrastructure implements Application ports; API composes the system. Application has no EF Core or SQL dependency. SQL Server is the default storage mode; Mock is an explicitly gated Development alternative, without durability or cross-instance guarantees.

## 4. Component responsibilities

| Component | Responsibility |
|---|---|
| API | Strict JSON/query/header validation, HTTP mapping, Problem Details, correlation, health and Development OpenAPI. |
| Application | Booking, availability and retrieval orchestration; replay semantics and logical outcome telemetry. |
| Domain | Full-interval schedule coverage, time-zone handling, qualification, conflict exclusion and deterministic selection. |
| Infrastructure | EF mappings/migrations, projected queries, attempt-bound stores, SQL locking, commit recovery and storage configuration. |
| Verification tooling | Isolated SQL fixtures, two-process tests, workload generation, sanitized timing capture and invariant inspection. |

Each SQL booking attempt owns one connection, context and transaction. All attempt-bound reads and writes use that unit; retries discard it before creating another. There is no generic repository, broker or background reservation workflow.

Configuration is validated at startup. Serving does not automatically migrate or seed SQL; migrations and `--seed-only --seed-base-date yyyy-MM-dd` are separate administrative steps. Matching repeated seeds are accepted; incompatible or partial seed state is rejected.

| Configuration | Implemented behavior |
|---|---|
| `ConnectionStrings__Scheduler` | Required externally for SQL; explicit server/database, `ApplicationIntent=ReadWrite`, `MultipleActiveResultSets=False`, `ConnectRetryCount=0`, connect timeout 1–3 seconds. |
| `Scheduler__StorageMode` | Defaults to `SqlServer`; `Mock` requires Development. |
| `Scheduler__MockBaseDate` | Optional Development fixture date in `yyyy-MM-dd` format. |
| `Telemetry__OtlpEndpoint` / `Telemetry__LoadCaptureFile` | Optional remote export / Development-only local capture. |
| `AllowedHosts` | Checked-in value `localhost;127.0.0.1`; deployment must configure intended hosts. |

## 5. Appointment booking sequence

```mermaid
sequenceDiagram
    participant C as Client
    participant A as API/Application
    participant T as SQL transaction adapter
    participant D as SQL Server
    C->>A: POST booking + optional Idempotency-Key
    A->>A: Validate syntax; generate operation GUID
    A->>T: Execute booking attempt
    T->>D: Begin ReadCommitted; acquire dealership lock
    A->>D: Lookup confirmed key using attempt store
    alt Matching existing key
        D-->>A: Original appointment
        T->>D: Commit read-only transaction; release lock
        A-->>C: 200 + Location
    else New booking
        A->>D: Read references, hours and resource conflicts
        A->>A: Validate ownership, future interval and eligibility
        A->>D: Insert appointment with both assignments
        T->>D: Commit; release lock
        A-->>C: 201 + Location
    end
    Note over T,D: On uncertain commit: dispose attempt, then one fresh GUID lookup
    Note over A,C: Recover confirmation if found; otherwise report unknown outcome
```

Key mismatch and business rejection terminate without an insert. Successful responses follow transaction completion. Availability uses the same eligibility evaluator but does not reserve capacity.

## 6. Data model

The [initial migration](../src/KeyLoopServiceScheduler.Infrastructure/Persistence/Migrations/20261009121741_InitialScheduler.cs) defines ten singular tables:

```mermaid
erDiagram
    Customer ||--o{ Vehicle : owns
    Customer ||--o{ Appointment : requests
    Vehicle ||--o{ Appointment : serviced
    Dealership ||--o{ Technician : employs
    Dealership ||--o{ ServiceBay : contains
    Dealership ||--o{ DealershipOperatingWindow : hours
    Dealership ||--o{ Appointment : hosts
    Technician ||--o{ TechnicianWorkingWindow : hours
    Technician ||--o{ TechnicianQualification : qualifications
    ServiceType ||--o{ TechnicianQualification : qualifies
    TechnicianQualification ||--o{ Appointment : permits
    ServiceType ||--o{ Appointment : service
    Technician ||--o{ Appointment : assigned
    ServiceBay ||--o{ Appointment : assigned
```

Reference entities use seeded `bigint` IDs; Appointment uses an application-generated `uniqueidentifier`. Qualification has a composite technician/service primary key. Windows store `LocalStart`/`LocalEnd` as `datetime2(7)`; Dealership stores its named zone.

| Reference data | Principal persisted attributes |
|---|---|
| Customer / Vehicle | Customer ID and optional display name; vehicle ID, required customer FK and optional description. |
| Dealership / ServiceType | Required dealership name and zone; required service name and positive integer duration. |
| Technician / ServiceBay | Required dealership FK; optional technician display name or bay name. |
| TechnicianQualification | Required technician/service FKs forming the composite key. |
| Operating / working windows | ID, required dealership/technician FK and required ordered local endpoints. |

Appointment contains customer, vehicle, dealership, service, technician and bay IDs; UTC `datetimeoffset(7)` start/end/creation; positive duration snapshot; `Confirmed` status; and nullable `varchar(128)` request key. Required assignments reside in one row, with no pending reservation state.

Composite foreign keys enforce ownership, resource locality and technician qualification. Checks enforce positive duration, UTC offsets, ordered endpoints and `EndUtc = DATEADD(minute, DurationMinutes, StartUtc)`. Deletes are restricted. A filtered unique `(DealershipId, RequestKey)` index uses binary case-sensitive comparison. Confirmed technician/start and bay/start indexes include end/status; qualification, locality and window indexes support selection. These indexes do **not** enforce interval exclusion independently of the booking protocol.

## 7. API contracts

The authoritative [OpenAPI contract](../specs/001-service-scheduler/contracts/openapi.json) and [API description](../specs/001-service-scheduler/contracts/api.md) define:

| Operation | Input | Success |
|---|---|---|
| `POST /api/v1/appointments` | JSON: `customerId`, `vehicleId`, `dealershipId`, `serviceTypeId`, `startTime`; optional `Idempotency-Key` header | 201 new / 200 replay, both with `Location`. |
| `GET /api/v1/appointments/{id}` | GUID in D format | 200 confirmation; 404 missing. |
| `GET /api/v1/availability` | Query: `dealershipId`, `serviceTypeId`, `startTime` | 200 with `available`, `reasonCode` and provisional notice. |
| `GET /health/live` | None | 200; no database dependency. |
| `GET /health/ready` | None | 200/503 connectivity result; does not certify schema or runtime permissions. |

Confirmation fields are `id`, the six entity/resource IDs, `startTime`, `endTime`, `durationMinutes` and `status`. Availability also returns dealership/service IDs and the derived interval; `reasonCode` is `AVAILABLE` or the applicable unavailability code. It states: “Availability is provisional until booking confirmation succeeds.”

IDs must be positive signed 64-bit integers. Unknown/duplicate JSON properties and unexpected/repeated query parameters are rejected. Start times require an explicit offset, valid calendar/range and at most seven fractional digits; responses use UTC `Z`. Clients cannot override duration, end or assignments. Keys contain 1–128 visible ASCII characters, without trimming.

Every response carries `X-Correlation-ID`. Errors use `application/problem+json` with stable `code`, `correlationId` and, where applicable, persistence `outcome`. Development exposes `/openapi/v1.json`.

## 8. Concurrency and transactions

Inside an explicit ReadCommitted transaction, `sp_getapplock` acquires an exclusive transaction-owned lock named `scheduler:dealership:<numeric-id>` in the shared database/public principal. Key lookup, authoritative reads, selection, insert and commit all occur under this lock. Same-dealership participating writers serialize; different dealerships use independent locks. Lock wait is at most two seconds and limited by the remaining deadline.

Overlap is `existing.StartUtc < requested.EndUtc && existing.EndUtc > requested.StartUtc`. Valid local windows are converted to instants and overlapping/touching coverage is merged before evaluating the full service interval.

Replay compares original IDs and canonical start instant before current future-time/resource checks, allowing retrieval of an earlier confirmation after time passes. Failed attempts consume no key. The unique index protects key binding; the cooperative lock protects resource intervals. Direct inserts bypassing this protocol can violate overlap safety.

## 9. Error handling and resilience

400 covers invalid input, unknown references and ownership errors; 409 covers resource unavailability and key mismatch; 503 covers busy storage, deadline expiry, database unavailability and uncertain booking outcome; 500 covers invalid reference configuration or unexpected faults. Availability reports ordinary resource unavailability as 200 with `available=false`.

Principal booking rejection codes are `DEALERSHIP_CLOSED`, `NO_QUALIFIED_TECHNICIAN`, `TECHNICIAN_UNAVAILABLE`, `BAY_UNAVAILABLE` and `KEY_PAYLOAD_MISMATCH`. Technical codes are `BOOKING_BUSY`, `REQUEST_TIMEOUT`, `DATABASE_UNAVAILABLE` and `BOOKING_OUTCOME_UNKNOWN`. Evaluation precedence is syntax, keyed replay/mismatch, references/ownership, duration/zone, representable future interval, dealership hours, technician eligibility, then bay eligibility.

Response work has a ten-second budget linked to caller cancellation. Configuration permits 1–3 seconds to connect; SQL commands are capped at five seconds, lock acquisition at two, and independent rollback cleanup at one. Provider disposal and server disconnect detection are not hard wall-clock guarantees.

At most one jittered whole-attempt retry follows a classified transient pre-commit failure with established noncommit and disposed resources. SQL-client automatic write retries are disabled. Business failures, lock expiry, cancellation and uncertain commits are not retried blindly.

A stable operation GUID permits one fresh-primary lookup after an uncertain commit, within the remaining budget. If recovery cannot establish the result, `BOOKING_OUTCOME_UNKNOWN` preserves uncertainty. An original keyed retry can recover its confirmation; an unkeyed external retry may create another booking. Error guidance distinguishes these cases and ordinary read retries.

## 10. Logging, metrics and tracing

Serilog writes allowlisted structured JSON through a nonblocking 1,024-event queue with bounded shutdown drain. Fields include operation, outcome, reason, correlation/trace IDs, dealership and elapsed time. Payloads, raw keys, SQL, secrets and arbitrary exceptions are excluded. Saturation drops events; logs are not a durable audit trail.

OpenTelemetry records request/use-case, transaction, lock and sanitized database-operation activities. Counters distinguish logical booking requests, attempts, new confirmations, replays, resource conflicts, key mismatches, lock failures and telemetry drops. Histograms cover transaction, lock wait and availability durations. Metric labels use finite reasons, without customer/resource IDs. Attempt timings are emitted after disposal.

`Telemetry__OtlpEndpoint` enables export. Development-only `Telemetry__LoadCaptureFile` enables bounded local sanitized JSONL span capture for load runs. Export failure is contained; capture coverage does not prove every child span survived. Live SQL capture and remote OTLP transport remain unverified.

## 11. Scalability and reliability

SQL-backed API replicas coordinate through the same primary database and dealership locks. Stateless serving permits replication, while a busy dealership’s serialized write path limits throughput. Projected reads and supporting indexes reduce work; actual plans, logical reads and history growth effects remain unmeasured. Availability can become stale immediately.

The implemented harness supports two processes, distributed/hot-dealership profiles, 100k history, ten callers, a 60/25/15 availability/retrieval/booking mix, 30-second warmup and three 120-second measurements. Proposed p95 targets are 300/150/500 ms respectively; they are **unmeasured targets**. No capacity or high-availability claim follows from unit tests.

## 12. Security

Runtime configuration requires an external SQL connection string with primary read/write intent, MARS disabled and connection retries disabled. Separate migration/seed credentials avoid runtime administration. The supplied [permission script](../scripts/database/runtime-permissions.sql) grants reference SELECT and Appointment SELECT/INSERT, excluding reference mutation and appointment UPDATE/DELETE.

Strict validation, constrained output, telemetry redaction and Development gates are implemented. Authentication, authorization, TLS termination and rate limiting are not implemented. A valid customer ID is not proof of caller identity; the delivered API therefore lacks a production access-control boundary. Host filtering and example loopback binding do not provide authorization.

## 13. Technology decisions and trade-offs

.NET 10 / ASP.NET Core, EF Core SQL Server and SQL Server 2022 provide one transaction boundary and relational integrity without distributed reservations. The [pinned SDK](../global.json) is 10.0.401 with latest-patch roll-forward; [central package versions](../Directory.Packages.props) include EF Core/OpenAPI 10.0.12, SqlClient 7.1.1, Serilog.AspNetCore 10.0.0 and OpenTelemetry hosting/exporter 1.19.1. Lock files support reproducibility. The modular monolith keeps deployment simple; ports preserve domain testability.

A dealership-wide application lock favors understandable correctness over maximum same-dealership throughput. Named-zone dated windows favor explicit assessment behavior over recurring-calendar complexity. Optional idempotency supports recovery while leaving unkeyed requests independent. EF migrations express durable constraints; application locking remains necessary for overlaps. Decisions and alternatives are recorded in [research](../specs/001-service-scheduler/research.md) and the [plan](../specs/001-service-scheduler/plan.md).

## 14. Testing strategy and actual evidence

Unit tests cover interval/zone policies, selection, precedence and transaction lifecycle using controlled ports. HTTP integration tests cover strict contracts, errors, Mock journeys, replay and telemetry. Real-SQL tests are implemented for schema, persistence, constraints, races and recovery; process tests target independent instances and restart behavior.

Latest recorded [non-SQL evidence](verification/convergence-nonsql.md), dated 2026-10-10:

| Assembly | Passed | Failed | Skipped discovery groups |
|---|---:|---:|---:|
| Unit | 83 | 0 | 0 |
| Integration | 74 | 0 | 41 |
| ProcessTests | 3 | 0 | 5 |
| Total | 160 | 0 | 46 |

The three ProcessTests passes are pure workload/capture helpers, not process or SQL safety evidence. Skipped theory groups are not expanded case counts or passes. The evidence page identifies the three final TRX files under `artifacts/test-results/convergence-nonsql-final/`; an earlier unit-only file in that directory is excluded. Review independently recounted individual TRX outcomes because summary skip counters are misleading. Release build passed with zero warnings/errors; the ECMAScript OpenAPI validator passed key-character, bounds, timestamp syntax and header checks. SQL Server was not installed/configured for that run. This documentation update does not constitute a new test run.

## 15. AI collaboration during design

AI-assisted work translated supplied requirements and recorded clarifications into the specification, architecture, schema, transaction protocol and decision records. Design discussion clarified replay lifetime, half-open intervals, deterministic selection, time-zone exclusions, error precedence and logical-request metric denominators.

The [collaboration narrative](ai-collaboration-narrative.md) records implementation increments, initially failing checks and subsequent corrections, plus the user’s explicit scope excluding SQL setup. These artifacts provide a traceable rationale; they do not establish independent design approval or substitute for real-SQL evidence.

## 16. Known limitations and future improvements

**Outstanding completion work:** [convergence tasks T104–T109](../specs/001-service-scheduler/tasks.md) require mandatory SQL acceptance, clean setup assessment, actual timing capture, measured performance/query plans and parallel fixture cleanup verification. T108 is a remaining source gap: capture-read or invariant failures can occur before the harness writes its report, losing collected failure evidence. It can be fixed without SQL setup.

**Implemented boundaries:** immutable seeded calendars; no cancellation/rescheduling; cooperative writers; ephemeral Mock mode; bounded telemetry with possible drops; connectivity-only readiness; no demonstrated SQL recovery, concurrency or production capacity. Distributed load slots use a finite date horizon that will eventually need renewal.

**Proposed future design:** introduce caller authentication and ownership authorization, TLS/rate controls, backup/restore and failover drills, operational dashboards and retention policies. If calendar administration or other writers are introduced, define a shared locking/write protocol. Consider finer locking, query tuning or availability caching only after measurement; final booking must retain authoritative transactional checks. These proposals are not delivered capabilities.
