Build the Keyloop Unified Service Scheduler.

Business Context:
Automotive dealerships provide maintenance and repair services.
Customers require appointments for specific vehicles and service
types at their preferred dealership and time.

The application must automatically verify that both a service bay
and a qualified technician are available before confirming a booking.

Mandatory Functional Requirements:

FR-001: Appointment Request
- Accept an existing customer.
- Accept a vehicle belonging to that customer.
- Accept a dealership.
- Accept a supported service type.
- Accept a requested start date and time.

FR-002: Service Duration
- Determine appointment duration from the selected service type.
- Derive the appointment end time from start time and duration.

FR-003: Technician Eligibility
- Only technicians qualified for the selected service type are eligible.
- The technician must belong to the selected dealership.
- The technician must be available for the entire appointment.

FR-004: Service Bay Availability
- The bay must belong to the selected dealership.
- It must be available throughout the entire appointment duration.

FR-005: Conflict Detection
- Reject any booking that overlaps an existing confirmed booking
  for the selected technician or service bay.
- Treat appointment intervals as half-open: [start, end).
- Back-to-back appointments are allowed.

FR-006: Appointment Confirmation
- Select one valid technician and one valid bay.
- Confirm the appointment only when both can be reserved.
- Persist the customer, vehicle, dealership, service type,
  technician, bay, start time, end time, and booking status.
- Return a unique appointment identifier.

FR-007: Unavailable Resources
- Do not create an appointment when required resources
  are unavailable.
- Return a clear business error.

FR-008: Data Validation
- Reject unknown customers, vehicles, dealerships,
  and service types.
- Reject appointments with invalid start times.
- Reject a vehicle not belonging to the requested customer.

FR-009: Appointment Retrieval
- Support retrieval of an existing confirmed appointment
  by identifier.

FR-010: Availability Query
- Allow a caller to check resource availability for
  a dealership, service type, and requested start time.
- Clearly state that availability is provisional
  until booking confirmation succeeds.

Acceptance Scenarios:

AS-001: Booking succeeds when an eligible technician and
available bay exist for the complete duration.

AS-002: Booking fails when no qualified technician exists.

AS-003: Booking fails when all eligible technicians are busy.

AS-004: Booking fails when all service bays are busy.

AS-005: Partial time overlap prevents booking.

AS-006: Adjacent non-overlapping appointments are accepted.

AS-007: Confirmed appointments survive application restart.

AS-008: Two simultaneous conflicting requests cannot both
receive successful bookings for the same resources.

AS-009: Invalid requests do not persist appointment records.

AS-010: An appointment can be retrieved with all resource links.

Scope:
- Backend implementation only.
- No production React frontend.
- Pre-seeded sample dealership, customer, vehicle,
  technician, bay, and service-type data.
- No payment system, notifications, or external DMS integration.
- No cancellation or rescheduling in the initial version.

Deliver:
- Prioritized user stories.
- Functional and non-functional requirements.
- Acceptance scenarios.
- Explicit business assumptions.
- In-scope and out-of-scope features.
- Clearly identified risks and unresolved questions.

Do not select technical frameworks or implementation details
during this specification phase.
