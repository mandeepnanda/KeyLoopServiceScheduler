# Independent architecture and code-quality review

Reviewed on 2026-10-10 under `postImplementation-review-001.md`. This is a fresh source review and test rerun, not an adoption of the conclusions in `final-review.md`. No production code or existing requirement/checklist markers were changed.

## Verdict and verification

The dependency direction, application orchestration, pure scheduling rules, and attempt-bound SQL transaction design are sound on source inspection. Acceptance remains incomplete: the SQL implementation has not been exercised in this environment. Two concrete issues need correction: retry instructions for an unkeyed unknown outcome and suppressed startup diagnostics. A smaller fixture isolation issue should also be addressed.

Executed:

```powershell
dotnet test KeyLoopServiceScheduler.slnx -c Release --no-restore --logger trx --results-directory artifacts/test-results/postimplementation-review
```

The command exited 0 and rebuilt the test projects and their application dependencies without reported build errors. Unit tests: 83 passed. Integration tests: 64 passed and 39 SQL discovery groups skipped. Process tests: 0 passed and 4 skipped. Total: 147 passed, 0 failed, 43 skipped groups. Skipped theories are not expanded parameter cases and are not passing tests. No `SCHEDULER_TEST_CONNECTION` was configured. No migration, SQL database creation, SQL performance run, or external exporter test occurred.

Fresh evidence:

- Unit: `artifacts/test-results/postimplementation-review/mande_MANDEEPDEV_2026-10-10_11_43_41_net10.0.trx`.
- Integration: `artifacts/test-results/postimplementation-review/mande_MANDEEPDEV_2026-10-10_11_43_58_net10.0.trx`.
- Process: `artifacts/test-results/postimplementation-review/mande_MANDEEPDEV_2026-10-10_11_43_55_net10.0.trx`.
- Per-test outcomes and their exact TRX locations: `artifacts/test-results/postimplementation-review/test-outcomes.json`.

## Ranked findings and minimal corrections

### R1 — High: mandatory SQL acceptance has no execution evidence

This is a verification blocker, not a demonstrated implementation defect. The fresh run skips `SchemaConstraintTests`, SQL booking/availability/HTTP/cancellation tests, and every process test. Consequently real SQL constraint enforcement, concurrent reservation safety, rollback cleanup, and restart durability remain unproven. These include original mandatory AS-007 and AS-008. Passing mock HTTP tests and coordinator doubles do not establish these properties.

Evidence: the integration/process TRX files above; `tests/KeyLoopServiceScheduler.IntegrationTests/Fixtures/SqlDatabaseFixture.cs:8` and `:16` deliberately skip tests without an external connection.

Minimal correction: provide an isolated SQL Server test connection using the documented test identity and rerun the complete suite. Review executed schema, rollback, stale availability, independent-connection races, and two-process restart/race results before accepting the mandatory SQL requirements. Keep skips visible; do not substitute another provider or weaken assertions. Performance evidence is a separate additional engineering checkpoint.

### R2 — High: unknown-outcome retry advice assumes a key that may not exist

`src/KeyLoopServiceScheduler.Api/Errors/ProblemDetailsMapper.cs:29` gives every 503 the same detail: `Please retry this request using the same request key.` Booking keys are optional, and the mapper never checks whether the original booking supplied one. If an unkeyed insert commits but acknowledgement is lost and the fresh lookup cannot establish its outcome, this advice gives the caller no usable replay identity. Retrying without a key, or adding a new key after the failure, can create a second appointment on a spare pair. GET failures also receive booking-key advice.

Evidence: `BookAppointment.ExecuteCoreAsync` accepts null keys; `BookingTransactionCoordinator.ExecuteAsync` returns unknown after unresolved commit uncertainty; `ProblemDetailsMapper.Create` selects detail only by HTTP status. `specs/001-service-scheduler/spec.md` explicitly says unkeyed retries are independent and can create another booking. `ValidationRegressionTests.TechnicalResponsesPreserveSafeOutcomeAndExposeNoProviderMessage` passes but uses the helper's default key and does not test retry instructions. This finding is established by source inspection; no actual SQL transport fault was induced.

Minimal correction: choose guidance by operation, persistence outcome, and whether the original request carried a valid key. For keyed unknown outcomes, replay the original key and unchanged payload. For unkeyed unknown outcomes, explain that confirmation may already exist and automatic retry can duplicate it; adding a new key cannot recover the previous request. For known noncommits, give ordinary retry guidance; for GETs, omit booking-key instructions. Add focused HTTP cases for keyed/unkeyed unknown outcomes and GET technical failures without changing key optionality.

### R3 — Medium: the logging filter silently removes startup diagnostics

`src/KeyLoopServiceScheduler.Api/Observability/LoggingConfiguration.cs:12` admits only events with an `operation` property. The Mock warning in `src/KeyLoopServiceScheduler.Api/Program.cs:45` has no such property or scope and is filtered out. Ordinary host lifecycle messages are also excluded. Even if admitted, `BoundedLogSink` omits message text, so a startup warning needs safe structured fields to communicate its meaning. Request logging still works, but the intended ephemeral-storage warning is absent from that logging path.

Evidence: the filter, the startup call, and the bounded sink's field projection. `TelemetryBackpressureTests.StalledSinkDropsWithoutBlockingAndProjectsOnlySafeFields` passes for sink behavior; it does not cover the configured startup logger. This is a deterministic source finding, not a new live-host probe.

Minimal correction: emit allowlisted structured startup events, such as `operation=startup` and a finite `reasonCode=MOCK_STORAGE_EPHEMERAL`; provide similarly sanitized startup failure/lifecycle events where useful. Preserve exclusion of arbitrary exception text, credentials, payloads, and keys. Verify the configured logger admits the safe startup event and still drops unsafe fields.

### R4 — Low: SQL fixture cleanup affects unrelated connection pools

`tests/KeyLoopServiceScheduler.IntegrationTests/Fixtures/SqlDatabaseFixture.cs:122` calls process-wide `SqlConnection.ClearAllPools()` when disposing one isolated database. Other classes own separate databases and can run in parallel. This broad cleanup couples otherwise isolated classes and can change their connection reuse/timing. No actual flaky failure is claimed: these SQL tests were skipped.

Minimal correction: clear only the pool associated with this fixture's database connection, after fixture-owned contexts have been disposed. Preserve the generated-name guard and explicit database cleanup. Validate with parallel SQL classes when SQL becomes available.

## Review coverage

| Requested area | Assessment and evidence | Remaining limit |
|---|---|---|
| Layering and dependency direction | Domain has no project dependencies; Application references Domain; Infrastructure references Application/Domain; API references Application and Infrastructure for composition. Application uses `IAvailabilityReader`, `IAppointmentReader`, `IBookingTransaction`, and `IBookingStore`. | API references to Infrastructure are expected at composition, health, seed, and Mock boundaries. No reverse dependency found. |
| Domain logic in controllers | `AppointmentsController` and `AvailabilityController` validate transport shape, call application services, and map HTTP results. Duration, ownership, schedules, qualification, selection, and overlaps live in Application/Domain. | No scheduling policy leak found. Manual `JsonElement` validation is deliberate strict contract enforcement. |
| Database queries | `ResourceQueries.ReadAsync` uses sequential bounded query batches, date/interval predicates, qualified local IDs, and projected overlaps. `AppointmentReader` projects only public confirmation fields. | Constant query count does not mean bounded row count. Repeated in-memory filtering of windows/overlaps per candidate can be optimized with lookups if measurement justifies it; no load/plan evidence exists. |
| Transaction boundaries | `BookingAttempt` opens one ReadCommitted transaction, takes a transaction-owned dealership application lock before exposing the store, inserts one complete row, and commits before the result returns. Replays/rejections roll back read-only attempts. Retry uses a fresh disposed attempt; ambiguous commit triggers one fresh lookup, never delegate reinsertion. | SQL serialization assumes all booking writers cooperate with the lock. Reference/calendar mutation is administrative in current scope. Real races, lock behavior, and recovery are unverified (R1). |
| EF tracking and queries | Reads use `AsNoTracking`; writes intentionally track a new Appointment until `SaveChangesAsync`. No parallel queries share a context. Composite FKs enforce ownership/dealer/qualification; duration/status/UTC/key constraints and indexes are defined. | Model/source review is not migration execution. Index effectiveness, query translation/plans, and actual constraint behavior need SQL evidence. |
| Input validation and statuses | Strict unknown/duplicate property rejection, positive bigint IDs, explicit-offset precision checks, ownership/reference validation, and header bounds. Tested creation 201, replay/retrieval 200, invalid 400, unknown appointment 404, business conflict 409, technical 503. | Unsupported body media type maps to 400 under the approved contract and current test, so it is not raised as a 415 regression. SQL HTTP cases remain skipped. |
| Error handling | Safe Problem Details expose stable codes/correlation and persistence outcome where known. Exception text/provider details are omitted. Response-started exceptions are not rewritten. Unknown persistence outcomes are not asserted to be rollbacks. | Retry wording needs R2. No real acknowledgement-loss/transport-fault reproduction performed. |
| Cancellation | Controller tokens reach application ports, EF queries, lock acquisition, writes, and commit. `BookingDeadline` links caller cancellation to a response budget; rollback uses a separate cleanup budget. Disconnect handling stops response writing. | Async disposal itself has no explicit cancellation budget; the code is not proof of a hard end-to-end wall-clock bound. Real cancellation/cleanup cases skipped. |
| Sensitive data logging | Request logs project operational fields; sink strips message/exception/payload/key fields; metric labels use finite reason codes. SQL parameter/text logging is not enabled. HTTP tracing removes URL fields. | Startup visibility needs R3. Real OTLP export and captured remote traces were not reviewed, so exporter-level privacy/completeness is not certified. |
| Test isolation and maintainability | Fresh Mock instances, deterministic unit/fake clocks, generated SQL database per class, guarded drop, independent process harness, and distinct TRX files. Telemetry collection disables parallelization for shared global meter assertions. | R4 affects pool isolation. Process fixtures use fixed future dates and Release/net10.0 paths; revisit when target framework or date horizon changes. |

## Acceptance decision

Do not mark the backend fully assessed. Correct R2/R3, preserve privacy checks, and obtain real SQL evidence for R1. R4 is a smaller maintainability correction. Proposed changes have not been applied during this review. Requirement-by-requirement outcomes and original-source limitations are recorded in `postimplementation-review-002-results.md`.
