# Demonstrate the backend

Build and start Development mock mode using README. No React frontend is required. The same
`/api/v1` routes work in SQL mode after explicit migration and seeding.

In a second PowerShell window:

```powershell
$base = 'http://localhost:5080'
$demo = Invoke-RestMethod "$base/demo"
$time = $demo.exampleBooking.startTime
$query = "$base/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=$([uri]::EscapeDataString($time))"
Invoke-RestMethod $query
$body = @{ customerId=1; vehicleId=1; dealershipId=1; serviceTypeId=1; startTime=$time } | ConvertTo-Json
$headers = @{ 'Idempotency-Key'='demo-api-001'; 'X-Correlation-ID'='assessment-01' }
$created = Invoke-WebRequest "$base/api/v1/appointments" -Method Post -ContentType 'application/json' -Headers $headers -Body $body -UseBasicParsing
$created.StatusCode # 201
Invoke-RestMethod ($base + $created.Headers.Location)
$replay = Invoke-WebRequest "$base/api/v1/appointments" -Method Post -ContentType 'application/json' -Headers $headers -Body $body -UseBasicParsing
$replay.StatusCode # 200; same body and Location
Invoke-RestMethod "$base/health/live"
Invoke-RestMethod "$base/health/ready"
Invoke-RestMethod "$base/openapi/v1.json"
```

Availability returns the derived UTC interval, available=true, reasonCode=AVAILABLE, and
notice="Availability is provisional until booking confirmation succeeds." It reserves nothing.
Booking returns id, customer/vehicle/dealer/service IDs, both resource IDs, UTC Z start/end,
durationMinutes=60 and status=Confirmed. Retrieval returns the saved body without a raw key.

Change vehicleId to 2 with the confirmed key: 409 KEY_PAYLOAD_MISMATCH. Keep the original body
with a second key: 201 on the alternate pair. A third distinct key for that slot: 409
TECHNICIAN_UNAVAILABLE. Requery availability: 200 available=false with that reason. Unknown
customer 999 with a fresh key gives 400 UNKNOWN_CUSTOMER; an unknown valid appointment GUID
gives 404 APPOINTMENT_NOT_FOUND. Unknown/missing JSON properties give 400 INVALID_REQUEST.

Representative conflict body:

```json
{"type":"urn:keyloop:problem:TECHNICIAN_UNAVAILABLE","title":"TECHNICIAN UNAVAILABLE","status":409,"detail":"The request cannot be confirmed with the current booking state.","instance":"/api/v1/appointments","code":"TECHNICIAN_UNAVAILABLE","correlationId":"assessment-01"}
```

Technical cases use explicit fault adapters and, when SQL is available, real held locks and
transactions. BOOKING_BUSY/REQUEST_TIMEOUT with established rollback use 503 and
outcome=not_committed; unresolved commit uses 503 BOOKING_OUTCOME_UNKNOWN and outcome=unknown.
No ordinary demo command creates transport uncertainty. Retry uncertainty with the same key.

In SQL mode `/demo` is absent: use the explicit future seed date's 09:00 local dealer-1 slot
(03:30 UTC, Asia/Kolkata), service/customer/vehicle/dealer 1. Seeded history ID
11111111-1111-1111-1111-111111111111 can be retrieved independently of booking.

Mock mode resets on restart. SQL restart/replay tests are in ProcessTests and skip without
SCHEDULER_TEST_CONNECTION. A mock restart does not demonstrate SQL durability.
