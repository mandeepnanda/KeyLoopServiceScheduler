Generate the complete technical plan for the Keyloop
Unified Service Scheduler using the approved specification.

Technology:
- C# with ASP.NET Core Web API
- .NET 10 LTS
- Entity Framework Core
- SQLServer as persistent database
- xUnit for automated tests
- ASP.NET Core integration testing
- OpenAPI documentation
- Serilog structured logging
- OpenTelemetry instrumentation

Architecture:
- Pragmatic Clean Architecture
- Modular monolith deployed as one application
- API, Application, Domain, Infrastructure boundaries
- Dependency injection
- No message broker
- No microservices
- No authentication infrastructure for MVP

Responsibilities:
- API: requests, validation, response mapping, errors
- Application: use-case orchestration and transaction coordination
- Domain: booking policies, qualification and overlap rules
- Infrastructure: EF Core persistence, resource allocation
  and database-backed concurrency coordination

Data Model:
- Customer
- Vehicle
- Dealership
- ServiceType
- Technician
- TechnicianQualification
- ServiceBay
- Appointment

Generate:
1. Architecture diagram using Mermaid.
2. Component responsibility descriptions.
3. Appointment booking sequence diagram.
4. ER diagram and relational schema.
5. API contracts and error response specifications.
6. Database transaction and concurrency strategy.
7. Dependency injection design.
8. Observability and logging strategy.
9. Unit and integration test strategy.
10. Technology decision records and trade-offs.
11. Deployment and local execution instructions.
12. Risks, assumptions, and future scalability considerations.

Concurrency Requirement:
Provide a concrete concurrency-control design compatible
with SQLServer that remains correct across independent
application processes sharing the database.

Document lock boundaries, transaction behavior,
busy timeout handling, conflict detection, and retries.

Do not rely exclusively on an in-memory lock,
optimistic pre-check, or transaction without a
demonstrated serialization mechanism.



Scalability, Performance, Reliability, and Future Readiness:

Design the system to satisfy Keyloop's "Build For the Future"
requirement while keeping the assessment implementation simple.

1. Scalability Assumptions
- Define representative workload assumptions for the MVP
  and a hypothetical production deployment.
- Include dealership count, technician and service bay
  count per dealership, daily appointments, peak concurrent
  booking requests, and availability-query volume.
- Clearly label all workload figures as design assumptions,
  not requirements provided by Keyloop.
- Distinguish current implementation capacity from
  aspirational production targets.

2. Application Scalability
- Design ASP.NET Core APIs to be stateless.
- Avoid application-instance-specific booking state.
- Explain how multiple API instances could operate behind
  a load balancer.
- Ensure correctness does not rely on in-memory locks.
- Document the future deployment topology.

3. Database Scalability
- Design indexes for common availability and booking queries.
- Analyze query efficiency as appointment history grows.
- Explain SQlServer's transaction, concurrency, and
  shared-storage limitations.
- Explain how the concurrency-control strategy would
  change during migration.
- Do not claim that switching databases alone solves
  booking concurrency issues.

4. Booking Concurrency and Consistency
- Guarantee that confirmed appointments cannot overlap
  for the same technician or service bay.
- Protect availability checking and resource allocation
  through an appropriate transactional mechanism.
- Account for concurrent requests targeting the same
  and different dealerships.
- Analyze transaction contention and retry behavior.
- Define consistent handling of booking conflicts.
- Prioritize correctness over throughput.

5. Performance
- Define proposed latency objectives for:
  a. Availability queries
  b. Appointment creation
  c. Appointment retrieval
- Treat these as targets, not proven capabilities.
- Specify how latency will be measured.
- Identify likely database bottlenecks.
- Avoid unnecessary database round trips.
- Include a small, reproducible performance test plan.

6. Caching
- Evaluate caching for relatively static reference data:
  dealerships, service types, and technician qualifications.
- Explain cache invalidation requirements.
- Do not use cached availability results as authoritative
  evidence that a booking can be confirmed.
- Do not introduce Redis unless justified.

7. Reliability and Failure Handling
- Define database transaction rollback behavior.
- Handle database contention and transient failures.
- Avoid unsafe or unbounded retries.
- Define timeouts and cancellation handling.
- Ensure duplicate client requests cannot accidentally
  create duplicate appointments if idempotency is supported.
- Document failure scenarios and recovery behavior.

8. Observability
- Define metrics for:
  - Appointment booking success rate
  - Booking conflict rate
  - API response latency
  - Database transaction duration
  - Database contention and busy errors
  - Availability-query duration
- Use structured logs and distributed tracing.
- Define how these signals help identify scaling bottlenecks.

9. Future Production Architecture
- Describe a production-oriented evolution using:
  - Multiple stateless ASP.NET Core API instances
  - Load balancing
  - SQLServer or another suitable managed relational DB
  - Connection pooling
  - Health checks
  - Centralized logging and metrics
- Explain which existing components remain unchanged.
- Identify required changes to transaction handling.
- Avoid adding these infrastructure components to the
  assessment implementation unless necessary.

10. Architectural Trade-offs
- Compare MVP and future production architecture.
- Identify scalability limitations and associated risks.
- Explain correctness versus throughput trade-offs.
- Document decisions using lightweight ADRs.

Required Deliverables:
- Scalability and performance section in plan.md
- Identified scaling bottlenecks
- Database indexing strategy
- Concurrency and consistency design
- Proposed load/performance test scenarios
- MVP versus production architecture comparison
- Corresponding content for the System Design Document

Do not implement speculative production infrastructure.
Do not invent performance measurements.
Keep the implementation proportionate to a coding assessment.
Do not generate application code during planning.