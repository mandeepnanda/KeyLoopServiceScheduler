Review the booking implementation for race conditions.

Design and execute integration tests using separate
DbContext instances and, where feasible, independent
processes against a shared persistent test database.

Verify:
- Two overlapping requests cannot both claim the same resources.
- Failed transactions leave no partial bookings.
- Database contention is handled correctly.
- No check-then-insert race remains.
- Adjacent bookings are allowed.

Report test evidence and any unresolved limitations.
Do not claim multi-instance safety based only on
single-process testing.
