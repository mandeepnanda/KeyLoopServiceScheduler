Perform an independent architecture and code-quality review.

Check:
- Layering and dependency direction.
- Domain logic leaking into controllers.
- Database queries and transaction boundaries.
- EF Core tracking and query behavior.
- Input validation and HTTP status codes.
- Error handling.
- Cancellation propagation.
- Sensitive data logging.
- Test isolation and maintainability.

Rank issues and propose minimal corrections.
