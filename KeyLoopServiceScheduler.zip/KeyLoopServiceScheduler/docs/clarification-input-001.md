Review the specification and identify unresolved business
rules involving:

1. Appointment duration and service-type configuration.
2. Technician qualifications.
3. Technician working hours and availability.
4. Dealership operating hours.
5. Service bay allocation.
6. Half-open time intervals and overlapping bookings.
7. Time zone handling.
8. Appointment lifecycle.
9. Resource selection when multiple options exist.
10. Booking requests that cannot be fulfilled.

Ask targeted clarification questions and recommend
the simplest defensible assumptions for this assessment.

Distinguish Keyloop's explicit requirements from proposed
business assumptions.

Update the specification with confirmed decisions.
Do not implement code.
