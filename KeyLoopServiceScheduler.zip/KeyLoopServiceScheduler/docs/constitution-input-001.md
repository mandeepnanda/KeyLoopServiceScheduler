Project: Keyloop Unified Service Scheduler.

Establish the following non-negotiable engineering principles:

1. Requirements-First Development
- Implement functionality traceable to the assessment requirements.
- Document assumptions for ambiguous requirements.
- Keep optional enhancements separate from mandatory functionality.

2. Architecture and Design
- Use a modular monolith rather than microservices.
- Follow pragmatic Clean Architecture principles for .NET Core Framework 10 Version.
- Separate API, Application, Domain, and Infrastructure concerns.
- Apply SOLID and dependency inversion where they improve maintainability.
- Avoid unnecessary patterns and abstractions.

3. Domain Correctness
- Booking eckit-conmust require a qualified technician and available service bay.
- Both resources must cover the entire appointment duration.
- Conflicting confirmed bookings must never be allowed.
- Availability checks alone are not sufficient to guarantee booking correctness.
- Persist the appointment and both resource assignments atomically.

4. API Engineering
- Follow REST conventions.
- Validate all user inputs.
- Use appropriate HTTP status codes.
- Return standardized Problem Details errors.
- Provide OpenAPI documentation.

5. Data Integrity
- Use relational database constraints where appropriate.
- Define explicit transaction boundaries.
- Handle concurrent requests safely.
- Never assume in-memory locks work across application instances.
- Do not claim concurrency safety without tests.

6. Testing and Verification
- Use automated unit and integration tests.
- Test success, validation failure, unavailable resources,
  overlapping appointments, and concurrent bookings.
- Never suppress or remove failing tests merely to pass validation.
- Record test results accurately.

7. Observability
- Use structured logging.
- Include correlation IDs.
- Instrument important booking operations.
- Avoid logging customer-sensitive information unnecessarily.

8. AI Engineering
- Treat AI-generated code as untrusted until reviewed and verified.
- Implement in small, reviewable increments.
- Explain significant architectural decisions.
- Record AI collaboration and corrections.
- Do not fabricate verification results.

9. Assessment Scope
- Implement the backend fully.
- Mock the frontend with OpenAPI, HTTP requests, and tests.
- Prioritize correctness and clear documentation.
- Do not introduce Kubernetes, Kafka, distributed messaging,
  or authentication infrastructure without demonstrated need.

10. Documentation
- Maintain a System Design Document.
- Document assumptions and architectural decisions.
- Keep README build, run, and test instructions reproducible.
- Explain key trade-offs and limitations.
