# Booking race-condition review

Reviewed on 2026-10-10 under `docs/postImplementation-review-003.md`.

## Verdict

Source inspection found no unprotected check-then-insert sequence in the normal SQL booking path: a transaction-owned exclusive dealership application lock precedes all eligibility reads and remains held through commit or rollback. The design is suitable for coordinating cooperating instances against the same SQL database. **Its actual concurrency, rollback, contention and multi-instance safety are not verified on this host.** No persistent SQL test connection was supplied, and all relevant SQL/process test bodies were skipped. Passing policy, Mock and coordinator-double tests do not establish multi-instance safety.

This review adds focused integration/process test definitions and records a fresh suite attempt. Production behavior, business requirements, and earlier review findings were not changed. The requested real-database execution remains incomplete.

## Environment and actual execution

Read-only probes found:

- `SCHEDULER_TEST_CONNECTION` is not configured.
- No `sqlcmd`, `docker`, or `SqlLocalDB` command is available through PATH.
- No Windows service matching `*SQL*` was returned.

These probes do not prove that no remote SQL server exists; no authorized remote endpoint or test identity is available to this review. No instance was installed, credentials inferred, or runtime database repurposed. The probe saves booleans/tool/service availability, not connection strings or secrets, in `artifacts/test-results/postimplementation-review-003/environment-probe.json`.

Executed:

```powershell
dotnet test KeyLoopServiceScheduler.slnx -c Release --no-restore --logger trx --results-directory artifacts/test-results/postimplementation-review-003
```

Exit code: 0. Compilation of the modified test projects succeeded. Results:

| Project | Passed | Failed | Skipped discovery groups | Evidence |
|---|---:|---:|---:|---|
| Unit | 83 | 0 | 0 | `artifacts/test-results/postimplementation-review-003/mande_MANDEEPDEV_2026-10-10_11_57_58_net10.0.trx` |
| Integration | 64 | 0 | 41 | `artifacts/test-results/postimplementation-review-003/mande_MANDEEPDEV_2026-10-10_11_58_12_net10.0.trx` |
| Process | 0 | 0 | 5 | `artifacts/test-results/postimplementation-review-003/mande_MANDEEPDEV_2026-10-10_11_58_19_net10.0.trx` |
| Total | 147 | 0 | 46 | `artifacts/test-results/postimplementation-review-003/test-outcomes.json` |

Skipped theories represent discovery groups rather than expanded parameter cases. The increase from the prior review's 43 skipped groups is two new integration methods and one new process method. Their bodies did not execute. No test database was created, no migration applied, and no two API child processes launched for these skipped tests. Zero failures does not close the SQL evidence gap.

## Race analysis

### 1. Overlap checks and writes share one protected transaction

`src/KeyLoopServiceScheduler.Infrastructure/Transactions/BookingAttempt.cs:29` opens the attempt connection and begins ReadCommitted before calling `DealershipApplicationLock.AcquireAsync`. The store is exposed only after successful lock acquisition. The coordinator calls the application work delegate after `AcquireAsync` completes (`BookingTransactionCoordinator.cs:34`).

`src/KeyLoopServiceScheduler.Application/Booking/BookAppointment.cs` performs replay lookup, reference checks, full interval eligibility and resource selection inside that delegate. Resource reads at line 59 precede insert at line 66, both through the attempt-bound store. `BookingStore.AddAsync` calls SaveChanges but does not commit. The coordinator commits only after the delegate returns. Thus the next cooperating booking for that dealership cannot perform its resource reads before the first attempt ends its transaction. A prior availability query is provisional and is not reused as an authoritative reservation.

The shared lock is a SQL `sys.sp_getapplock` lock with resource `scheduler:dealership:<id>`, mode Exclusive, owner Transaction and database principal public. It is not a process-local semaphore. Context instances/processes targeting the same database use the same dealer lock name. Composite relationship constraints ensure a persisted technician/bay belongs to its dealership, which supports partitioning by dealership.

**Evidence level:** inspected source plus passing fake lifecycle/policy tests. Real SQL locking, isolation and overlap-query behavior remain untested here. No remaining normal-path race was identified by inspection; that is not proof that no race exists.

### 2. Partial assignments and failed transactions

The appointment stores both required resource IDs in a single row. Relationship, interval, duration, status and UTC constraints are defined in `Persistence/Configurations/AppointmentConfiguration.cs`. There are no separate reservation writes that can be committed independently. Before-commit failures roll back the explicit transaction with a separate cleanup token and dispose its context. Successful results leave the coordinator only after acknowledged commit, or after a fresh lookup recovers a committed operation.

If commit has started and acknowledgement is uncertain, the code does not claim rollback or run the booking delegate again. It discards the old attempt and makes one fresh-primary lookup by operation ID, otherwise returns unknown. Unknown is not equivalent to failed/no rows. The existing post-commit fault decorator simulates acknowledgement loss after a real commit; it is not a real network fault test.

**Evidence level:** source and fake lifecycle assertions pass. Real rollback, constraint enforcement and actual transport failure behavior remain unresolved.

### 3. Contention, cancellation and retry

Lock wait is capped at two seconds, SQL commands at five seconds, and the linked request budget is ten seconds. Lock timeout maps to `BOOKING_BUSY`; cancellation maps to `REQUEST_TIMEOUT`. Only eligible transient failures retry, at most once, after disposal and a known noncommit. Commit uncertainty never retries the work delegate. An independent dealership uses a separate lock.

These limits bound work initiation and cancellation intent; asynchronous provider/context disposal has no explicit wall-clock cancellation bound. There is no actual SQL contention, deadlock, cleanup-latency, starvation/fairness, or load measurement in this review. The existing injected -3/deadlock test exercises retry policy, not a genuinely induced SQL deadlock.

### 4. Adjacent intervals

`AppointmentInterval.Overlaps` and the SQL resource predicate use half-open comparisons: existing StartUtc < requested EndUtc and existing EndUtc > requested StartUtc. A booking ending exactly at the next start is not a conflict. Unit cases pass for both technician and bay boundaries. New independent-context and two-process tests require adjacent rows to use the same constrained pair, with the first EndUtc exactly equal to the second StartUtc.

**Evidence level:** policy pass; actual SQL adjacency and process execution skipped.

### 5. Protection assumptions and limits

The overlap indexes are ordinary indexes, not an interval exclusion constraint. The unique index prevents duplicate dealer/key bindings, not two distinct overlapping appointments. `BookingStore` is public, and runtime permissions include direct INSERT on Appointment (`scripts/database/runtime-permissions.sql`), so another writer bypassing the coordinator/application lock can defeat resource exclusion even while satisfying the row/FK constraints. This is an explicit architectural boundary, not an observed API exploit or a demonstrated normal-path race.

All serving instances must use this lock protocol, the same authoritative database, and consistent lock identity/principal. Live calendar/qualification mutations by administrators are not serialized by this booking code. Current reference data is administratively seeded before serving; if live mutation or additional write services are introduced, they must participate in an appropriate transaction/locking protocol. If database-level exclusion for arbitrary writers becomes a requirement, enforce writes through a single protected database operation and restrict direct inserts; ordinary indexes alone cannot meet it.

## Designed tests and outcomes

The existing fixture creates one uniquely named persistent SQL database per test class, applies real migrations, and does not wrap tests in an outer transaction. Application services create a fresh context/connection/transaction per attempt. Verification uses another context reading committed rows. No EF InMemory, SQLite, or Mock substitute was introduced for SQL tests.

New test source:

- `tests/KeyLoopServiceScheduler.IntegrationTests/Booking/BookingRaceReviewTests.cs`.
- Added `PartialOverlapAndAdjacencyAcrossTwoProcessesUseCommittedOnePair` in `tests/KeyLoopServiceScheduler.ProcessTests/BookingConcurrencyTests.cs`.

| Required check | Test design and exact method | Actual outcome | What remains unproven |
|---|---|---|---|
| Two overlaps cannot claim a shared pair, technician or bay | Existing integration `BookingConcurrencyTests.IndependentConnectionsCannotConfirmCompetingSharedResources`: three variants, separate coordinators/contexts, a common start gate, one success and one specific business conflict, fresh-context row/no-overlap checks. Existing process `HundredHealthyPairsAcrossTwoProcessesHaveOneConfirmationAndOneBusinessConflict`: 100 request pairs for each of three resource variants. | SQL/process skipped | All real-database assertions and 300 two-process race repetitions. |
| A contender rechecks committed eligibility instead of using stale state | New `BookingRaceReviewTests.WaitingOverlapRechecksAfterUncommittedInsertCommitsOrRollsBack(false)`: first real SQL SaveChanges completes and pauses before commit while its transaction lock is held; a separate contender enters real lock acquisition for a start 15 minutes later; release first commit; expect first success, second technician conflict, exactly one complete row. Context and connection identities must differ. | SQL theory group skipped | The real held-lock interleaving and subsequent resource recheck. Gates arrange overlap in attempt lifetimes; provider scheduling/lock behavior still needs real execution. |
| Rollback under contention leaves no partial rows or consumed key | Same new method with `true`: inject a precommit exception after actual SaveChanges, roll back first attempt, allow waiter to succeed; fresh context must see only waiter ID/key and no failed operation/key. Retry failed key at a free future slot must create a fresh complete row. Existing `BookingRecoveryTests.RealRollbackRemovesBothAssignmentsAndKey` covers before-save and beforecommit faults. | SQL skipped | Real rollback/lock release and corrected-key insertion. Injected application exceptions are not actual transport faults. |
| Contention produces correct business/technical classification and cleanup | Existing `DealershipLockTests.HeldLockProducesFiniteBusyOtherDealerProceedsAndRollbackReleasesLock`; `BookingCancellationTests.CancellationDuringHeldLockWaitLeavesNoRowAndLaterBookingCanProceed`; `BookingRecoveryTests.InjectedDeadlockResultRetriesOnlyAfterDisposingRealAttemptWithFreshContext`. | SQL skipped | Real busy/cancel handling. Injected deadlock policy coverage cannot establish genuine deadlock recovery. |
| No availability check-then-insert race | Existing `StaleAvailabilityTests.PositiveQueryDoesNotReservePairAndStaleBookingRechecksUnderSqlLock`; new held-uncommitted-insert test; source ordering described above. | Source reviewed; SQL tests skipped | No real SQL proof of the absence of a race. |
| Adjacent bookings succeed on the same resources through separate contexts | New `BookingRaceReviewTests.SimultaneousAdjacentBookingsShareOnePairWithoutOverlap`: constrain to one qualified technician and one bay; gated concurrent starts 60 minutes apart; both successful, two unique IDs, same resource IDs, exact end/start equality and no overlap. | SQL skipped | SQL overlap translation and shared-pair adjacency acceptance. |
| Partial overlap and adjacency through independent processes | New process `PartialOverlapAndAdjacencyAcrossTwoProcessesUseCommittedOnePair`: two Release API instances against the same fixture database; one pair; 20 runs per 15-minute partial overlap / 60-minute adjacency case, alternating process assignment of the earlier request. Require one 201 plus one specific 409 for overlaps, or two 201s for adjacency, then inspect complete committed rows in a fresh context. | Process theory group skipped | All 40 planned request-pair repetitions and all multi-instance assertions. Client start gates do not guarantee identical server arrival times. |
| Half-open interval policy and coordinator lifecycle | `BookAppointmentTests.OverlapRejectsButAdjacencyIsAllowed`, `AppointmentIntervalTests.HalfOpenOverlapIsSymmetric`, and existing `BookingCoordinatorTests` entries recorded in the outcome index. | Passed in this rerun | These are policy/fake lifecycle checks, not SQL or multi-process evidence. |

The new tests reuse real SQL adapters and only add test-only observation/commit gates. They neither replace the real lock/store nor add shared application memory as the safety mechanism. The commit-gated test drains started operations before fixture cleanup, retains operation/connection identities before disposal, and uses a fresh no-tracking read for persisted assertions. Their compilation is verified; skipped bodies have not been runtime-validated and may expose fixture/timing issues on the first SQL run.

## Remaining work and reproducible execution

Supply `SCHEDULER_TEST_CONNECTION` externally for an isolated SQL Server 2022 test identity with create/drop privileges, as described in `docs/development-environment.md`. Do not use a production connection. Then rerun:

```powershell
dotnet test KeyLoopServiceScheduler.slnx -c Release --no-restore --logger trx --results-directory artifacts/test-results/postimplementation-review-003-sql
```

The Release build is required because the process fixture starts the built Release API assembly. Retain separate project TRX results, inspect failures and skips, and verify that the new parameter cases and existing process repetitions actually executed before making any SQL or multi-instance claim. Diagnose genuine failures without relaxing overlap, atomicity, contention or adjacency requirements.

Pending evidence includes real lock ordering, constraints and rollback, contention and cancellation, independent-process overlap/adjacency, and actual deadlock/transport faults where those guarantees are claimed. Real SQL access is the prerequisite for completing this review's execution requirement. The appropriate current status is **source review and test design complete; persistent SQL and multi-instance verification unresolved**.
