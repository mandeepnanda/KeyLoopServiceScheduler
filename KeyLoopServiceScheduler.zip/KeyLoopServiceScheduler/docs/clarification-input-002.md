Focus specifically on transactional correctness and
concurrent booking behavior.

Resolve these questions:

- What prevents two simultaneous requests from booking
  the same technician or service bay?
- Is an availability response only advisory?
- What happens if resources become unavailable between
  the availability check and booking confirmation?
- What happens when a database transaction fails?
- Should booking retries be idempotent?
- What happens when a request is repeated?
- How are resource conflicts reported?
- How are failed requests prevented from leaving
  partial appointment records?

Define externally observable acceptance criteria.
Record any assumptions separately from mandatory requirements.
Do not prescribe a concurrency implementation yet.
