Implement only the foundational, domain-model, and persistence tasks from tasks.md.

Requirements:
- Create the solution and project structure.
- Implement the approved domain entities.
- Implement technician qualification rules.
- Implement appointment interval-overlap rules.
- Configure EF Core mappings and relational constraints.
- Generate database migrations.
- Implement reproducible seed data.
- Add corresponding unit and integration tests.

Use the approved plan and constitution.

After implementation:
- Build the solution.
- Run relevant tests.
- Report commands executed and actual results.
- Explain significant design decisions.
- Identify unfinished tasks.

Do not start the appointment booking API yet.
