Implement the availability and appointment-booking tasks from tasks.md.

Use the approved concurrency design.

Business rules:
- Validate customer, vehicle, service type, and dealership.
- Determine appointment duration.
- Find qualified technicians.
- Find available service bays.
- Reject overlapping appointments for either resource.
- Allocate both resources atomically.
- Persist the confirmed appointment.
- Return a clear conflict response when capacity is unavailable.

Concurrency requirements:
- Ensure concurrent requests cannot confirm conflicting
  allocations for the same technician or service bay.
- Protect the entire check-and-book sequence.
- Do not rely solely on an availability pre-check.
- Implement the approved database transaction strategy.
- Handle database contention and retries appropriately.
- Do not perform unsafe blind retries.

Implement tests for:
1. Successful appointment.
2. No qualified technician.
3. Technician unavailable.
4. Service bay unavailable.
5. Overlapping appointment.
6. Back-to-back appointment.
7. Concurrent competing requests.
8. Transaction rollback.

Run relevant tests and report actual results.

Do not claim concurrency guarantees without demonstrating
the supporting implementation and tests.