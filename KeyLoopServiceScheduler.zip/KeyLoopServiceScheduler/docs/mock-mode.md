# Run without SQL Server

Mock mode is an explicit Development-only option. It uses the existing availability and booking services with a host-owned, in-memory store. No SQL connection, migrations, or external database are required.

From the repository root in PowerShell:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Scheduler__StorageMode = 'Mock'
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-launch-profile -- --urls http://localhost:5080
```

Open http://localhost:5080/demo for the sample manifest. In a second PowerShell window:

```powershell
$base = 'http://localhost:5080'
$demo = Invoke-RestMethod "$base/demo"
Invoke-RestMethod ($base + $demo.availabilityUrl)
$body = $demo.exampleBooking | ConvertTo-Json
$booking = Invoke-RestMethod "$base/demo/appointments" -Method Post -ContentType 'application/json' -Body $body
Invoke-RestMethod "$base/demo/appointments/$($booking.id)"
Invoke-RestMethod "$base/demo/appointments" -Method Post -ContentType 'application/json' -Body $body
```

The first booking returns 201; replaying the same key and payload returns 200 with the same appointment. Changing that key's payload returns 409. Distinct keys compete for the two qualified technicians and bays in the example slot. Responses identify storage through `X-Scheduler-Storage: Mock`.

Sample dates start tomorrow in UTC and span 15 days. The manifest supplies a future booking time, customer/vehicle 1, dealership 1, and service 1. Customer/vehicle 2, dealership 2, and service 2 are also seeded. Optionally set `Scheduler__MockBaseDate` to a future `yyyy-MM-dd` date before starting. Restart the application to reset all changes.

The store stages a booking until the operation succeeds and serializes writes within one host. It provides no durable storage or coordination between processes and does not emulate SQL constraints, SQL locks, retries, or commit uncertainty. SQL verification checkpoints remain open. The `/demo` routes retain their local contract; the same adapters now also support the approved `/api/v1` routes. See [demo instructions](demo-instructions.md) for header-based keys and standard Problem Details.

SQL Server remains the default. Remove the mock environment setting and supply the documented SQL configuration to switch back:

```powershell
Remove-Item Env:Scheduler__StorageMode
```

Mock mode rejects environments other than Development. `--seed-only` remains a SQL Server command; mock data is seeded automatically. Console logging remains available; the Windows Event Log provider is disabled so startup requires no event-log write permission.
