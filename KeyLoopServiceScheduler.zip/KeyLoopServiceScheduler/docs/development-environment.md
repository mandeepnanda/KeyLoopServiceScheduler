# Development environment

For a local application demo without SQL Server, follow [mock mode](mock-mode.md). This opt-in
Development mode seeds ephemeral data automatically and exposes `/demo` routes. SQL verification
still requires the configuration below.

Use the .NET SDK pinned in global.json (.NET 10.0.401), with NuGet dependencies pinned centrally
and project-local lock files. Run `dotnet tool restore`, `dotnet restore KeyLoopServiceScheduler.slnx --locked-mode`,
and `dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore`.

SQL integration tests require an existing SQL Server 2022 Developer instance and an externally
supplied `SCHEDULER_TEST_CONNECTION` connection string with permission to create/drop isolated
test databases. Tests never use SQLite or EF InMemory in its place. Do not point test configuration
at production; fixtures use a new unique KeyLoopScheduler_Test_<GUID> database.

Supply runtime connection via `ConnectionStrings__Scheduler`, migration connection via the
explicit EF CLI invocation, and test connection via `SCHEDULER_TEST_CONNECTION`; do not commit secrets.
Runtime configuration rejects MultipleActiveResultSets=True, ConnectRetryCount other than zero,
connection timeout over 3 seconds and unexpected provider retry configuration. Runtime DB command
timeout is 5 seconds; the implemented booking coordinator enforces the shared request budget.

Use separate migration/seed and serving credentials; run migrations/seeding once before serving.
Optional Docker-hosted SQL is a deployment choice, not a requirement for local SQL installation.
No SQL Server or Docker installation was found on this execution host during initial probing.

Local integrated-security example (explicitly development-only certificate shortcut):

```powershell
$env:ConnectionStrings__Scheduler = 'Server=localhost;Database=KeyLoopScheduler;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=False;ConnectRetryCount=0;Connect Timeout=3'
```

Before serving, use migration/seed credentials with the explicit administrative commands:

```powershell
dotnet ef database update --project src/KeyLoopServiceScheduler.Infrastructure --startup-project src/KeyLoopServiceScheduler.Api --configuration Release
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build -- --seed-only --seed-base-date 2030-01-07
# Switch ConnectionStrings__Scheduler to the separately provisioned runtime identity.
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build -- --urls http://localhost:5080
dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore
dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-build --no-restore
```

Choose a future base date at execution time. Seed data covers 15 dated days at two dealers,
with service IDs 1 (60 minutes) and 2 (30 minutes), customers/vehicles 1 and 2, technicians 1–4
and bays 1–4. Dealer 1 uses Asia/Kolkata, dealer 2 America/New_York; both open 09:00–17:00.
Technician 1 works 09:00–12:00 and 13:00–17:00; technician 2 lacks service-2 qualification;
technician 4 has none. A confirmed fixture occupies technician 1/bay 1, 10:00–11:00 on day one.
Repeated seeding with the same future date preserves data; different/partial references are rejected
atomically. Seed-only exits without listening; the serving path never seeds or migrates.

The initial migration is also available as `scripts/database/initial-schema.sql` (idempotent EF SQL).
Review `scripts/database/runtime-permissions.sql` when provisioning the separate runtime user.
Integration tests need create/drop database privileges only on their external test identity.
The host now exposes all three business endpoints, health and Development OpenAPI in SQL and Mock modes.
See verification documents for actual commands/results; migration application and live SQL testing
were not performed here. Mock readiness identifies its storage explicitly.

Availability and booking application services are now registered and exercised directly by the
test suites. Booking requires a primary read-write connection and rejects ApplicationIntent=ReadOnly.
HTTP binding is now implemented. See verification/implementation-003.md and verification/booking.md
for the current test results and unexecuted SQL concurrency/rollback checks.
