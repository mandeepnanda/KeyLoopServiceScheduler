Complete the remaining approved implementation tasks. 

Implement:
- Availability endpoint.
- Appointment creation endpoint.
- Appointment retrieval endpoint.
- Request validation.
- Problem Details error responses.
- OpenAPI documentation.
- Correlation ID handling.
- Serilog structured logging.
- OpenTelemetry tracing and metrics.
- Database-backed integration tests.
- Seed-data initialization.
- README build, run, and test instructions.

Ensure the backend is demonstrable without a React frontend.

Provide sample HTTP requests and expected response examples.

Run the complete test suite.
Report failures accurately.
Do not change requirements simply to make tests pass.
