# Acceptance traceability

Source: approved spec.md, plan.md, tasks.md and input-003. Task completion denotes source/test
definitions where stated; it does not make skipped SQL cases pass. Latest actual execution is in
[convergence-nonsql.md](verification/convergence-nonsql.md) and the exact TRX files listed there.
Unit policies, mock HTTP and lifecycle probes pass. All SQL/process scenarios below await a real
test connection. Proposed performance targets remain unmeasured.

## Convergence Correction Traceability — 2026-10-10

| Source / correction | Concrete check | Current evidence / limit |
|---|---|---|
| FR-013/FR-014, AS-027/AS-031/AS-032, T096: safe recovery advice | `ValidationRegressionTests.RetryGuidanceDistinguishesKeyPresenceAndKnownPersistenceOutcome` (four cases); `RetrievalTechnicalFailureHasNoBookingKeyAdvice` | Five non-SQL HTTP passes; transaction outcomes supplied by a test adapter |
| NFR-004, T098: safe startup warning | `TelemetryBackpressureTests.ConfiguredLoggerEmitsSafeEphemeralStorageStartupWarning` | Configured logger/Mock host pass |
| Plan performance reporting, T099: local timing capture | `LoadTimingExporterTests.ConfiguredDevelopmentHostCapturesARealBookingWithoutSql`; `BatchCaptureRetainsMeasuredTimingsAndExcludesSensitiveFieldsAndUnknownOperations`; `CaptureFailureCannotChangeACompletedOperation`; `LocalCaptureIsRejectedOutsideDevelopment` | Four passes; no SQL timings or remote OTLP delivery certified |
| Plan low-collision profile, T100 | `LoadProfileTests.DistributedBookingsRemainDistinctAcrossWarmupAndBeyondTheOldWrapBoundary`; `HotDealerDeliberatelyReusesTheSamePairInterval`; `TimingSummaryCombinesProcessesAndExcludesWarmupAndLateRecords` | Three pure load-helper passes; no API processes or database involved |
| Plan fixture isolation, T102 | Fixture-scoped `SqlConnection.ClearPool` source review and project compilation | Parallel SQL fixture execution unperformed |
| NFR-005/NFR-006, T103 | Updated README, design, AI narrative, verification and final review | Current evidence reconciled; SQL assessment/final acceptance still open |

Earlier verification sections remain historical evidence. Latest totals are 83 unit, 74 non-SQL
integration and three pure load-helper passes; 41 SQL integration and five SQL process discovery
groups skipped. The three helper passes in the ProcessTests assembly do not demonstrate process safety.

## Requirements

| Requirement | Tasks | Concrete verification |
|---|---|---|
| FR-001 request | T012/T019/T038/T045/T061/T063/T064/T085 | BookingContractTests.InvalidShapeOrReferencesAreRejected; BookAppointmentTests.RejectionsLeaveNoRowsOrKeys |
| FR-002 duration | T008/T011/T016/T023/T025/T045/T061 | ServiceDurationTests.EndIsElapsedDurationWithoutBufferAndPreservesTicks; SchemaConstraintTests.EndDurationMismatchAndOverflowAreRejected |
| FR-003 qualified local technician | T010/T014/T018/T022/T023/T027/T045 | ResourceEligibilityTests.OtherDealerAndUnqualifiedResourcesCannotSatisfyBooking; SqlHttpJourneyTests.SqlResourceConflictsHaveSpecific409AndDoNotPersist |
| FR-004 local bay | T014/T018/T023/T027/T045 | ResourceEligibilityTests.BaysHaveNoServiceCapabilityFilter; BookingConcurrencyTests.IndependentConnectionsCannotConfirmCompetingSharedResources |
| FR-005 overlaps/adjacency | T008/T011/T024/T027/T042–T045/T052/T080 | AppointmentIntervalTests.HalfOpenOverlapIsSymmetric; BookAppointmentTests.OverlapRejectsButAdjacencyIsAllowed; ProcessTests.BookingConcurrencyTests.HundredHealthyPairsAcrossTwoProcessesHaveOneConfirmationAndOneBusinessConflict |
| FR-006 atomic confirmation | T016/T023/T043–T049/T064/T080/T082 | BookingTransactionTests.CompleteConfirmationReplayMismatchAndFreshReaderPreserveSavedRow; BookingRecoveryTests.RealRollbackRemovesBothAssignmentsAndKey |
| FR-007 no pair | T038/T045/T060/T064/T083 | BookingContractTests.CreationReplayRetrievalAndCapacityHaveContractHeadersAndUtcBodies; StaleAvailabilityTests.PositiveQueryDoesNotReservePairAndStaleBookingRechecksUnderSqlLock |
| FR-008 validation | T019/T022/T032/T038/T060/T061/T063/T085 | BookingContractTests.InvalidTimestampsHaveStableProblemCode; ValidationRegressionTests.MalformedJsonAndUnsupportedBodyMediaTypeUseSafeValidationContract |
| FR-009 retrieval | T028/T058/T065/T066/T082 | AppointmentRetrievalTests.SeededRetrievalIsIndependentAndIdentifiersDistinguish400From404; ProcessTests.AppointmentRestartTests.RestartRetainsConfirmationResourcesAndKeyBinding |
| FR-010 provisional availability | T018/T027/T028/T032–T037/T059/T067/T083 | QueryAvailabilityTests.ReportsFullIntervalReasonAndNoticeWithoutReservations; AvailabilityContractTests.QueryIsProvisionalThenReflectsBookingsWithoutReservingCapacity |
| FR-011 full hours | T009/T015/T017/T027/T045/T085 | ScheduleCoverageTests.GapAndMissingHoursFailClosed; SqlScheduleContractTests.CrossMidnightWindowIsIncludedForBothQueryAndBooking |
| FR-012 zones/DST | T009/T013/T017/T026/T029/T061/T085 | ScheduleCoverageTests.InvalidOrRepeatedBoundaryExcludesOnlyThatWindow; SqlScheduleContractTests.InvalidDstBoundaryIsExcludedButAnUnaffectedWindowCanCoverElapsedService |
| FR-013 keys/replay | T016/T023/T039/T044–T052/T063/T064/T081/T082 | BookingReplayTests.ConfirmedKeyRejectsEveryChangedPayloadField; ProcessTests.BookingReplayConcurrencyTests.KeysAcrossProcessesHaveOneBindingOrIndependentDealerScope; ProcessTests.AppointmentRestartTests.PastConfirmedKeyStillReplaysAfterRestartBeforeFutureValidation |
| FR-014 failure/recovery | T019/T041–T053/T060/T062/T064/T084 | BookingCoordinatorTests.AmbiguousCommitVerifiesOnceAfterDisposalAndNeverReinserts; BookingCancellationTests.CancellationBeforeCommitRollsBackAndAfterActualCommitDoesNotClaimRollback; ValidationRegressionTests.TechnicalResponsesPreserveSafeOutcomeAndExposeNoProviderMessage |
| NFR-001 concurrency | T042–T054/T079–T081/T087 | Independent SQL connection and two-process race definitions; SQL skipped, no guarantee |
| NFR-002 integrity/durability | T021–T025/T040/T049–T051/T082/T084 | SchemaConstraintTests; BookingRecoveryTests; AppointmentRestartTests; SQL skipped |
| NFR-003 clear outcomes | T060–T071/T085 | HTTP status/code/content-type/UTC/header assertions pass in mock mode |
| NFR-004 traceability/privacy | T062/T072–T078 | TelemetryContractTests.RequestsReplayAndBusinessConflictHaveLogicalDenominatorsWithoutIdentifierLabels; TransactionTelemetryTests.RetryAddsAttemptsAndEmitsOnlyAfterUnitDisposalWhileTechnicalFailuresAreNotConflicts; TelemetryBackpressureTests.StalledSinkDropsWithoutBlockingAndProjectsOnlySafeFields |
| NFR-005 evidence | T007/T019/T031/T037/T055/T056/T071/T078/T087/T092/T094 | Separate timestamped TRX; corrected failures and SQL skips recorded |
| NFR-006 assessment | T005/T029/T088–T094 | README, requests.http, demo-instructions, system-design, AI narrative; live mock smoke passes, clean SQL assessment pending |

## Acceptance cases

The concrete method references above plus these names identify the primary checks, not a claim
that every downstream SQL acceptance assertion ran.

| Acceptance | Primary named checks | Evidence limit |
|---|---|---|
| AS-001 | SuccessHasBothLowestNumericAssignmentsAndDerivedDuration; CreationReplayRetrievalAndCapacityHaveContractHeadersAndUtcBodies | Unit/mock pass; SQL row proof skipped |
| AS-002 | RejectionsLeaveNoRowsOrKeys (qualification); SqlResourceConflictsHaveSpecific409AndDoNotPersist | SQL skipped |
| AS-003 | RejectionsLeaveNoRowsOrKeys (technician); same SQL conflict method | SQL skipped |
| AS-004 | RejectionsLeaveNoRowsOrKeys (bay); same SQL conflict method | SQL skipped |
| AS-005 | HalfOpenOverlapIsSymmetric; OverlapRejectsButAdjacencyIsAllowed | Policy pass; real allocations skipped |
| AS-006 | OverlapRejectsButAdjacencyIsAllowed; AlternatePairAdjacencyServiceCompatibilityAndRetainedReplayUseSavedResults | Unit pass; SQL skipped |
| AS-007 | RestartRetainsConfirmationResourcesAndKeyBinding | Process skipped |
| AS-008 | IndependentConnectionsCannotConfirmCompetingSharedResources; HundredHealthyPairsAcrossTwoProcessesHaveOneConfirmationAndOneBusinessConflict | SQL/process skipped |
| AS-009 | RejectionsLeaveNoRowsOrKeys; InvalidShapeOrReferencesAreRejected; SeededRetrievalNeedsNoBookingAndInvalidRequestsChangeNoRows | Unit/mock pass; SQL skipped |
| AS-010 | SeededRetrievalIsIndependentAndIdentifiersDistinguish400From404; RestartRetainsConfirmationResourcesAndKeyBinding | Mock pass; durability skipped |
| AS-011 | SuccessHasBothLowestNumericAssignmentsAndDerivedDuration; SqlHttpJourneyTests.BookingReplayRetrievalAndProvisionalQueryUseCommittedSqlRows | Unit pass; SQL skipped |
| AS-012 | ConflictingLowestCandidateDoesNotHideAlternativePair; AlternatePairAdjacencyServiceCompatibilityAndRetainedReplayUseSavedResults | Policy pass; SQL skipped |
| AS-013 | SeededRetrievalIsIndependentAndIdentifiersDistinguish400From404 | Mock HTTP pass; SQL not run |
| AS-014 | ReportsFullIntervalReasonAndNoticeWithoutReservations; QueryIsProvisionalThenReflectsBookingsWithoutReservingCapacity | Unit/mock pass; SQL skipped |
| AS-015 | same availability methods; MissingResourcesAndShiftGapsAreReadOnlyUnavailableResults | Unit/mock pass; SQL skipped |
| AS-016 | PositiveQueryDoesNotReservePairAndStaleBookingRechecksUnderSqlLock | SQL skipped |
| AS-017 | ValidationPrecedesResourceReads; InvalidTimestampsHaveStableProblemCode | Unit/mock pass |
| AS-018 | ExactScheduleBoundariesAreIncludedButPartialCoverageFails; FullIntervalRejectsShiftGapOrEndAfterClosing | Policy pass; SQL skipped |
| AS-019 | GapAndMissingHoursFailClosed; FullIntervalRejectsDealerAndTechnicianGapsInOrder | Unit pass; SQL skipped |
| AS-020 | EquivalentOffsetsNormalizeToUtc; NamedZoneFollowsSeasonalOffsets; KeysAcrossProcessesHaveOneBindingOrIndependentDealerScope (offset) | Unit pass; process skipped |
| AS-021 | EndIsElapsedDurationWithoutBufferAndPreservesTicks; DstBoundaryWindowIsExcludedUnaffectedWindowCanCoverElapsedService | Unit duration policy pass; multi-zone SQL skipped |
| AS-022 | BaysHaveNoServiceCapabilityFilter; AlternatePairAdjacencyServiceCompatibilityAndRetainedReplayUseSavedResults | Unit pass; SQL skipped |
| AS-023 | LowestNumericEligibleIdsWinRegardlessOfInputOrder; SuccessHasBothLowestNumericAssignmentsAndDerivedDuration | Unit pass; SQL skipped |
| AS-024 | InvalidOrRepeatedBoundaryExcludesOnlyThatWindow; InvalidDstBoundaryIsExcludedButAnUnaffectedWindowCanCoverElapsedService | Policy pass; SQL HTTP skipped |
| AS-025 | ReplayNormalizesOffsetAndBypassesExpiredTimeReferencesAndResourceReads; CreationReplayRetrievalAndCapacityHaveContractHeadersAndUtcBodies | Unit/mock pass; durable SQL skipped |
| AS-026 | SameKeyRacesBindOnceWithSparePairsOrRejectChangedPayload; KeysAcrossProcessesHaveOneBindingOrIndependentDealerScope | SQL/process skipped |
| AS-027 | CaseSensitiveKeysUnkeyedRequestsAndFailedKeysAreIndependent | Unit pass; SQL skipped |
| AS-028 | DistinctKeysUseSparePairsAndSameKeyAtSeparateDealersIsIndependent; KeysAcrossProcessesHaveOneBindingOrIndependentDealerScope | SQL/process skipped |
| AS-029 | ReplayNormalizesOffsetAndBypassesExpiredTimeReferencesAndResourceReads; PastConfirmedKeyStillReplaysAfterRestartBeforeFutureValidation | Unit pass; process skipped |
| AS-030 | FailedKeyHasNoDurableBindingAndAllowsCorrectedRequest; RealRollbackRemovesBothAssignmentsAndKey | SQL skipped |
| AS-031 | AmbiguousCommitVerifiesOnceAfterDisposalAndNeverReinserts; RealCommitFollowedBySimulatedAcknowledgementLossIsRecoveredOrReportedUnknown | Fake lifecycle pass; SQL simulation skipped; no actual transport claim |
| AS-032 | TechnicalResponsesPreserveSafeOutcomeAndExposeNoProviderMessage; CancellationBeforeCommitRollsBackAndAfterActualCommitDoesNotClaimRollback | HTTP adapter pass; SQL skipped |

## Success criteria and provenance

SC-001 maps AS-001/009/025/030/032; SC-002 maps AS-008; SC-003 maps AS-005/006; SC-004 maps
AS-007/010; SC-005 maps AS-014–017; SC-006 maps documented three-journey smoke plus clean assessment;
SC-007 maps AS-018/019; SC-008 maps AS-020; SC-009 maps AS-021; SC-010 maps AS-023; SC-011 maps
AS-024; SC-012 maps AS-025–029; SC-013 maps AS-030–032. The named checks and result limits above
apply to each corresponding criterion; SQL-dependent universal/100-pair claims are still unproven.

Original scope is FR-001–FR-010 and AS-001–AS-010 as refined in approved clarification. FR-011–FR-014,
duration/buffer/bay compatibility/numeric selection, replay and failure details are confirmed
assessment assumptions. Budget/retry/default load figures are approved engineering defaults;
performance p95 targets are proposed. Development mock mode and optional OTLP are optional additions
explicitly separated from required SQL guarantees. No source provides the authoritative numbered
grouping for the requested three acceptance requirements; that review question remains open.
