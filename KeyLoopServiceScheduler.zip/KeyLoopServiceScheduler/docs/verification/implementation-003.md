# Remaining implementation — input 003

Scope: `docs/implement-input-003.md`, confirmed after the earlier filename typo. Existing checklist
override persists: requirements 16/16 checked; booking quality review 0/40 checked. Reviewer markers
were not edited. SQL verification gaps remain open while the user-authorized implementation advances.

## Delivered

REST controllers for creation/replay, retrieval, and provisional availability call the existing
application services. Validation rejects unknown/duplicate properties, invalid signed-bigint IDs,
offsetless/overprecision/impossible/range-overflow timestamps, and invalid or multiple keys.
Responses use UTC Z, safe Problem Details, correlation IDs, and matching creation/replay Location.
Health endpoints distinguish liveness from primary SQL access or explicit Mock readiness.

Built-in Development OpenAPI verifies documented route discovery and transforms manually validated
JSON schemas using the embedded approved contract. Components and operations are compared against
that contract; optional parameter required:false is omitted by serialization, the OpenAPI default.
ECMAScript schema checks run against both the approved and runtime-generated documents.

Serilog uses a bounded nonblocking JSON console queue and an operational-field allowlist.
OpenTelemetry uses HTTP/custom activities and finite-label counters/histograms; optional OTLP
traces use bounded batch export. Database and lock spans capture timing in the attempt, then stop
after transaction/context disposal; attempt measurements also emit after disposal. Raw keys,
payloads, SQL parameters/text, customer descriptors, exceptions, and credentials are not logged.

SQL HTTP, stale-availability, cancellation, independent-process races, and restart tests are defined.
The process harness owns isolated databases and launches two Release instances with separate
connections. A performance harness prepares history/windows before serving, runs two processes,
10 mixed callers, 30 s warmup, 120 s measurement, three repetitions per profile, and checks persisted
overlaps/partial rows/duplicate bindings. Actual SQL/performance execution remains unavailable.

## Actual verification

- Locked solution restore passed; new process/load harness dependencies have project lock files.
- Release solution build passed with zero warnings/errors, including the load harness.
- EF migration/model consistency passed: no model changes since the initial migration; no SQL connection or migration application was performed by that check.
- Final complete suite: 83 unit passes; 64 non-SQL integration passes, 39 SQL integration discovery
  groups skipped; four SQL process discovery groups skipped. Zero test failures. Skipped theories
  represent discovery groups rather than expanded parameter cases. Total executed passes: 147.
- Result files: `artifacts/test-results/implementation-003-final/*.trx`, separately timestamped per
  project. An earlier same-name solution TRX run overwrote files; those are not the final evidence.
  Final files end `23_27_48_net10.0.trx` (unit), `23_27_59_net10.0.trx` (integration), and
  `23_28_16_net10.0.trx` (process), with the host/user prefix retained in the artifacts directory.
  Command: `dotnet test KeyLoopServiceScheduler.slnx -c Release --no-restore --logger trx --results-directory artifacts/test-results/implementation-003-final`.
- `node scripts/verification/openapi-schema.mjs` and the same command with
  `artifacts/generated-openapi.json`: passed 256 ASCII character cases, key bounds/Unicode,
  timestamp syntax, response headers. Actual calendar/range/precision checks pass in HTTP tests.
- Live mock HTTP smoke: availability=true, creation=201, retrieval unchanged, replay=200 with the
  same body/Location, UTC Z fields, correlation assessment-01, readiness=200, OpenAPI=200.
  Evidence: `artifacts/implementation-003-smoke.json` and `artifacts/generated-openapi.json`.
  The smoke host was stopped after verification; its data is ephemeral.

## Failures corrected and remaining limits

Initial HTTP baseline: 18 failures against absent routes. Initial observability test build failed
because its types did not exist. Implementation exposed ambiguous metric overloads and scoped
dictionary access compile errors; both corrected. The empty-header test initially failed because
HttpClient omitted an empty outgoing value; the server boundary collection is now tested directly.
Schema harness initially checked regex alone for max length; it now applies schema min/max as well.
Strict OpenAPI comparison exposed only default required:false omission; normalization preserves
its optional semantics. First whitespace verification failed on new initializer formatting; the
  formatter was run and final whitespace verification passed. Process dependency restore initially failed on sandbox TLS; an approved retry
succeeded. Failing assertions were corrected without changing business requirements.

No SQL instance/test connection is configured. No migration was applied and no SQL test database
was created. SQL constraints, concurrency, cancellation/cleanup, commit recovery, restart durability,
and real process acceptance remain unverified. Simulated post-commit failures are explicitly labeled
and do not establish real transport fault behavior. Load results, SQL query plans/logical reads,
and remote lock/DB metric capture are not available. No concurrency or capacity guarantee is claimed.

Before/after extension hook configuration is absent. Existing .gitignore covers .NET, secrets,
generated results, and universal files; Git executable is unavailable. No unrelated ignore files
or infrastructure were added.

Task tracking now records 84 implementation/test-definition/documentation tasks complete, with ten
remaining SQL/performance/assessment checkpoints or partial work open. Final review and clean SQL
assessment are not marked complete merely because their preliminary documentation exists.

Supply SCHEDULER_TEST_CONNECTION externally for an isolated SQL Server 2022 identity with create/drop
privileges, rerun the complete suite, then the performance profile. Close SQL/performance checkpoints
only when real execution supports them. See README, development-environment.md and the final review.
