# Mock mode verification

Executed on 2026-10-09 with the pinned .NET SDK, without SQL Server or a test connection.

`dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-restore`: 83 passed, zero failed.

`dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-restore --logger 'trx;LogFileName=mock-mode-full.trx' --results-directory artifacts/test-results`: 35 passed, 31 SQL groups skipped, zero failed. Evidence: `artifacts/test-results/mock-mode-full.trx`.

Six mock tests verify startup without a connection string, Development-only selection, availability followed by booking, persisted retrieval, replay, payload mismatch, exhausted capacity, independent host state, discard after a staged-operation exception, gate release, and concurrent capacity/replay behavior. HTTP testing exposed and corrected request-scope disposal of the host-owned store. Scoped reader wrappers now borrow the database; only the host owns disposal.

Initial startup also exposed denied Windows Event Log writes. Event Log logging is disabled in API configuration; console logging still reports mock storage and its limitations.

A real local HTTP host was started with Development and `Scheduler__StorageMode=Mock`, no launch profile, and no SQL connection. Requests returned a Mock manifest, available=true, creation 201, replay 200, successful retrieval of the created identity, and `X-Scheduler-Storage: Mock`. The smoke host was stopped after verification.

These checks demonstrate the ephemeral mock adapters only. They provide no SQL constraints, SQL application-lock, cross-process concurrency, durable commit, migration, or SQL recovery evidence. Production HTTP binding and all previously open SQL checkpoints remain pending.
