# Regression verification — T079–T087

Latest run: [non-SQL convergence verification](convergence-nonsql.md): 160 passed, zero failed,
46 SQL/process discovery groups skipped. Earlier input-003 results below are historical.

The complete unit, integration, and process projects were built and invoked. Unit and non-SQL
integration cases passed; every SQL-dependent process/relational group skipped without a test
connection. See [actual results](implementation-003.md). No skips were relabeled as passes.

Defined process scenarios: at least 100 healthy pairs per shared-pair/technician-only/bay-only
variant; same/equivalent-offset/changed/distinct/dealer-scoped keys; restart retrieval and conflict;
historical confirmed key replay after end and restart. Technical outcomes fail healthy race runs.

Defined SQL regressions: stale positive availability followed by authoritative rejection;
cancellation under a held lock, before commit, and after real commit with injected acknowledgement
loss; known rollback versus unknown outcome and key reuse/replay. Existing recovery tests cover
negative results, fresh retries, exhausted verification and failed cleanup policy. No hard SQL
disconnect-release bound is claimed. HTTP timestamp/key/schema/UTC/error/correlation tests pass
against mock adapters; real SQL atomicity, overlapping allocations, persistence and resource
links await execution.

T087 remains open until SQL/process and representative performance evidence actually executes.

Convergence adds five HTTP recovery-guidance cases, one configured startup-warning check, four
local timing-exporter checks and three pure workload/report checks. Those 13 checks pass without
SQL. The ProcessTests assembly now has three pure helper passes; its five real SQL/process groups
still skip. Fixture cleanup now clears only the owning database pool; parallel SQL execution is
still required to verify that correction under live connections. No load profile was run.
