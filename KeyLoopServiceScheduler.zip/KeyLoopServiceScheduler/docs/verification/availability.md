# Availability verification — T032–T037

Latest revalidation: [remaining-task review](implement-002-followup.md). T037 still requires
real SQL; mock results do not satisfy this checkpoint.

Scope: application-level provisional availability; HTTP binding remains phase 6.
Execution date: 2026-10-09. Prior SQL foundation checkpoints T025/T031 remain open.

`QueryAvailability` validates positive IDs, dealer/service references, duration/zone configuration,
representable elapsed interval and future start, then invokes the shared full-coverage evaluator.
Both available and unavailable details include canonical UTC bounds, a deterministic reason and
the exact notice: "Availability is provisional until booking confirmation succeeds."
It uses read-only ports, creates no transaction lock or reservation, and never writes appointments.

## Recorded tests

| Command | Actual result |
|---|---|
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-restore --filter FullyQualifiedName~QueryAvailabilityTests --logger 'trx;LogFileName=availability-red.trx' --results-directory artifacts/test-results/red` | Initial scaffolding had unread constructor parameter errors; after correcting scaffolding, 10 tests failed against NotImplementedException. |
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore --logger 'trx;LogFileName=application.trx' --results-directory artifacts/test-results` | Final run: 83 passed, 0 failed/skipped, including 11 availability cases. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-restore --logger 'trx;LogFileName=booking-integration.trx' --results-directory artifacts/test-results` | Final run: 29 non-database checks passed, 31 SQL groups skipped, including AvailabilityPersistenceTests. |

Unit coverage: AS-014/015 result bounds/notice and available/closed/unqualified/technician/bay reasons;
AS-017 unknown references, past start, overflow and bad zone; AS-019 missing windows/resources;
full-interval dealer/technician gaps and equivalent offset normalization. Pure domain tests also
cover dated window merging, midnight, seasonal offsets and invalid/ambiguous boundaries.

SQL tests are written for committed schedules, alternate pair selection, missing coverage and
unchanged appointment counts/no tracking. They have not run against SQL. Healthy SQL availability,
HTTP acceptance and the later stale-positive booking race are not certified. T037 remains open.
Set SCHEDULER_TEST_CONNECTION to an isolated SQL Server test identity with create/drop privileges
and rerun integration tests; no SQLite/InMemory replacement is supplied.
