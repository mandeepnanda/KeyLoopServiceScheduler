# Observability verification — T072–T078

Latest verification: [non-SQL convergence](convergence-nonsql.md), including the configured
startup logger and local load timing exporter. The input-003 observations below are historical.

Six observability/OpenAPI checks passed in the focused final run. Full-suite results and files are
in [input-003 evidence](implementation-003.md). This is operational telemetry, not a durable audit.

TelemetryContractTests observes four logical bookings: two new confirmations, one replay, and one
resource conflict. Metric labels contain no resource/customer/dealer/key identifiers.
TransactionTelemetryTests observes two attempts for an injected precommit retry, emission only after
fake-unit disposal, and three technical outcomes with zero resource-conflict increments. These are
lifecycle-policy tests; the fake attempt is not a SQL locking proof.

Backpressure tests stall a bounded sink, observe drops and nonblocking enqueue, confirm mock booking
still succeeds, and verify only safe JSON fields survive projection. An injected writer exception
increments drops without escaping. Correlation tests cover validation, health, unknown routes,
valid token preservation and invalid-token replacement.

Actual live console output included this sanitized record (trace ID shortened here):

```json
{"operation":"booking","outcome":"success","reasonCode":"CONFIRMED","traceId":"ac9e2aac...","correlationId":"assessment-01","dealerId":1,"elapsedMs":55.1808}
```

Replay used reasonCode=REPLAY and the same correlation ID. No raw key/body/SQL/exception was emitted.
Lock/DB spans are named operations, with stop deferred until attempt disposal. SQL telemetry and
remote OTLP collector delivery were not exercised; no live transaction timing claim is made.
Queues/export timeout/shutdown flush are bounded and failures cannot change recorded business
results. A crash can lose telemetry; counters and drop observations cannot certify durable totals.

Convergence correction: the startup warning now emits finite structured startup/reason fields.
The configured logger test verifies that it survives filtering and contains no message/exception
field. Four local capture checks verify an actual Mock booking span, timing-field projection,
exclusion of arbitrary tags/events/baggage, contained file-write failure with a drop observation,
and rejection outside Development. Local capture exports on the bounded SDK batch worker;
SQL lock/DB timings and remote OTLP transport remain unverified.
