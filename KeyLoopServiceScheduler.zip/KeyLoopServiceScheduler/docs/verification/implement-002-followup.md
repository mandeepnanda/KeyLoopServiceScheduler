# Remaining availability and booking tasks

Execution date: 2026-10-09. Scope follows `docs/implement-input-002.md`: availability and booking application/persistence tasks through T056. Later REST, observability, process/performance, and delivery tasks require a separate scope decision. Existing reviewer-checklist override remains recorded in tasks.md; reviewer markers were not changed.

## Review and execution

Reviewed the task dependencies, approved plan, domain/schema contracts, transaction coordinator, SQL fixture, independent-connection concurrency tests, rollback/recovery tests, held-lock test, and booking acceptance fixture. The requested implementation and test definitions already exist. The remaining in-scope tasks are verification checkpoints, not missing application code.

| Command/check | Actual result |
|---|---|
| Spec-kit prerequisite script | Passed using process-only PowerShell execution-policy bypass; resolved `specs/001-service-scheduler`. Direct script execution was blocked by the host policy. |
| Reviewer checklists | requirements.md: 16/16 checked; booking.md: 0/40 checked. Existing override preserved. |
| SQL prerequisites | `SCHEDULER_TEST_CONNECTION` and runtime SQL connection unset; no SQL service, registered instance, SQL tooling, or Docker found. No database was created or modified. |
| `dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore` | Passed, zero warnings/errors. |
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore --logger 'trx;LogFileName=implement-002-followup-unit.trx' --results-directory artifacts/test-results` | 83 passed, zero failed/skipped. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-build --no-restore --logger 'trx;LogFileName=implement-002-followup-integration.trx' --results-directory artifacts/test-results` | 35 passed, zero failed, 31 SQL discovery groups skipped. The six mock tests are included in the passes and provide no SQL evidence. |
| `dotnet tool restore` | Initial sandbox NuGet access failed; approved network retry restored pinned dotnet-ef 10.0.12. |
| `dotnet ef migrations has-pending-model-changes --project src/KeyLoopServiceScheduler.Infrastructure --startup-project src/KeyLoopServiceScheduler.Api --configuration Release --no-build` | Passed: no model changes since the last migration. This does not apply the migration or verify SQL constraints. |
| Setup ignore files | Existing .gitignore covers .NET and universal generated files. Git executable unavailable; repository status could not be verified. No additional technology-specific ignore file was required. |
| Extension hooks | `.specify/extensions.yml` absent at pre/post execution; no hooks dispatched. |

## Outstanding checkpoints

| Task | Required evidence still missing |
|---|---|
| T025 | Apply the initial migration to isolated real SQL and pass schema constraints. |
| T031 | Pass SQL migration/seed/query integration checks. |
| T037 | Pass real-SQL availability checks, including unchanged row counts. |
| T055 | Pass SQL booking, rollback, replay, independent-connection races, and held-lock suites. |
| T056 | Execute the provided SQL booking acceptance fixture and record its results. |

None of these tasks was marked complete. Phase dependencies remain unmet. Mock storage cannot demonstrate SQL transactions, locks, durable replay, or database constraints, and no concurrency guarantee is claimed.

## Resume

Configure `SCHEDULER_TEST_CONNECTION` externally for an isolated SQL Server 2022 test instance with create/drop privileges, then rerun the integration command above. Fixtures create uniquely named `KeyLoopScheduler_Test_<GUID>` databases, apply migrations, and dispose their own databases. A configured but unreachable server fails rather than skips. Do not supply a production identity.

The test identity is independent of the application's optional mock setting and its runtime connection. See [SQL setup](../development-environment.md). Close checkpoints only after the corresponding SQL cases actually pass; T057 onward retains its approved dependency gates.
