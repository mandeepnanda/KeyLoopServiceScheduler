# Performance status — T086/T087

No performance run or SQL plan/reads inspection was executed. Proposed p95 objectives in plan.md
are targets, not measured capacity. The load harness compiles in the Release solution. Latest
non-SQL fixes and actual test results are recorded in [convergence-nonsql.md](convergence-nonsql.md).

With an isolated SQL test identity configured externally:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/performance/run-load.ps1
```

The harness owns unique test databases, migrates and seeds before serving two Release processes,
adds a 100k historical profile (optional HistoryRows up to 1m), uses seed 12345, 10 callers with
60/25/15 availability/retrieval/create mix, 30-second warmup, 120-second measurement, and three
repetitions each for distributed slots and a hot dealer. Each repetition uses an independent DB.
Named zones determine request instants; extended dated windows are test data, not new requirements.
History inserts check SQL constraints and occur before API startup. Output groups counts and
p50/p95/p99 by operation and status so fast errors are not reported as successful latency.
Persisted interval running maxima and scoped-key aggregation check overlaps/partial rows/duplicates.

The runner now enables local Development-only bounded batch timing capture for both API processes,
without a remote collector. Separate JSONL files retain allowed scheduler operation names, UTC
bounds, duration and trace ID, excluding tags/events/baggage and HTTP/SQL content. Per-run reports
filter measurement bounds and aggregate lock, transaction and DB-adapter timings/counts/percentiles.
Root coverage is checked; individual child spans may still drop, so capture is not a durable audit.
DB-adapter timings do not establish SQL logical reads. Remote OTLP transport remains unverified.

Distributed booking slots are distinct over warmup/measurement, never wrapping. There are 58,400
dealer/hour slots over 3,650 seeded days; capacity exhaustion fails explicitly. Warmup rows remain
without occupying later distributed slots. Hot-dealer mode deliberately reuses an interval. Reports
include observed success/conflict/technical rates, throughput, outcome counts, warmup attempts,
SQL version/edition/compatibility and API-host environment. Remote SQL hardware needs separate disclosure.

Actual SQL timings, plans/logical reads, parallel process capture and observed profile quality still
require execution. T086/T087 and convergence T099/T101 retain those evidence limits. Pure load/capture
tests pass without SQL; they are not capacity measurements. No caching or speculative optimization
was introduced to meet an unmeasured target.
