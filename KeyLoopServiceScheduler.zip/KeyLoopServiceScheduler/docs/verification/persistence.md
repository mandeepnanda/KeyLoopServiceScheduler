# Persistence verification — T020–T031

Execution date: 2026-10-09. SDK 10.0.401; EF/ASP.NET 10.0.12; SQL Server provider.

## Actual commands and results

Commands ran from the repository root. EF commands use `--project src/KeyLoopServiceScheduler.Infrastructure --startup-project src/KeyLoopServiceScheduler.Api --configuration Release --no-build`.

| Command | Actual result |
|---|---|
| `dotnet ef migrations add InitialScheduler` with the above arguments and `--output-dir Persistence/Migrations` | Initial attempt failed on missing startup EF Design. Added the private tooling reference, restored/rebuilt, then generated successfully. |
| `dotnet ef migrations script --idempotent` with the above arguments and `--output scripts/database/initial-schema.sql` | Passed without connecting to SQL. |
| `dotnet ef migrations has-pending-model-changes` with the above arguments | Passed: no changes since the migration. |
| `dotnet restore KeyLoopServiceScheduler.slnx --locked-mode --ignore-failed-sources` | Latest sandbox attempt failed NU1900 on unreachable vulnerability feed. Warnings were not suppressed. |
| `dotnet restore KeyLoopServiceScheduler.slnx --locked-mode` with approved network access | Passed, vulnerability checks enabled. |
| `dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore` | Final build passed, 0 warnings, 0 errors. |
| `dotnet format whitespace KeyLoopServiceScheduler.slnx --no-restore --verify-no-changes` | Final check passed with no formatting changes required. |
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore --logger 'trx;LogFileName=domain.trx' --results-directory artifacts/test-results` | 40 passed, 0 failed, 0 skipped. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-build --no-restore --logger 'trx;LogFileName=persistence.trx' --results-directory artifacts/test-results` | 12 non-database checks passed, 0 failed, 14 live SQL groups skipped. Skipped theories contain multiple parameter cases; these are discovery-group counts. |

Generated results: `artifacts/test-results/domain.trx` and `persistence.trx`.
Earlier schema-model red run had 2 failures before mappings and 2 passes afterward. A later review
run found 2 failures: early configuration validation prevented host overrides, and the migration
snapshot lagged the corrected status constraint. Both were fixed; the final run passed. The seed/query
increment was checked with its tests but has no recorded pre-implementation red run.

## Implementation decisions

Ten tables use approved types, lengths/nullability, positive reference IDs, restrictive deletes,
and ownership/locality/qualification FKs. Both allocations occupy one confirmed row. The elapsed
duration CHECK uses DATEADD with 100 ns timestamps. Status uses binary comparison and exact byte
length to reject case variants and trailing spaces allowed by ordinary SQL equality. This correction
was made before initial database application to mapping, migration and snapshot; consistency passes.
Replay keys use nullable varchar(128), visible ASCII, binary collation and dealer-scoped filtered
uniqueness. Resource overlap indexes include EndUtc/Status; qualification/local window indexes exist.

SQL Server 2022 compatibility 160, command timeout 5 seconds, connection timeout 1–3 seconds,
MARS disabled, ConnectRetryCount=0 and EF retries disabled match the approved provider policy.
Future booking owns whole-attempt retry and locks; neither is implemented in this scope.

Seed-only mode validates an explicit future base date and both named zones. Fifteen dated days,
qualification/ownership exceptions and one confirmed fixture are reproducible with an injected clock.
A serializable administrative transaction writes fixtures atomically. Matching repeats preserve
rows/CreatedUtc; partial/incompatible references are rejected before writes. Seeding exits before
listening. Serving never migrates/seeds; migration is the separate explicit EF CLI command.

Readers use no-tracking projections. ResourceQueries has six batched queries, SQL filters for local
qualification and half-open overlaps, numeric ID order, and earlier-starting cross-date windows.
Busy qualified resources remain in snapshots to preserve evaluator rejection precedence. These
reads are provisional until later booking supplies a locked attempt context. Runtime permission
example grants reference reads and appointment SELECT/INSERT, with separate administrative identity.
Public database membership supplies the planned application-lock principal.

## Unexecuted live SQL checks

No SQL Server/Docker installation was found and SCHEDULER_TEST_CONNECTION is unset. No database
was created, migration applied, seed written, permission script executed, or query plan measured.
Generated SQL/model checks do not establish relational behavior on a running server.

The suite creates unique disposable class databases, applies migrations, resets between cases using
independently committed connections and injects a fixed clock. Written live tests cover required
appointment/window NULLs; FK ownership/locality/qualification; state/key validity; lengths/positive
IDs/bounds/UTC/restrictive deletes; duration/end mismatch and overflow; 100 ns roundtrip; scoped key
uniqueness/case/nulls; repeat/partial seeding; explicit seed command; saved projections; no tracking
or writes; earlier-date windows; adjacency; and six-query batches at 2 and 52 candidates.
These assertions remain unexecuted against SQL.

Provide an isolated SQL Server 2022 test connection with create/drop privileges through
SCHEDULER_TEST_CONNECTION and rerun the integration command before closing T025/T031. A configured
but unreachable server fails tests rather than skipping. Use the commands in
[development-environment.md](../development-environment.md); do not use production credentials.

T001–T024 and T026–T030 implementation artifacts are provided. T025 is partial; T031 and phase 3's
database checkpoint remain open. T032–T094 were not started. Reviewer checklist markers are unchanged.

Latest revalidation: [remaining-task review](implement-002-followup.md). The migration model is
current, but T025/T031 still require execution against SQL Server.
