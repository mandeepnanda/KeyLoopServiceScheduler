# Domain verification — T008–T019

Execution date: 2026-10-09.

| Command | Actual result |
|---|---|
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-restore --logger 'trx;LogFileName=domain-red.trx' --results-directory artifacts/test-results/red` | Expected red run: 32 failed, 0 passed, targeting temporary policy stubs |
| Same command with `domain-green.trx` and `artifacts/test-results/green` after policies | 32 passed, 0 failed |
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-restore --logger 'trx;LogFileName=domain.trx' --results-directory artifacts/test-results` | 40 passed, 0 failed, 0 skipped, including entity invariants |

Reports are generated under `artifacts/test-results/` (ignored output). Red-run failures were
retained, not suppressed; all temporary NotImplementedException stubs were replaced.

Coverage includes half-open partial/contained/equal overlaps, both adjacency boundaries, one-tick
overlap, UTC normalization, positive elapsed duration, representable-end validation, optional key
limits, positive entity IDs, required/max-length metadata, qualification/locality, lowest numeric
valid pair, gaps/missing schedules, cross-midnight windows, schedule union, seasonal zone offsets,
both repeated/nonexistent boundary kinds and unaffected windows, and a valid window spanning DST.

The domain is pure and does not read a database or authorize a booking. Application ports expose
only domain/projection types and attempt-bound store contracts. Future orchestration must acquire
the dealership lock before populating these policies from authoritative booking data. This test
run does not establish database concurrency safety.
