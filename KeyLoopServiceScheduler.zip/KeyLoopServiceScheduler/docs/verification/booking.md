# Booking verification — T038–T056

Latest revalidation: [remaining-task review](implement-002-followup.md). Build/model consistency
passed; 83 unit and 35 non-SQL integration tests passed, with 31 SQL groups skipped.

Scope: booking application use case, attempt-bound SQL stores, dealership lock, transaction lifecycle,
replay, deadlines/retry/recovery and tests. HTTP endpoints, observability integration and two-process
certification remain later phases. SQL checkpoints are open; no concurrency guarantee is claimed.

## Actual commands and results

All commands ran at repository root, using SDK 10.0.401 and pinned .NET/EF packages.

| Command | Actual result |
|---|---|
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-restore --filter 'FullyQualifiedName~BookAppointmentTests\|FullyQualifiedName~BookingReplayTests' --logger 'trx;LogFileName=booking-red.trx' --results-directory artifacts/test-results/red` | 25 failed before implementation, 0 passed. The actual filter uses a literal pipe; table escaping is Markdown only. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-restore --filter FullyQualifiedName~BookingCoordinatorTests --logger 'trx;LogFileName=coordinator-red.trx' --results-directory artifacts/test-results/red` | 9 failed against the coordinator stub, 1 passed. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-restore --filter FullyQualifiedName~BookingCoordinatorTests --logger 'trx;LogFileName=coordinator-green.trx' --results-directory artifacts/test-results` | Initial implementation: 10 passed. Expanded policy/composition coverage is in the final run below. |
| `dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore` | Final build passed, 0 warnings, 0 errors. An earlier build failed on five xUnit2031 assertions; assertions were corrected to use predicate overloads, without suppressing warnings. |
| `dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore --logger 'trx;LogFileName=application.trx' --results-directory artifacts/test-results` | Final: 83 passed, 0 failed, 0 skipped. Includes 40 domain, 11 availability and 32 booking/replay cases. |
| `dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-restore --logger 'trx;LogFileName=booking-integration.trx' --results-directory artifacts/test-results` | Final: 29 passed, 0 failed, 31 SQL groups skipped. Passed checks are 17 fake-unit lifecycle/composition checks and 12 existing non-database checks. Skipped theories represent groups, not expanded parameter-case counts. |
| `dotnet format whitespace KeyLoopServiceScheduler.slnx --no-restore --verify-no-changes` | Passed with no changes required. |

TRX outputs are under artifacts/test-results; red baselines under its red directory. No package
changes/network restore were needed for this increment. No SQL database was created or modified.

## Reviewed design and implementation

1. Syntax/key validation precedes a transaction. Each request creates one operation GUID, reused
   by internal retry. Authoritative replay/reference/coverage/conflict reads run after acquiring the
   exclusive transaction-owned `scheduler:dealership:<positive bigint>` application lock, using
   invariant formatting, public principal, explicit ReadCommitted and the same connection.
   Procedure return value >=0 grants; negative values abort and clean up. -1 is BOOKING_BUSY,
   -2 REQUEST_TIMEOUT, -3 eligible deadlock retry, -999 INVALID_REFERENCE_CONFIGURATION.
2. Replay comes before references/configuration/future time, compares exact IDs and UTC ticks, and
   returns the saved projection; mismatch rejects without writes. New requests evaluate references,
   ownership, duration/zone, elapsed interval/future start, dealer hours, qualification, technician
   hours/conflicts, then bay conflicts. Lowest eligible numeric IDs determine both assignments.
3. One appointment row stores both assignments and optional key. The attempt-bound store also
   enforces its locked dealer, single insert and operation GUID. SQL SaveChanges and Commit belong
   to that attempt; confirmation is returned only after commit or recovery. Read-only replay and
   business rejections roll back their transaction without inventing a commit outcome.
4. One monotonic 10-second linked deadline covers all response work, including verification.
   Connect/command/lock caps are 3/5/2 seconds; lock wait is also capped by remaining time. Cleanup
   gets an independent 1-second token. Disposal may take longer; there is no hard disconnect lock
   release promise. No query/retry runs during cleanup. A failed rollback after writes produces
   unknown outcome, never an assertion of not_committed or an unsafe retry.
5. EF/SqlClient retries remain disabled. The coordinator permits one whole retry only after known
   precommit rollback, transient classification, complete disposal and remaining jitter plus at
   least one second of useful budget. Jitter is 100–250 ms. Business outcomes, key mismatch,
   lock timeout, cancellation and commit uncertainty are not internally retried. Transient
   classification is a narrow SQL error/deadlock whitelist, not all exceptions.
6. Once commit starts and fails, the old unit is discarded and one fresh-primary GUID lookup may
   run within remaining budget. Found row recovers confirmation; absence/failure/budget exhaustion
   returns BOOKING_OUTCOME_UNKNOWN. No delegate reexecution or reinsertion occurs. The generic
   transaction port reports recovery through an application-owned CommitRecoveredException,
   converted to a confirmation by BookAppointment, preserving the existing generic port.
7. Runtime configuration rejects ApplicationIntent=ReadOnly. DI uses scoped use cases/coordinator/
   factory/verifier, singleton immutable options/clock/zone/lock/retry policies, and fresh owned
   contexts per attempt. Validation proves no scoped capture and no production fault decorator.

## Coverage and unexecuted evidence

| Requirement/scenario | Tests provided | Evidence limit |
|---|---|---|
| Successful confirmation, duration, lowest assignments, alternate pair, all bays support services | BookAppointmentTests; BookingTransactionTests; BookingAcceptanceTests | Pure use-case tests pass; saved SQL rows unverified |
| Unknown references/ownership/configuration/time and rejection precedence | BookAppointmentTests; QueryAvailabilityTests; BookingAcceptanceTests | Unit cases pass; real SQL matrix skipped |
| No qualification, technician unavailable, bay unavailable | Unit orchestration tests; BookingAcceptanceTests | No-write pure cases pass; SQL skipped |
| Overlap and back-to-back for either resource | BookAppointmentTests; BookingConcurrencyTests; BookingAcceptanceTests | Unit half-open decisions pass; SQL writes/races skipped |
| Full hours, gaps, midnight, DST and canonical offsets | Existing domain tests; application tests; BookingAcceptanceTests | Pure policies pass; SQL DST/gap scenarios skipped |
| Key replay/mismatch/reuse, unkeyed independence, case, 100 ns equality, retained replay/dealer scope | BookingReplayTests; BookingTransactionTests; BookingConcurrencyTests; BookingAcceptanceTests | Unit cases pass; durable SQL/restart certification unexecuted |
| Atomic rollback and same connection/transaction | BookingRecoveryTests | SQL tests compiled and skipped; fake policy tests are not atomicity proof |
| Concurrent shared pair, tech-only and bay-only; keyed races; different dealers | BookingConcurrencyTests | Independent-connection tests written, not executed; technical errors fail healthy runs rather than being filtered |
| Busy/deadlock/cancel/config lock results, fresh retry, timeout cleanup | BookingCoordinatorTests; BookingRecoveryTests; DealershipLockTests | Fake lifecycle policies pass; real held lock/transaction/retry checks skipped |
| Commit recovery/unresolved/budget exhaustion | BookingCoordinatorTests; BookingRecoveryTests | Fake policy checks pass; actual SQL commit followed by simulated acknowledgement loss is written but skipped |

BookingFaultDecorator is test-only. Its after-commit scenario performs a real SQL commit and then
throws a simulated connectivity exception; it is not a real network acknowledgement-loss test.
Negative lock/deadlock injection tests label simulated procedure outcomes accurately and exercise
real transactions when SQL is configured. Two-process 100-pair certification, actual transport-fault
verification, HTTP contracts and later acceptance traceability are not established here.

SCHEDULER_TEST_CONNECTION remains unset, with no SQL Server/Docker installation found previously.
Supply an isolated SQL Server 2022 connection with create/drop privileges and rerun the integration
command to establish actual rows, zero overlaps, rollback and lock behavior. Configured but unreachable
SQL fails rather than skipping. Do not point fixture resets at production.

Implementation/test-definition tasks are marked separately from verification checkpoints. T025/T031
remain open from foundation; T037/T055/T056 remain open for SQL/acceptance verification, although
acceptance fixtures are provided. Phase 4/5 checkpoints have not passed. T057 onward was not started.
