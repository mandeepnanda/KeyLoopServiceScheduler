# Setup verification — T001–T007

Execution date: 2026-10-09. SDK 10.0.401; .NET/ASP.NET runtime 10.0.12.

| Command | Actual result |
|---|---|
| `dotnet --list-sdks` / `dotnet --list-runtimes` | .NET 10 SDK/runtime available |
| `git rev-parse --git-dir` | Not run successfully: Git is not installed/on PATH and no repository metadata was found |
| `dotnet restore KeyLoopServiceScheduler.slnx` (sandbox) | Failed with NU1301 TLS authentication errors; no passing claim |
| `dotnet restore KeyLoopServiceScheduler.slnx` (approved escalation) | Passed; seven project lock files generated |
| `dotnet restore KeyLoopServiceScheduler.slnx --locked-mode --ignore-failed-sources` | Passed from restored dependencies |
| `dotnet tool restore` (approved escalation) | Passed; dotnet-ef 10.0.12 restored |
| `dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore` | Passed; zero warnings, zero errors |

Central package versions came from NuGet's stable package index, queried with approved network
access. Application references Domain only; Domain has no packages or web/persistence references;
Infrastructure references Application/Domain; API composes Application/Infrastructure.
Three test projects exist. SDK, packages and EF tool are pinned; `CI=true` enables locked restore.

Startup requires an externally supplied connection string and rejects MARS, provider connection
retries, absent database/server and connection timeouts outside 1–3 seconds. No automatic migration
or serving-time seed path exists. Business endpoints are outside this increment.
