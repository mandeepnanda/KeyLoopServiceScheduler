# API verification — T057–T071

See [input-003 results](implementation-003.md) for commands, result files, and corrected failures.
Nineteen initial contract checks passed using explicit mock storage; later regression and telemetry
tests also passed. These verify HTTP behavior, not SQL persistence.

Creation/replay/retrieval/capacity assertions cover 201/200/409, Location equality, complete saved
bodies without keys, canonical UTC Z, correlation propagation, and safe Problem Details. Retrieval
is independently tested from seeded history with malformed 400 and unknown 404. Availability returns
200 for both eligible and exhausted states, the exact provisional notice, and makes no reservation.
Validation covers missing/duplicate/unknown fields, overflow IDs, timestamp offsets/precision/calendar/
range, empty server-side keys, invalid Unicode/whitespace keys, and technical not_committed/unknown.
Malformed JSON and unsupported body media types also return the approved safe 400 contract. API
transport records are mapped to application inputs after manual strict validation. SQL HTTP tests
add DST affected/unaffected windows and cross-midnight query/booking parity; those groups skip.

Runtime OpenAPI uses approved manual schemas after checking operation discovery. Schema components
match exactly; operations match after removing optional required:false defaults from the expected
document. Node evaluates ECMAScript regex and length semantics for every 0–255 character and bounds.

SqlHttpJourneyTests separately define committed booking/replay/retrieval/query checks, independent
seeded retrieval, resource-specific conflicts, and row-count assertions. Those SQL cases skip without
SCHEDULER_TEST_CONNECTION. T071's real-SQL HTTP journey checkpoint remains open.
