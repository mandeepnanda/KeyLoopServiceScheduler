# AI Collaboration Narrative

## REST and observability increment — input 003

The user confirmed implement-input-003.md after a filename typo and authorized the remaining REST,
telemetry, database test, seed/demo and documentation work. Existing checklist approval persisted.
HTTP tests preceded controllers: 18 initial failures against absent routes. Added strict JSON/query
validation, transport DTOs, safe standardized errors, UTC/correlation/Location contracts and built-in
OpenAPI transformation from approved manual schemas. No business requirement was relaxed for tests.

Observability tests preceded their types (initial build errors). Added bounded sanitized Serilog JSON,
OpenTelemetry activities and logical-request/attempt metrics, with transaction measurements emitted
after unit disposal. Corrected overload/dictionary compiler errors and strengthened observer assertions
so production containment of callback exceptions cannot hide a test failure. Deferred DB/lock span stop
preserves capture intervals while exporting after cleanup. Added SQL HTTP, schedule, cancellation,
stale-query, two-process/replay/restart definitions and a load harness. They compile but SQL evidence is
still unavailable. New harness dependencies restored after an approved retry for sandbox TLS failure.

Reviewed two test issues: HttpClient omits empty outgoing headers, so empty-key presence is asserted
at the real server header collection; OpenAPI pattern and length restrictions are tested together.
Optional required:false omission is normalized in full contract comparison as the standard default.
No requirement change was made. Full suite/results and live mock HTTP smoke are in
docs/verification/implementation-003.md. Whitespace formatting was corrected. No SQL concurrency,
durability, capacity or complete assessment claim is made on skipped tests.

## 2026-10-09 — Foundation, domain and persistence increment

Authorized scope: T001–T031 only. The user explicitly authorized implementation despite the
40 unchecked reviewer-owned booking checklist items; their markers remain unchanged.
Booking use cases, booking endpoints, transaction-lock adapter and telemetry integration remain
later work. No concurrency-safety claim is made by this increment.

Design follows the approved .NET 10 modular monolith, pure domain policies, attempt-bound
application ports, and SQL Server schema. The analysis-approved duration/end CHECK, replay
semantics, decision precedence, and metric definitions remain authoritative.

Implementation verification and corrections are recorded as work proceeds in
`docs/verification/setup.md`, `domain.md`, and `persistence.md`.

Domain tests had a recorded failing baseline (32 failures), then passed and expanded to 40 checks.
Schema tests first failed on the unmapped model, then passed with explicit SQL mappings. Review
corrected startup EF tooling, early configuration validation that prevented host overrides,
migration metadata, test isolation and SQL status comparison semantics. Seed/query tests were
verified in their increment without a recorded prior red run. No substitute database was adopted.

Final build: 0 warnings/errors. Tests: 40 domain and 12 non-database persistence/host checks passed;
14 live SQL groups skipped. Migration/script generation and consistency passed; actual migration
application, relational constraints, seeds and queries remain unverified on SQL. T025/T031 remain
open and phase 3 is not declared complete. An unavailable vulnerability feed was retried with
approved network access instead of suppressing warnings. No reviewer checkbox, booking API,
deployment or later use-case task was changed to claim completion.

## Availability and booking increment — implement-input-002.md

Scope extended to T032–T056, using the existing checklist override without changing reviewer markers.
Prerequisite script execution initially hit PowerShell policy; running the local script with
process-local ExecutionPolicy Bypass succeeded without changing machine policy. SQL remained absent,
so code and test definitions proceeded while database phase checkpoints remained explicitly open.

Recorded red baselines: 10 availability failures, 25 booking/replay failures, and 9 coordinator
failures/1 existing passing helper case. Temporary stubs were removed. Compiler unread-parameter
scaffolding errors and five xUnit analyzer assertion errors were fixed without suppressions.
Reviewed corrections added dealer/operation binding to stores, primary read-write connection intent,
deadline-aware error classification, and conservative unknown outcome after failed write rollback.

The approved generic transaction port was retained: an application-owned recovered-commit signal
returns a durable projection to BookAppointment, avoiding generic result casting or a blind retry.
Fault injection remains test-only; real SQL commit followed by a simulated acknowledgement failure
is distinguished from a genuine transport fault. No production sink work was introduced under locks.

Final Release build passes, 0 warnings/errors. Unit run: 83 passed. Integration project: 29 non-SQL
checks passed and 31 live SQL groups skipped. Pure/lifecycle tests are not SQL concurrency proof.
T037/T055/T056 and existing T025/T031 remain open; HTTP, telemetry and process certification remain
future phases. Verification files record exact commands, limitations and remaining acceptance evidence.
# Optional local mock mode

The user explicitly requested a database mode that runs the application without SQL Server. Added an opt-in Development-only in-memory store, automatic future sample data, and `/demo` availability, booking, and retrieval routes using existing application services. SQL Server remains the default. The store stages writes until successful completion and uses a process-local gate; it is ephemeral and does not emulate database guarantees.

Tests caught request-scope disposal of shared storage and denied Windows Event Log writes; both were corrected. Verification passed 83 unit tests and 35 non-SQL integration tests, with 31 SQL groups skipped. A live HTTP smoke test confirmed creation, retrieval, and replay without a connection string. See `docs/verification/mock-mode.md`; no SQL or production-HTTP task was marked complete on mock evidence.
# Availability and booking follow-up

Reviewed the remaining work requested against implement-input-002.md. Existing implementation and test definitions cover the requested use cases; remaining in-scope checkpoints require a SQL instance, which is still unavailable. Rebuilt and reran suites: 83 unit passes, 35 non-SQL integration passes, 31 SQL groups skipped. Restored the pinned EF tool after an approved network retry and verified migration/model consistency. Preserved task and reviewer checklist markers. Evidence and exact resume instructions are in `docs/verification/implement-002-followup.md`. No SQL concurrency guarantee or completion claim was made.

## 2026-10-10 — Non-SQL convergence implementation

The user limited this pass to remaining convergence work that does not require SQL Server setup
or installation. Existing approval to proceed with the incomplete reviewer booking checklist
persists; its 40 unchecked markers were preserved.

Reviewed the convergence tasks and current error/logging/load/fixture code against the approved
specification, plan and constitution. Corrected unconditional same-key advice for unkeyed unknown
outcomes and GET errors without making keys mandatory. Tests now distinguish original-key replay,
known noncommit and possible unkeyed duplication. Only key presence enters response-guidance context.

The mock startup warning now uses finite structured fields accepted by the real logging pipeline.
Local load capture uses the existing OpenTelemetry SDK and a bounded batch exporter, avoiding a
new external collector dependency. Its field allowlist excludes arbitrary tags/events/baggage and
HTTP/SQL data. File failures are contained. Workload slots never wrap; warmup cannot consume later
distributed booking slots. Reports disclose capture loss, actual rates and environment information.
Fixture disposal clears only its database pool. Live SQL portions remain open rather than being
certified by compilation or Mock tests.

Six focused tests first failed against the prior guidance and suppressed startup warning. Corrected
an xUnit assertion analyzer issue without suppression. A capture build failed on an unavailable
ConfigureBuilder API; the installed SDK's DI configuration callback resolved it. Review also changed
the report label to root coverage: matching roots cannot prove that every child span survived.
No new package, optional infrastructure or speculative database optimization was added.

Final suite: 83 unit, 74 non-SQL integration and three pure load-helper passes; zero failures,
41 SQL integration plus five process discovery groups skipped. These three helper passes do not
prove process safety. Release build/OpenAPI schema checks pass; targeted formatting completed.
Exact commands/TRX and limitations: [convergence evidence](verification/convergence-nonsql.md).
T095/T097/T101 were excluded; T099/T102 source changes are provided with SQL verification outstanding.
README/design/traceability/final review now reflect current evidence. No SQL or complete-assessment
claim was made, and no SQL instance was installed or configured.
