﻿# Keyloop Unified Service Scheduler — 7-minute presentation

Audience: Keyloop technical evaluators. Spoken sections total **7:00**; preparation and command blocks are presenter cues, not spoken text. Allow pauses and command execution within the demonstration’s 90 seconds.

## Before the presentation — not timed

Have [SYSTEM_DESIGN.md](SYSTEM_DESIGN.md) open at the architecture and booking diagrams, plus [verification evidence](verification/convergence-nonsql.md). Build beforehand using the [README](../README.md). Start a fresh Mock instance for the portable demo:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Scheduler__StorageMode = 'Mock'
Remove-Item Env:Scheduler__MockBaseDate -ErrorAction SilentlyContinue
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build --no-launch-profile -- --urls http://localhost:5080
```

In a second PowerShell window, prepare these variables without booking:

```powershell
$base = 'http://localhost:5080'
$manifest = Invoke-RestMethod "$base/demo"
$start = $manifest.exampleBooking.startTime
$query = "$base/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=$([uri]::EscapeDataString($start))"
$body = @{ customerId=1; vehicleId=1; dealershipId=1; serviceTypeId=1; startTime=$start } | ConvertTo-Json
$headers = @{ 'Idempotency-Key'='interview-demo-001'; 'X-Correlation-ID'='interview-001' }
```

The manifest supplies a future date automatically. Keep the same instance running and do not pre-submit the booking. OpenAPI JSON is at `http://localhost:5080/openapi/v1.json`; there is no bundled Swagger UI. Use an API client or the command blocks below to display status, headers and bodies. Rehearse locally; these instructions are not a new execution result.

## 1. Introduction and business problem — 0:00–0:45

“Good morning. This scheduler solves a dealership booking problem: confirming a service appointment requires both a qualified technician and a service bay for the entire service duration.

The difficult part is correctness under contention. Two callers can see the same available slot, but that observation cannot authorize two conflicting confirmations. The system must validate vehicle ownership, qualification and working hours, then assign both resources atomically.

I implemented availability, appointment creation, keyed replay and retrieval as a REST backend. I’ll explain the consistency design, demonstrate the actual API, and distinguish what the recorded tests establish from SQL verification that remains open.”

## 2. Architecture and trade-offs — 0:45–2:15

**Cue:** show the architecture diagram.

“The application is a .NET 10 modular monolith with four projects: API, Application, Domain and Infrastructure.

API handles strict transport validation, HTTP results, correlation and OpenAPI. Application orchestrates booking, availability and retrieval through persistence ports. Domain contains pure scheduling policies. Infrastructure implements SQL Server persistence through EF Core, migrations and transaction coordination. Application does not depend on EF or SQL types.

I chose one deployable application because this problem benefits from one database transaction, rather than distributed reservations and compensation. The boundaries still make policies testable and allow a Development-only Mock adapter.

Reference data and dated calendars are seeded. Services have fixed elapsed durations without buffers. Every bay supports every service, and allocation selects the lowest eligible technician and bay IDs. These are documented clarifications, not hidden implementation assumptions.

The main consistency trade-off is a dealership-wide SQL application lock. It makes the participating-writer protocol straightforward across instances, but serializes bookings at a busy dealership. Different dealerships use separate locks.

The design also includes bounded structured logging and OpenTelemetry. Export should not block booking. Queue saturation can drop telemetry, so operational logs are not a durable audit trail.”

## 3. Booking flow and database consistency — 2:15–3:45

**Cue:** show the booking sequence and relevant schema constraints.

“A booking first validates syntax and generates a stable operation GUID. The SQL adapter then begins a ReadCommitted transaction and acquires an exclusive, transaction-owned dealership application lock before authoritative reads.

If an optional key already identifies a confirmation, matching original details return that appointment. Changed details are rejected. Replay compares canonical instants before current future-time checks, so an old confirmation remains recoverable.

For a new booking, the application checks references and ownership, derives the end from service duration, checks the future interval, and evaluates full dealership and technician coverage plus resource conflicts.

Intervals are half-open: touching appointments are allowed, but any actual overlap is rejected. Local windows use named dealership time zones; ambiguous or nonexistent boundary times exclude the affected window.

One Appointment row stores both required resource assignments. Composite foreign keys enforce ownership, locality and qualification. Checks enforce UTC values, positive duration and duration/end agreement. A filtered unique index binds a request key within a dealership. These constraints do not independently prevent interval overlap; that requires all writers to follow the locking protocol.

Confirmation follows commit. A commit failure may still mean the write succeeded. The coordinator uses one fresh lookup by operation GUID within the remaining deadline; unresolved outcomes are reported as unknown, never blindly reinserted.”

## 4. Live API demonstration — 3:45–5:15

**0–15 seconds — state the boundary and show provisional availability:**

“This demonstration uses Development Mock storage and the actual `/api/v1` controllers and application services. It demonstrates API behavior, not SQL durability or multi-instance locking. Here is the provisional availability response.”

```powershell
Invoke-RestMethod $query | ConvertTo-Json
```

**15–45 seconds — create and retrieve:**

“I submit customer, vehicle, dealership, service and an explicit-offset start time. The server chooses resources and derives the end. The first response should be 201 with a Location and correlation ID. Retrieval returns that confirmation.”

```powershell
$created = Invoke-WebRequest "$base/api/v1/appointments" -Method Post -ContentType 'application/json' -Headers $headers -Body $body -UseBasicParsing
$created.StatusCode
$created.Headers['Location']
$created.Headers['X-Correlation-ID']
$created.Content
Invoke-RestMethod ($base + $created.Headers['Location']) | ConvertTo-Json
```

**45–65 seconds — replay:**

“Repeating the original key and unchanged body should return 200 and the same appointment ID, rather than reserve another pair.”

```powershell
$replayed = Invoke-WebRequest "$base/api/v1/appointments" -Method Post -ContentType 'application/json' -Headers $headers -Body $body -UseBasicParsing
$replayed.StatusCode
$replayed.Content
```

**65–90 seconds — mismatch:**

“With the confirmed key, changing the payload produces 409 KEY_PAYLOAD_MISMATCH. The response is Problem Details with a correlation ID. An unkeyed retry after an unknown commit is different: it can create a duplicate, so the API explicitly warns against assuming rollback.”

```powershell
$changed = @{ customerId=1; vehicleId=2; dealershipId=1; serviceTypeId=1; startTime=$start } | ConvertTo-Json
try {
    Invoke-RestMethod "$base/api/v1/appointments" -Method Post -ContentType 'application/json' -Headers $headers -Body $changed
} catch {
    [int]$_.Exception.Response.StatusCode
    $_.ErrorDetails.Message
}
```

## 5. AI collaboration and verification — 5:15–6:15

**Cue:** show the specification’s clarification entries and recorded test table.

“Spec Kit guided AI through constitution, specification, clarification, plan, tasks and convergence. That created traceability and kept architectural choices and remaining gaps explicit. The constitution required atomic assignment, real cross-instance verification and honest reporting of unexecuted checks.

The user resolved business ambiguities; AI assisted architecture, code and test generation. Recommendations were challenged through source review, contract checks and executable assertions. Corrections included unsafe unkeyed retry advice, suppressed startup diagnostics and wrapping load slots.

The latest recorded run has 160 passes, zero failures and 46 skipped SQL/process groups. Release build and OpenAPI checks passed. The three passing process-project tests are pure helpers, not running-process evidence.

These checks independently test generated behavior against requirements, but they do not establish SQL guarantees. Real-SQL tests for constraints, races, recovery and restart exist; their execution is still required. Passing mocks cannot certify the locking design.”

## 6. Key lessons and limitations — 6:15–7:00

“The main lesson is to separate a plausible design from demonstrated correctness. Availability is advisory, a transaction alone is insufficient for check-then-insert safety, and a commit exception does not prove rollback.

AI was useful when constrained by explicit requirements, small increments, review and tests. Human ownership remained with scope, business clarification and acceptance.

Remaining work includes SQL acceptance, clean setup, measured performance and a load-report failure path found during convergence. Authentication, authorization and production resilience are outside the delivered assessment scope.

My next step would be executing the isolated SQL and two-process acceptance suite, then measuring contention before adding complexity. That would turn the current design and non-SQL evidence into defensible database guarantees.”

## Evidence for follow-up questions — not timed

- [README: setup and AI narrative](../README.md)
- [System design: implemented architecture and future proposals](SYSTEM_DESIGN.md)
- [Specification: recorded business clarifications](../specs/001-service-scheduler/spec.md)
- [Constitution: development and verification rules](../.specify/memory/constitution.md)
- [Actual test commands and TRX evidence](verification/convergence-nonsql.md)
- [AI corrections and development record](ai-collaboration-narrative.md)
- [Source review and acceptance limitations](final-review.md)
- [Remaining convergence tasks](../specs/001-service-scheduler/tasks.md)
