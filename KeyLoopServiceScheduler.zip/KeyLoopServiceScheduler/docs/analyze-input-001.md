Perform a thorough requirements-to-design-to-task consistency review.

Pay special attention to:

- Every mandatory Keyloop requirement being implemented.
- Every booking invariant being tested.
- Concurrency guarantees being supported by the
  actual database and transaction mechanism.
- Qualification and availability checks being performed
  inside the correct booking transaction boundary.
- The API and database schema being consistent.
- All documented assumptions being reflected in design.
- No unplanned frontend or distributed-system complexity.
- No missing documentation or verification deliverables.

Report all gaps with severity and recommended remediation.
Do not silently edit files.
