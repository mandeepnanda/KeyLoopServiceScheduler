Generate dependency-ordered tasks for the approved Keyloop Unified Service Scheduler design.

Organize work into the following logical phases:

Phase 1: Solution setup and project structure.

Phase 2: Domain entities, value objects, qualification
rules, and interval-overlap logic.

Phase 3: EF Core schema, migrations, sample data,
and persistence integration.

Phase 4: Availability query, with unit tests.

Phase 5: Transactionally safe appointment booking,
with integration and concurrency tests.

Phase 6: REST endpoints, validation, OpenAPI,
and standardized error responses.

Phase 7: Structured logging and OpenTelemetry.

Phase 8: Negative tests, edge cases, and regression tests.

Phase 9: System Design Document, README,
AI Collaboration Narrative, and demo instructions.

Requirements:
- Trace tasks to functional requirements and user stories.
- Include test tasks alongside the functionality they verify.
- List explicit acceptance criteria for each phase.
- Identify blocking dependencies.
- Identify tasks safe for parallel implementation.
- Keep each task small and reviewable.
- Do not implement code during task generation.
