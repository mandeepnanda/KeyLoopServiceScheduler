﻿# Keyloop Unified Service Scheduler

A .NET 10 assessment backend for booking dealership service appointments. It provides provisional availability, atomic booking of a qualified technician and service bay, optional keyed replay, and retrieval of confirmed appointments.

**Assessment status:** the implementation and non-SQL verification are delivered. Latest recorded results are **160 passed, 0 failed, 46 SQL/process discovery groups skipped**. Real SQL concurrency, durability, recovery, performance and clean SQL setup acceptance remain unverified. See [verification evidence](docs/verification/convergence-nonsql.md) and [final review](docs/final-review.md).

## Application overview

One modular monolith separates API, Application, Domain and Infrastructure. Booking validates customer/vehicle ownership, service duration, dealership hours, technician qualification and full-interval resource availability. A confirmed appointment contains both assignments in one row. Availability never reserves capacity.

SQL booking uses an explicit transaction and a transaction-owned dealership application lock. Optional idempotency keys identify a booking within one dealership for the appointment’s lifetime. Development Mock mode uses the same application services with ephemeral storage; it provides no SQL durability or cross-process guarantees.

The API is an unauthenticated local assessment backend. Cancellation, rescheduling, calendar administration, payments and notifications are outside scope. See the [system design](docs/SYSTEM_DESIGN.md), [specification](specs/001-service-scheduler/spec.md) and [API contract](specs/001-service-scheduler/contracts/api.md).

## Technology stack

| Area | Technology |
|---|---|
| Runtime/API | .NET 10, ASP.NET Core; SDK 10.0.401 pinned in `global.json` |
| Persistence | SQL Server 2022; EF Core 10.0.12; SqlClient 7.1.1 |
| Contracts | REST, Problem Details, built-in Development OpenAPI |
| Observability | Serilog structured JSON; OpenTelemetry traces and metrics |
| Verification | xUnit, ASP.NET Core test hosts, real-SQL fixtures, two-process/load tooling |
| Design workflow | Spec Kit constitution, specification, plan, tasks and convergence artifacts |

Package versions are [centrally pinned](Directory.Packages.props); the local EF tool is 10.0.12. Logs exclude raw keys, bodies, credentials and SQL text. Optional `Telemetry__OtlpEndpoint` enables export; Development-only local timing capture supports the SQL load harness.

## Prerequisites

- .NET SDK 10.0.401, or a compatible latest patch permitted by `global.json`.
- PowerShell for the commands below; run them from the repository root.
- SQL Server 2022 Developer for local SQL execution, either an existing instance or an independently configured persistent container. Docker is optional. Mock mode needs neither.
- Separate administrative migration/seed credentials and a least-privilege runtime identity. SQL tests need a dedicated development/test identity able to create/drop isolated databases.
- Node.js to run the optional ECMAScript OpenAPI schema validator.

Supply secrets externally. Example integrated-security connections below assume the executing Windows identity already has the stated permissions. `TrustServerCertificate=True` is a local development shortcut; deployed environments need validated certificates. Setup commands are instructions, not evidence that SQL setup was executed on this host.

## Build

```powershell
dotnet --version
dotnet tool restore
dotnet restore KeyLoopServiceScheduler.slnx --locked-mode
dotnet build KeyLoopServiceScheduler.slnx -c Release --no-restore
```

## Database setup and seeding

Use an administrative identity, then apply migrations and seed before serving:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Scheduler__StorageMode = 'SqlServer'
# This Windows identity must have migration/seed permissions.
$env:ConnectionStrings__Scheduler = 'Server=localhost;Database=KeyLoopScheduler;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultipleActiveResultSets=False;ConnectRetryCount=0;Connect Timeout=3'

dotnet ef database update --project src/KeyLoopServiceScheduler.Infrastructure --startup-project src/KeyLoopServiceScheduler.Api --configuration Release

$seedDate = '2030-01-07' # Choose a future date; use the same date in sample requests.
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build --no-launch-profile -- --seed-only --seed-base-date $seedDate
```

Seed data includes two dealerships (Asia/Kolkata and America/New_York), 60/30-minute services, customers/vehicles, technicians, bays, qualifications and 15 dated days of hours. Customer 1 owns vehicle 1. Dealership 1 opens 09:00–17:00; technician 1 works 09:00–12:00 and 13:00–17:00. A historical fixture occupies technician 1/bay 1 at 10:00–11:00 on the first day; the 09:00 sample is adjacent.

Matching repeated seeds preserve data. Incompatible or partial existing seed state is rejected; use an appropriately fresh assessment database rather than editing serving reference data. Serving never migrates or seeds SQL automatically.

Provision the runtime user separately using the reviewed [runtime permission script](scripts/database/runtime-permissions.sql). Map the user to its role as described there: reference SELECT and Appointment SELECT/INSERT, without schema administration or broader inherited grants. Then replace `ConnectionStrings__Scheduler` with that runtime identity’s externally supplied connection string. Integrated security requires running under the separately provisioned runtime Windows identity. See [environment setup](docs/development-environment.md).

## Application startup

For SQL, after provisioning and switching to runtime credentials:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Scheduler__StorageMode = 'SqlServer'
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build --no-launch-profile -- --urls http://localhost:5080
```

For a demonstration without SQL Server:

```powershell
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Scheduler__StorageMode = 'Mock'
$env:Scheduler__MockBaseDate = '2030-01-07' # Choose a future date matching sample requests.
dotnet run --project src/KeyLoopServiceScheduler.Api -c Release --no-build --no-launch-profile -- --urls http://localhost:5080
```

Mock seeds automatically and resets on restart. Open [the demo manifest](http://localhost:5080/demo) to inspect sample dates/IDs. Mock is rejected outside Development; `--seed-only` is for SQL only.

`GET /health/live` tests liveness. `GET /health/ready` checks SQL connectivity or explicitly reports Mock storage; SQL readiness does not certify schema or runtime permissions. Checked-in host filtering permits `localhost` and `127.0.0.1`.

## OpenAPI usage

In Development, retrieve [the runtime OpenAPI JSON](http://localhost:5080/openapi/v1.json) and import it into an API client. There is no bundled Swagger UI. The runtime transformer supplies the approved [OpenAPI schemas](specs/001-service-scheduler/contracts/openapi.json).

```powershell
Invoke-RestMethod 'http://localhost:5080/openapi/v1.json' | ConvertTo-Json -Depth 100 | Set-Content openapi.local.json
node scripts/verification/openapi-schema.mjs
```

The Node validator checks schema semantics; it does not exercise SQL. Ready-to-use requests are in [requests.http](docs/requests.http).

## Sample appointment requests

Run in a second PowerShell window, with a seeded future date matching the running database:

```powershell
$baseUrl = 'http://localhost:5080'
$seedDate = '2030-01-07'
$startTime = "${seedDate}T09:00:00+05:30"
$encodedStart = [Uri]::EscapeDataString($startTime)

# Provisional availability; another caller can consume capacity before booking.
Invoke-RestMethod "$baseUrl/api/v1/availability?dealershipId=1&serviceTypeId=1&startTime=$encodedStart"

$body = @{
    customerId = 1
    vehicleId = 1
    dealershipId = 1
    serviceTypeId = 1
    startTime = $startTime
} | ConvertTo-Json
$headers = @{ 'Idempotency-Key' = 'assessment-booking-001'; 'X-Correlation-ID' = 'assessment-001' }

$booking = Invoke-RestMethod -Method Post -Uri "$baseUrl/api/v1/appointments" -ContentType 'application/json' -Headers $headers -Body $body
Invoke-RestMethod "$baseUrl/api/v1/appointments/$($booking.id)"
# Same key and payload: original confirmation, without another appointment.
Invoke-RestMethod -Method Post -Uri "$baseUrl/api/v1/appointments" -ContentType 'application/json' -Headers $headers -Body $body
```

First POST returns 201; keyed replay returns 200; both include `Location`. Use `Invoke-WebRequest` or an API client to inspect headers/status. Confirmation includes IDs, technician/bay assignments, UTC start/end, duration and `Confirmed` status. The sample interval is 04:30–05:30 UTC. Availability always includes its provisional notice and a reason code.

Inputs reject unknown/duplicate fields. Timestamps require explicit offsets and at most seven fractional digits. Clients cannot choose resources or override duration/end. Keys are case-sensitive visible ASCII, 1–128 characters, scoped to a dealership. Changed details with a confirmed key return 409 `KEY_PAYLOAD_MISMATCH`.

Errors use safe Problem Details and `X-Correlation-ID`: 400 invalid references/input, 409 resource/key conflicts, 404 missing appointment, 503 busy/database/deadline/unknown outcome, 500 configuration/unexpected failure. After keyed uncertainty, retry the **original key and unchanged details**. An unkeyed retry may duplicate an already committed booking; adding a new key cannot recover the original attempt.

## Running tests

After the Release build:

```powershell
dotnet test tests/KeyLoopServiceScheduler.UnitTests -c Release --no-build --no-restore --logger 'trx;LogFileName=unit.trx' --results-directory artifacts/test-results/assessment
dotnet test tests/KeyLoopServiceScheduler.IntegrationTests -c Release --no-build --no-restore --logger 'trx;LogFileName=integration.trx' --results-directory artifacts/test-results/assessment
dotnet test tests/KeyLoopServiceScheduler.ProcessTests -c Release --no-build --no-restore --logger 'trx;LogFileName=process.trx' --results-directory artifacts/test-results/assessment
```

To enable real-SQL integration/process groups, set this externally **before running tests**:

```powershell
# Dedicated development/test identity with create/drop database permission.
$env:SCHEDULER_TEST_CONNECTION = 'Server=localhost;Database=master;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultipleActiveResultSets=False;ConnectRetryCount=0;Connect Timeout=3'
```

Fixtures create uniquely named `KeyLoopScheduler_Test_<GUID>` databases and apply migrations. Do not supply a production server/identity. Tests never replace SQL with SQLite or EF InMemory. Missing configuration explicitly skips SQL groups; a green test-command exit alone does not establish acceptance.

Latest recorded run, 2026-10-10:

| Assembly | Passed | Failed | Skipped discovery groups |
|---|---:|---:|---:|
| Unit | 83 | 0 | 0 |
| Integration | 74 | 0 | 41 |
| ProcessTests | 3 | 0 | 5 |
| Total | 160 | 0 | 46 |

The three ProcessTests passes are pure workload/capture helpers. They do not establish multi-process correctness. [Exact commands and final TRX filenames](docs/verification/convergence-nonsql.md) support these totals; an earlier unit-only file is excluded. Release build recorded zero warnings/errors; OpenAPI ECMAScript validation passed. This README update does not represent a new test execution.

The [SQL load harness](docs/verification/performance.md) additionally checks persisted invariants and collects sanitized timings. It requires SQL; no load measurements or actual query-plan/read evidence have been recorded.

## Troubleshooting

| Symptom | Check/action |
|---|---|
| SDK/tool or locked restore fails | Check `dotnet --version`, `global.json`, tool restore and package-feed access; preserve pinned versions. |
| SQL startup configuration rejected | Supply an explicit server/database, read/write intent, MARS=False, retry count zero and 1–3-second connect timeout. |
| Readiness 503 or SQL permission errors | Check connectivity, credentials, certificates and runtime grants. Apply migrations/seed separately with administrative credentials. |
| Seed rejected or no valid future hours | Align seed/request dates; incompatible/partial seeds need a fresh assessment database. Missing hours mean unavailable. |
| OpenAPI 404 / Mock rejected | Confirm Development and use `--no-launch-profile` so the selected environment is respected. |
| Booking conflict | Inspect `code`; check qualifications, operating/working windows and overlaps. Availability is advisory. |
| Busy or unknown outcome | Distinguish `BOOKING_BUSY` from `BOOKING_OUTCOME_UNKNOWN`; follow original-key guidance and avoid blind unkeyed resubmission. |
| SQL tests skipped | Set `SCHEDULER_TEST_CONNECTION` with isolated test privileges; skips are not passes. |
| Incomplete timing capture | Inspect report/capture artifacts; bounded export can drop spans. Do not claim capacity from incomplete or failed runs. |

These are operational checks derived from implemented behavior, not a claim that each incident occurred during development.

## AI Collaboration Narrative

The narrative below is grounded in the [constitution](.specify/memory/constitution.md), [clarifications](specs/001-service-scheduler/spec.md), [design decisions](specs/001-service-scheduler/research.md), [dated collaboration record](docs/ai-collaboration-narrative.md), [review](docs/final-review.md) and test evidence. Commit history could not be inspected because Git is unavailable in this environment; no commit IDs or commit-based attribution are asserted.

1. **Why Spec Kit:** its constitution → specification → plan → tasks → analysis/convergence workflow provided a practical way to keep assessment requirements, assumptions, implementation and remaining gaps traceable. This explains its fit to the observed workflow; there is no recorded comparative tool-selection exercise.
2. **Constitution guidance:** requirements-first scope, four project boundaries, full-duration atomic assignment, relational constraints, explicit transactions and cross-instance verification governed design. AI output required review; failed/unexecuted checks had to remain visible. Optional infrastructure could not displace mandatory correctness.
3. **Clarifying ambiguity:** recorded question/answer sessions settled full schedule coverage, named zones, fixed buffer-free duration, universal bay compatibility, lowest-ID selection and conservative DST-boundary handling. Later sessions established optional dealership-scoped keys, lifetime replay and reuse after known failure.
4. **AI architecture and coding assistance:** AI helped translate those decisions into domain policies, application ports, EF mappings/migrations, SQL lock coordination, replay/recovery, strict HTTP contracts, telemetry and test definitions. Work proceeded in scoped increments rather than treating generated code as accepted by default.
5. **Recommendations challenged or revised:** review corrected unconditional same-key guidance for unkeyed unknown outcomes and GET failures, logging fields that suppressed the Mock startup warning, wrapping load slots, and process-wide pool cleanup. Capture reporting was revised to say root coverage rather than imply every child span survived. An unavailable OpenTelemetry builder API was replaced with the installed SDK’s supported DI callback. These corrections are recorded; they are not invented debugging stories.
6. **Concurrency and data integrity verification:** pure tests and source review cover overlap rules, selection, transaction lifecycle and conservative recovery. Real-SQL schema/constraint, rollback, keyed-race, restart and two-process tests exist, including at least 100 healthy pairs per shared-resource variant, but their SQL groups were skipped. Therefore cross-instance safety and durable integrity remain unverified. Simulated acknowledgement loss is distinguished from a genuine transport fault.
7. **Tests executed:** the latest recorded suite totals are shown above. Evidence also records initially failing focused tests followed by fixes, Release build and contract checks. Mock HTTP journeys demonstrate transport/application behavior without certifying SQL persistence.
8. **Code-quality review:** documented reviews examined boundaries, ownership/locality/qualification constraints, error precedence, retry/disposal lifecycle, telemetry privacy and test isolation. Compiler/xUnit analyzer issues were corrected without suppression; targeted formatting was completed. Convergence retained missing evidence as open tasks rather than weakening assertions.
9. **Human-owned decisions:** the user supplied scope and clarification answers, authorized each implementation scope and the Development Mock option, and limited the latest convergence implementation to work without SQL setup. Reviewer checklist acceptance remains human-owned: authorization to proceed did not mark the booking checklist approved. Provisioning credentials, production access/security decisions and final assessment acceptance still require the responsible engineer/reviewer.
10. **Remaining limitations:** SQL acceptance, clean setup, live timing capture, measured performance and parallel fixture validation are open. Convergence also found a load-report failure path that can lose collected evidence before report writing (T108). Authentication/authorization, deployment TLS/rate controls, backup/failover and calendar lifecycle features are absent. See [remaining tasks](specs/001-service-scheduler/tasks.md); proposed extensions are separated from delivered behavior in the [system design](docs/SYSTEM_DESIGN.md).

## Assessment evidence

- [Acceptance traceability](docs/acceptance-traceability.md)
- [Booking](docs/verification/booking.md), [availability](docs/verification/availability.md) and [persistence evidence](docs/verification/persistence.md)
- [API/demo instructions](docs/demo-instructions.md) and [Mock mode](docs/mock-mode.md)
- [Review corrections](docs/postimplementation-review-003-results.md) and [final acceptance status](docs/final-review.md)
