using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Domain.Scheduling;

public sealed record LocalWindow(DateTime LocalStart, DateTime LocalEnd);
public sealed record TechnicianCandidate(long Id, long DealershipId, IReadOnlySet<long> QualifiedServiceTypes,
    IReadOnlyList<LocalWindow> WorkingWindows, IReadOnlyList<AppointmentInterval> Bookings);
public sealed record BayCandidate(long Id, long DealershipId, IReadOnlyList<AppointmentInterval> Bookings);
public enum EligibilityReason { Available, DealershipClosed, NoQualifiedTechnician, TechnicianUnavailable, BayUnavailable }
public sealed record EligibilitySelection(EligibilityReason Reason, long? TechnicianId = null, long? ServiceBayId = null);
public sealed class InvalidReferenceConfigurationException(string message) : Exception(message);
