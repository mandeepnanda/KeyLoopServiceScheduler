using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Domain.Scheduling;

/// <summary>Pure allocation policy; callers provide authoritative data within their own transaction boundary.</summary>
public static class EligibilityEvaluator
{
    public static EligibilitySelection Select(long dealershipId, long serviceTypeId, AppointmentInterval interval,
        TimeZoneInfo zone, IReadOnlyList<LocalWindow> dealerWindows, IEnumerable<TechnicianCandidate> technicians,
        IEnumerable<BayCandidate> bays)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(dealershipId);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(serviceTypeId);
        if (!ScheduleCoverage.Covers(interval, dealerWindows, zone))
            return new(EligibilityReason.DealershipClosed);

        var qualified = technicians.Where(t => ResourceEligibility.IsLocalQualified(t, dealershipId, serviceTypeId))
            .OrderBy(t => t.Id).ToArray();
        if (qualified.Length == 0)
            return new(EligibilityReason.NoQualifiedTechnician);

        var technician = qualified.FirstOrDefault(t => ScheduleCoverage.Covers(interval, t.WorkingWindows, zone) &&
            !t.Bookings.Any(interval.Overlaps));
        if (technician is null)
            return new(EligibilityReason.TechnicianUnavailable);

        var bay = bays.Where(b => ResourceEligibility.IsLocalBay(b, dealershipId)).OrderBy(b => b.Id)
            .FirstOrDefault(b => !b.Bookings.Any(interval.Overlaps));
        return bay is null ? new(EligibilityReason.BayUnavailable) : new(EligibilityReason.Available, technician.Id, bay.Id);
    }
}
