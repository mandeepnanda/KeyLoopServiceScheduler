namespace KeyLoopServiceScheduler.Domain.Scheduling;

public sealed class TimeZoneResolver : IZoneResolver
{
    public TimeZoneInfo Resolve(string zoneId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(zoneId))
                throw new InvalidReferenceConfigurationException("A named IANA time zone is required.");
            var zone = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
            if (!zone.HasIanaId)
                throw new InvalidReferenceConfigurationException("The dealership zone must use an IANA identifier.");
            return zone;
        }
        catch (TimeZoneNotFoundException)
        {
            throw new InvalidReferenceConfigurationException("The named dealership zone is unavailable.");
        }
        catch (InvalidTimeZoneException)
        {
            throw new InvalidReferenceConfigurationException("The named dealership zone is invalid.");
        }
    }
}
