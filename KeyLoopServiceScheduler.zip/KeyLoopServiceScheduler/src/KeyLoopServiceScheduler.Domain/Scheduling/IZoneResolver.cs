namespace KeyLoopServiceScheduler.Domain.Scheduling;

public interface IZoneResolver { TimeZoneInfo Resolve(string zoneId); }
