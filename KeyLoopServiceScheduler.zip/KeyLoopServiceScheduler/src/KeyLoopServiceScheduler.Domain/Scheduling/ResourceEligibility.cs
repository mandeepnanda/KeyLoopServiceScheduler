namespace KeyLoopServiceScheduler.Domain.Scheduling;

public static class ResourceEligibility
{
    public static bool IsLocalQualified(TechnicianCandidate technician, long dealershipId, long serviceTypeId) =>
        technician.Id > 0 && technician.DealershipId == dealershipId &&
        technician.QualifiedServiceTypes.Contains(serviceTypeId);

    public static bool IsLocalBay(BayCandidate bay, long dealershipId) =>
        bay.Id > 0 && bay.DealershipId == dealershipId;
}
