using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Domain.Scheduling;

public static class ScheduleCoverage
{
    public static bool Covers(AppointmentInterval requested, IEnumerable<LocalWindow> windows, TimeZoneInfo zone) =>
        ResolveAndMerge(windows, zone).Any(window => window.StartUtc <= requested.StartUtc && window.EndUtc >= requested.EndUtc);

    public static IReadOnlyList<AppointmentInterval> ResolveAndMerge(IEnumerable<LocalWindow> windows, TimeZoneInfo zone)
    {
        ArgumentNullException.ThrowIfNull(windows);
        ArgumentNullException.ThrowIfNull(zone);
        var valid = new List<AppointmentInterval>();
        foreach (var window in windows)
        {
            if (window.LocalStart.Kind != DateTimeKind.Unspecified || window.LocalEnd.Kind != DateTimeKind.Unspecified ||
                window.LocalEnd <= window.LocalStart)
                throw new InvalidReferenceConfigurationException("Dated schedule bounds must be increasing unspecified local clock values.");
            if (zone.IsInvalidTime(window.LocalStart) || zone.IsAmbiguousTime(window.LocalStart) ||
                zone.IsInvalidTime(window.LocalEnd) || zone.IsAmbiguousTime(window.LocalEnd))
                continue;
            valid.Add(new AppointmentInterval(TimeZoneInfo.ConvertTimeToUtc(window.LocalStart, zone),
                TimeZoneInfo.ConvertTimeToUtc(window.LocalEnd, zone)));
        }

        var merged = new List<AppointmentInterval>();
        foreach (var window in valid.OrderBy(w => w.StartUtc).ThenBy(w => w.EndUtc))
        {
            if (merged.Count == 0 || window.StartUtc > merged[^1].EndUtc)
            {
                merged.Add(window);
                continue;
            }
            if (window.EndUtc > merged[^1].EndUtc)
                merged[^1] = new AppointmentInterval(merged[^1].StartUtc, window.EndUtc);
        }
        return merged;
    }
}
