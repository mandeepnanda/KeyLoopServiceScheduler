namespace KeyLoopServiceScheduler.Domain.ValueObjects;

public sealed record ServiceDuration
{
    public int Minutes { get; }
    public ServiceDuration(int minutes)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(minutes);
        Minutes = minutes;
    }

    public DateTimeOffset DeriveEnd(DateTimeOffset start)
    {
        var utc = start.ToUniversalTime();
        var ticks = checked((long)Minutes * TimeSpan.TicksPerMinute);
        if (ticks > DateTimeOffset.MaxValue.UtcTicks - utc.UtcTicks)
            throw new ArgumentOutOfRangeException(nameof(start), "The derived end is outside the representable UTC range.");
        return utc.AddTicks(ticks);
    }
}
