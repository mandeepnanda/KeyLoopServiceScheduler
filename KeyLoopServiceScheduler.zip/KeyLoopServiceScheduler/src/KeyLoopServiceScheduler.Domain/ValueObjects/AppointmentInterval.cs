namespace KeyLoopServiceScheduler.Domain.ValueObjects;

/// <summary>UTC instants in a half-open interval: start inclusive, end exclusive.</summary>
public sealed record AppointmentInterval
{
    public DateTimeOffset StartUtc { get; }
    public DateTimeOffset EndUtc { get; }

    public AppointmentInterval(DateTimeOffset start, DateTimeOffset end)
    {
        if (end <= start)
            throw new ArgumentException("An appointment interval must have positive elapsed duration.", nameof(end));
        StartUtc = start.ToUniversalTime();
        EndUtc = end.ToUniversalTime();
    }

    public bool Overlaps(AppointmentInterval other)
    {
        ArgumentNullException.ThrowIfNull(other);
        return StartUtc < other.EndUtc && EndUtc > other.StartUtc;
    }
}
