namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class Customer
{
    public long Id { get; private set; }
    public string? DisplayName { get; private set; }
    private Customer() { }
    public Customer(long id, string? displayName = null)
    {
        Id = EntityGuard.Id(id, nameof(id)); DisplayName = EntityGuard.Text(displayName, 200, nameof(displayName));
    }
}
