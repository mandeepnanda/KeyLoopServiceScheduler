using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Domain.Entities;

/// <summary>Complete immutable confirmation; construction does not perform or authorize booking allocation.</summary>
public sealed class Appointment
{
    public Guid Id { get; private set; }
    public long CustomerId { get; private set; }
    public long VehicleId { get; private set; }
    public long DealershipId { get; private set; }
    public long ServiceTypeId { get; private set; }
    public long TechnicianId { get; private set; }
    public long ServiceBayId { get; private set; }
    public DateTimeOffset StartUtc { get; private set; }
    public DateTimeOffset EndUtc { get; private set; }
    public int DurationMinutes { get; private set; }
    public string Status { get; private set; } = "Confirmed";
    public string? RequestKey { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }

    private Appointment() { }

    public Appointment(Guid id, long customerId, long vehicleId, long dealershipId, long serviceTypeId,
        long technicianId, long serviceBayId, DateTimeOffset start, int durationMinutes, DateTimeOffset created,
        string? requestKey = null)
    {
        if (id == Guid.Empty) throw new ArgumentException("Appointment identity must be nonempty.", nameof(id));
        if (requestKey is not null && (requestKey.Length is < 1 or > 128 || requestKey.Any(c => c is < '!' or > '~')))
            throw new ArgumentException("Keys must contain 1–128 visible ASCII characters without whitespace.", nameof(requestKey));
        Id = id;
        CustomerId = EntityGuard.Id(customerId, nameof(customerId));
        VehicleId = EntityGuard.Id(vehicleId, nameof(vehicleId));
        DealershipId = EntityGuard.Id(dealershipId, nameof(dealershipId));
        ServiceTypeId = EntityGuard.Id(serviceTypeId, nameof(serviceTypeId));
        TechnicianId = EntityGuard.Id(technicianId, nameof(technicianId));
        ServiceBayId = EntityGuard.Id(serviceBayId, nameof(serviceBayId));
        var duration = new ServiceDuration(durationMinutes);
        StartUtc = start.ToUniversalTime();
        EndUtc = duration.DeriveEnd(start);
        DurationMinutes = duration.Minutes;
        CreatedUtc = created.ToUniversalTime();
        RequestKey = requestKey;
    }
}
