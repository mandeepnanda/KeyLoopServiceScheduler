namespace KeyLoopServiceScheduler.Domain.Entities;

internal static class EntityGuard
{
    public static long Id(long value, string parameter)
    {
        if (value <= 0) throw new ArgumentOutOfRangeException(parameter, "Reference identifiers must be positive.");
        return value;
    }

    public static string? Text(string? value, int maxLength, string parameter, bool required = false)
    {
        if (required && string.IsNullOrWhiteSpace(value)) throw new ArgumentException("A value is required.", parameter);
        if (value?.Length > maxLength) throw new ArgumentOutOfRangeException(parameter, "The value exceeds the configured maximum length.");
        return value;
    }

    public static void Window(DateTime start, DateTime end)
    {
        if (start.Kind != DateTimeKind.Unspecified || end.Kind != DateTimeKind.Unspecified || end <= start)
            throw new ArgumentException("Schedules require increasing dated, unspecified local clock values.");
    }
}
