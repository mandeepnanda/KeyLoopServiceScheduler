namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class Technician
{
    public long Id { get; private set; }
    public long DealershipId { get; private set; }
    public string? DisplayName { get; private set; }
    private Technician() { }
    public Technician(long id, long dealershipId, string? displayName = null)
    {
        Id = EntityGuard.Id(id, nameof(id)); DealershipId = EntityGuard.Id(dealershipId, nameof(dealershipId)); DisplayName = EntityGuard.Text(displayName, 200, nameof(displayName));
    }
}
