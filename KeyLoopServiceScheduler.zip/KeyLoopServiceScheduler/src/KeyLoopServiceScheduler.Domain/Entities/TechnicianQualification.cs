namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class TechnicianQualification
{
    public long TechnicianId { get; private set; }
    public long ServiceTypeId { get; private set; }
    private TechnicianQualification() { }
    public TechnicianQualification(long technicianId, long serviceTypeId)
    {
        TechnicianId = EntityGuard.Id(technicianId, nameof(technicianId)); ServiceTypeId = EntityGuard.Id(serviceTypeId, nameof(serviceTypeId));
    }
}
