namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class DealershipOperatingWindow
{
    public long Id { get; private set; }
    public long DealershipId { get; private set; }
    public DateTime LocalStart { get; private set; }
    public DateTime LocalEnd { get; private set; }
    private DealershipOperatingWindow() { }
    public DealershipOperatingWindow(long id, long dealershipId, DateTime localStart, DateTime localEnd)
    {
        EntityGuard.Window(localStart, localEnd); Id = EntityGuard.Id(id, nameof(id)); DealershipId = EntityGuard.Id(dealershipId, nameof(dealershipId)); LocalStart = localStart; LocalEnd = localEnd;
    }
}
