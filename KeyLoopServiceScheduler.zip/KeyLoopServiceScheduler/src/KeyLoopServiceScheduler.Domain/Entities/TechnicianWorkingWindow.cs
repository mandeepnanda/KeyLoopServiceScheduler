namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class TechnicianWorkingWindow
{
    public long Id { get; private set; }
    public long TechnicianId { get; private set; }
    public DateTime LocalStart { get; private set; }
    public DateTime LocalEnd { get; private set; }
    private TechnicianWorkingWindow() { }
    public TechnicianWorkingWindow(long id, long technicianId, DateTime localStart, DateTime localEnd)
    {
        EntityGuard.Window(localStart, localEnd); Id = EntityGuard.Id(id, nameof(id)); TechnicianId = EntityGuard.Id(technicianId, nameof(technicianId)); LocalStart = localStart; LocalEnd = localEnd;
    }
}
