namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class ServiceType
{
    public long Id { get; private set; }
    public string Name { get; private set; } = null!;
    public int DurationMinutes { get; private set; }
    private ServiceType() { }
    public ServiceType(long id, string name, int durationMinutes)
    {
        Id = EntityGuard.Id(id, nameof(id)); Name = EntityGuard.Text(name, 100, nameof(name), true)!; DurationMinutes = new ValueObjects.ServiceDuration(durationMinutes).Minutes;
    }
}
