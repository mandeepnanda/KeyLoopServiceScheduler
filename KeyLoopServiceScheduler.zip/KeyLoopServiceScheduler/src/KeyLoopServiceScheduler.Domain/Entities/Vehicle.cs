namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class Vehicle
{
    public long Id { get; private set; }
    public long CustomerId { get; private set; }
    public string? Description { get; private set; }
    private Vehicle() { }
    public Vehicle(long id, long customerId, string? description = null)
    {
        Id = EntityGuard.Id(id, nameof(id)); CustomerId = EntityGuard.Id(customerId, nameof(customerId)); Description = EntityGuard.Text(description, 200, nameof(description));
    }
}
