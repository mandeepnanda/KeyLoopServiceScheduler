namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class Dealership
{
    public long Id { get; private set; }
    public string Name { get; private set; } = null!;
    public string TimeZoneId { get; private set; } = null!;
    private Dealership() { }
    public Dealership(long id, string name, string timeZoneId)
    {
        Id = EntityGuard.Id(id, nameof(id)); Name = EntityGuard.Text(name, 200, nameof(name), true)!; TimeZoneId = EntityGuard.Text(timeZoneId, 100, nameof(timeZoneId), true)!; _ = new Scheduling.TimeZoneResolver().Resolve(TimeZoneId);
    }
}
