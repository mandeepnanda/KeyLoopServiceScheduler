namespace KeyLoopServiceScheduler.Domain.Entities;

public sealed class ServiceBay
{
    public long Id { get; private set; }
    public long DealershipId { get; private set; }
    public string? Name { get; private set; }
    private ServiceBay() { }
    public ServiceBay(long id, long dealershipId, string? name = null)
    {
        Id = EntityGuard.Id(id, nameof(id)); DealershipId = EntityGuard.Id(dealershipId, nameof(dealershipId)); Name = EntityGuard.Text(name, 100, nameof(name));
    }
}
