using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Application.Availability;

public sealed record AvailabilityQuery(long DealershipId, long ServiceTypeId, DateTimeOffset StartTime);
public sealed record AvailabilityDetails(long DealershipId, long ServiceTypeId, DateTimeOffset StartTime,
    DateTimeOffset EndTime, bool Available, string ReasonCode,
    string Notice = "Availability is provisional until booking confirmation succeeds.");
public sealed record AvailabilityResult(AvailabilityDetails? Details, Failure? Failure)
{
    public static AvailabilityResult Rejected(FailureCode code) => new(null, new(code));
}
