using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using System.Diagnostics;
using KeyLoopServiceScheduler.Application.Observability;

namespace KeyLoopServiceScheduler.Application.Availability;

public sealed class QueryAvailability(IAvailabilityReader reader, TimeProvider clock, IZoneResolver zones)
{
    public async Task<AvailabilityResult> ExecuteAsync(AvailabilityQuery query, CancellationToken cancellationToken = default)
    {
        using var activity = SchedulerTelemetry.Activities.StartActivity("availability");
        var watch = Stopwatch.StartNew();
        try { return await ExecuteCoreAsync(query, cancellationToken); }
        finally { SchedulerTelemetry.Availability(watch.Elapsed.TotalMilliseconds); }
    }
    private async Task<AvailabilityResult> ExecuteCoreAsync(AvailabilityQuery query, CancellationToken cancellationToken)
    {
        if (query.DealershipId <= 0 || query.ServiceTypeId <= 0) return AvailabilityResult.Rejected(FailureCode.INVALID_REQUEST);
        var references = await reader.ReadReferencesAsync(query.DealershipId, query.ServiceTypeId, cancellationToken);
        if (references.Dealership is null) return AvailabilityResult.Rejected(FailureCode.UNKNOWN_DEALERSHIP);
        if (references.ServiceType is null) return AvailabilityResult.Rejected(FailureCode.UNKNOWN_SERVICE_TYPE);
        if (references.ServiceType.DurationMinutes <= 0) return AvailabilityResult.Rejected(FailureCode.INVALID_REFERENCE_CONFIGURATION);
        try
        {
            var zone = zones.Resolve(references.Dealership.TimeZoneId);
            AppointmentInterval interval;
            try { interval = new(query.StartTime, new ServiceDuration(references.ServiceType.DurationMinutes).DeriveEnd(query.StartTime)); }
            catch (ArgumentOutOfRangeException) { return AvailabilityResult.Rejected(FailureCode.INVALID_START_TIME); }
            if (interval.StartUtc <= clock.GetUtcNow()) return AvailabilityResult.Rejected(FailureCode.INVALID_START_TIME);
            var resources = await reader.ReadResourcesAsync(query.DealershipId, query.ServiceTypeId, interval, cancellationToken);
            var selection = EligibilityEvaluator.Select(query.DealershipId, query.ServiceTypeId, interval, zone,
                resources.DealerWindows, resources.Technicians, resources.Bays);
            return new(new(query.DealershipId, query.ServiceTypeId, interval.StartUtc, interval.EndUtc,
                selection.Reason == EligibilityReason.Available,
                selection.Reason == EligibilityReason.Available ? "AVAILABLE" : SchedulingDecision.Code(selection.Reason).ToString()), null);
        }
        catch (InvalidReferenceConfigurationException) { return AvailabilityResult.Rejected(FailureCode.INVALID_REFERENCE_CONFIGURATION); }
    }
}
