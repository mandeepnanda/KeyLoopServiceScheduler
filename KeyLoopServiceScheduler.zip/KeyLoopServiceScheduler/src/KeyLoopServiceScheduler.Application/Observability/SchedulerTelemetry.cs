using System.Diagnostics;
using System.Diagnostics.Metrics;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Application.Observability;

public static class SchedulerTelemetry
{
    public const string Name = "KeyLoopServiceScheduler";
    public static readonly ActivitySource Activities = new(Name);
    public static readonly Meter Meter = new(Name);
    private static readonly Counter<long> Requests = Meter.CreateCounter<long>("booking.requests");
    private static readonly Counter<long> Attempts = Meter.CreateCounter<long>("booking.attempts");
    private static readonly Counter<long> Confirmations = Meter.CreateCounter<long>("booking.confirmations");
    private static readonly Counter<long> Replays = Meter.CreateCounter<long>("booking.replays");
    private static readonly Counter<long> Conflicts = Meter.CreateCounter<long>("booking.conflicts");
    private static readonly Counter<long> Mismatches = Meter.CreateCounter<long>("booking.key_mismatch");
    private static readonly Counter<long> LockFailures = Meter.CreateCounter<long>("booking.lock.failures");
    private static readonly Histogram<double> TransactionDuration = Meter.CreateHistogram<double>("booking.transaction.duration", "ms");
    private static readonly Histogram<double> LockDuration = Meter.CreateHistogram<double>("booking.lock.wait.duration", "ms");
    private static readonly Histogram<double> AvailabilityDuration = Meter.CreateHistogram<double>("availability.duration", "ms");
    private static long dropped;
    private static readonly ObservableCounter<long> Drops = Meter.CreateObservableCounter("telemetry.dropped", () => Interlocked.Read(ref dropped));
    public static void Dropped() => Interlocked.Increment(ref dropped);
    public static bool IsResourceConflict(FailureCode? code) => code is FailureCode.NO_QUALIFIED_TECHNICIAN or FailureCode.DEALERSHIP_CLOSED or FailureCode.TECHNICIAN_UNAVAILABLE or FailureCode.BAY_UNAVAILABLE;
    // Observer/exporter failures must never change a committed business result.
    private static void Observe(Action action) { try { action(); } catch (Exception) { Dropped(); } }
    public static void Booking(BookingResult result) => Observe(() =>
    {
        var reason = result.Failure?.Code.ToString() ?? (result.IsReplay ? "REPLAY" : "CONFIRMED");
        Requests.Add(1, new KeyValuePair<string, object?>("reasonCode", reason));
        if (result.Appointment is not null) { if (result.IsReplay) Replays.Add(1); else Confirmations.Add(1); }
        if (IsResourceConflict(result.Failure?.Code)) Conflicts.Add(1, new KeyValuePair<string, object?>("reasonCode", reason));
        if (result.Failure?.Code == FailureCode.KEY_PAYLOAD_MISMATCH) Mismatches.Add(1);
    });
    public static void Attempt(double elapsedMs, double? lockMs, int? lockResult) => Observe(() =>
    {
        Attempts.Add(1);
        TransactionDuration.Record(elapsedMs);
        if (lockMs is not null) LockDuration.Record(lockMs.Value);
        if (lockResult is < 0) LockFailures.Add(1, new KeyValuePair<string, object?>("reasonCode", lockResult switch { -1 => "timeout", -2 => "cancel", -3 => "deadlock", _ => "call-error" }));
    });
    public static void Availability(double elapsedMs) => Observe(() => AvailabilityDuration.Record(elapsedMs));
}
