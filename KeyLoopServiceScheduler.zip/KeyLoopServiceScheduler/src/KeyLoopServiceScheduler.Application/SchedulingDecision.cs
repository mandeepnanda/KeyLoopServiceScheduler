using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;

namespace KeyLoopServiceScheduler.Application;

internal static class SchedulingDecision
{
    public static FailureCode Code(EligibilityReason reason) => reason switch
    {
        EligibilityReason.DealershipClosed => FailureCode.DEALERSHIP_CLOSED,
        EligibilityReason.NoQualifiedTechnician => FailureCode.NO_QUALIFIED_TECHNICIAN,
        EligibilityReason.TechnicianUnavailable => FailureCode.TECHNICIAN_UNAVAILABLE,
        EligibilityReason.BayUnavailable => FailureCode.BAY_UNAVAILABLE,
        _ => throw new ArgumentOutOfRangeException(nameof(reason))
    };
}
