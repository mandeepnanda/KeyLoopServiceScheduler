using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Application.Booking;

public static class BookingPayloadComparer
{
    public static bool Matches(BookingRequest request, AppointmentProjection saved) =>
        request.CustomerId == saved.CustomerId && request.VehicleId == saved.VehicleId &&
        request.DealershipId == saved.DealershipId && request.ServiceTypeId == saved.ServiceTypeId &&
        request.StartTime.UtcTicks == saved.StartTime.UtcTicks;
}
