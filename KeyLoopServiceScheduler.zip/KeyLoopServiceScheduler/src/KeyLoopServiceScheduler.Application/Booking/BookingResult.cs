using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Application.Booking;

public sealed record BookingRequest(long CustomerId, long VehicleId, long DealershipId, long ServiceTypeId,
    DateTimeOffset StartTime, string? RequestKey = null);
public sealed record BookingResult(AppointmentProjection? Appointment, bool IsReplay, Failure? Failure)
{
    public static BookingResult Confirmed(AppointmentProjection appointment, bool replay = false) => new(appointment, replay, null);
    public static BookingResult Rejected(FailureCode code, PersistenceOutcome? outcome = null) => new(null, false, new(code, outcome));
}
