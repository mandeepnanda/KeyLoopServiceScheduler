using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Application.Observability;

namespace KeyLoopServiceScheduler.Application.Booking;

public sealed class BookAppointment(IBookingTransaction transaction, TimeProvider clock, IZoneResolver zones)
{
    public async Task<BookingResult> ExecuteAsync(BookingRequest request, CancellationToken cancellationToken = default)
    {
        using var activity = SchedulerTelemetry.Activities.StartActivity("booking");
        BookingResult result;
        try { result = await ExecuteCoreAsync(request, cancellationToken); }
        catch (Exception)
        {
            SchedulerTelemetry.Booking(BookingResult.Rejected(FailureCode.INTERNAL_ERROR));
            throw;
        }
        activity?.SetTag("reasonCode", result.Failure?.Code.ToString() ?? (result.IsReplay ? "REPLAY" : "CONFIRMED"));
        SchedulerTelemetry.Booking(result);
        return result;
    }
    private async Task<BookingResult> ExecuteCoreAsync(BookingRequest request, CancellationToken cancellationToken)
    {
        if (request.CustomerId <= 0 || request.VehicleId <= 0 || request.DealershipId <= 0 || request.ServiceTypeId <= 0)
            return BookingResult.Rejected(FailureCode.INVALID_REQUEST);
        if (request.RequestKey is not null && (request.RequestKey.Length is < 1 or > 128 || request.RequestKey.Any(c => c is < '!' or > '~')))
            return BookingResult.Rejected(FailureCode.INVALID_KEY);
        var operationId = Guid.NewGuid();
        try
        {
            return await transaction.ExecuteAsync(request.DealershipId, operationId, async (attempt, token) =>
            {
                var store = attempt.Store;
                if (request.RequestKey is not null)
                {
                    var saved = await store.FindConfirmedAsync(request.DealershipId, request.RequestKey, token);
                    if (saved is not null) return BookingPayloadComparer.Matches(request, saved)
                        ? BookingResult.Confirmed(saved, true) : BookingResult.Rejected(FailureCode.KEY_PAYLOAD_MISMATCH);
                }
                var references = await store.ReadReferencesAsync(request.CustomerId, request.VehicleId, request.DealershipId, request.ServiceTypeId, token);
                if (references.Customer is null) return BookingResult.Rejected(FailureCode.UNKNOWN_CUSTOMER);
                if (references.Vehicle is null) return BookingResult.Rejected(FailureCode.UNKNOWN_VEHICLE);
                if (references.Dealership is null) return BookingResult.Rejected(FailureCode.UNKNOWN_DEALERSHIP);
                if (references.ServiceType is null) return BookingResult.Rejected(FailureCode.UNKNOWN_SERVICE_TYPE);
                if (references.Vehicle.CustomerId != request.CustomerId) return BookingResult.Rejected(FailureCode.VEHICLE_CUSTOMER_MISMATCH);
                if (references.ServiceType.DurationMinutes <= 0) return BookingResult.Rejected(FailureCode.INVALID_REFERENCE_CONFIGURATION);
                try
                {
                    var zone = zones.Resolve(references.Dealership.TimeZoneId);
                    AppointmentInterval interval;
                    try { interval = new(request.StartTime, new ServiceDuration(references.ServiceType.DurationMinutes).DeriveEnd(request.StartTime)); }
                    catch (ArgumentOutOfRangeException) { return BookingResult.Rejected(FailureCode.INVALID_START_TIME); }
                    var decisionTime = clock.GetUtcNow();
                    if (interval.StartUtc <= decisionTime) return BookingResult.Rejected(FailureCode.INVALID_START_TIME);
                    var resources = await store.ReadResourcesAsync(request.DealershipId, request.ServiceTypeId, interval, token);
                    var selection = EligibilityEvaluator.Select(request.DealershipId, request.ServiceTypeId, interval, zone,
                        resources.DealerWindows, resources.Technicians, resources.Bays);
                    if (selection.Reason != EligibilityReason.Available) return BookingResult.Rejected(SchedulingDecision.Code(selection.Reason));
                    var appointment = new Appointment(attempt.OperationId, request.CustomerId, request.VehicleId, request.DealershipId,
                        request.ServiceTypeId, selection.TechnicianId!.Value, selection.ServiceBayId!.Value, interval.StartUtc,
                        references.ServiceType.DurationMinutes, decisionTime, request.RequestKey);
                    await store.AddAsync(appointment, token);
                    // This value becomes visible to the caller only after the coordinator commits.
                    return BookingResult.Confirmed(AppointmentProjection.From(appointment));
                }
                catch (InvalidReferenceConfigurationException) { return BookingResult.Rejected(FailureCode.INVALID_REFERENCE_CONFIGURATION); }
            }, cancellationToken);
        }
        catch (CommitRecoveredException recovered) { return BookingResult.Confirmed(recovered.Appointment); }
        catch (BookingTransactionException failure) { return new(null, false, failure.Failure); }
    }
}
