namespace KeyLoopServiceScheduler.Application.Contracts;

/// <summary>Safe lifecycle outcome; never carries provider text across the application boundary.</summary>
public sealed class BookingTransactionException(Failure failure) : Exception(failure.Code.ToString())
{
    public Failure Failure { get; } = failure;
}

/// <summary>Generic transaction port recovers a committed confirmation without reinvoking its delegate.</summary>
public sealed class CommitRecoveredException(AppointmentProjection appointment) : Exception("Commit verified")
{
    public AppointmentProjection Appointment { get; } = appointment;
}
