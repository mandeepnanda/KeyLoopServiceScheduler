using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;

namespace KeyLoopServiceScheduler.Application.Contracts;

public sealed record AvailabilityReferences(Dealership? Dealership, ServiceType? ServiceType);
public sealed record BookingReferences(Customer? Customer, Vehicle? Vehicle, Dealership? Dealership, ServiceType? ServiceType);
public sealed record ResourceSnapshot(IReadOnlyList<LocalWindow> DealerWindows,
    IReadOnlyList<TechnicianCandidate> Technicians, IReadOnlyList<BayCandidate> Bays);
