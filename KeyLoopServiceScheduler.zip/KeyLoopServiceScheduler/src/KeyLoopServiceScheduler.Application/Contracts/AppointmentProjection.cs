using KeyLoopServiceScheduler.Domain.Entities;

namespace KeyLoopServiceScheduler.Application.Contracts;

public sealed record AppointmentProjection(Guid Id, long CustomerId, long VehicleId, long DealershipId,
    long ServiceTypeId, long TechnicianId, long ServiceBayId, DateTimeOffset StartTime,
    DateTimeOffset EndTime, int DurationMinutes, string Status)
{
    public static AppointmentProjection From(Appointment row) => new(row.Id, row.CustomerId, row.VehicleId,
        row.DealershipId, row.ServiceTypeId, row.TechnicianId, row.ServiceBayId,
        row.StartUtc, row.EndUtc, row.DurationMinutes, row.Status);
}
