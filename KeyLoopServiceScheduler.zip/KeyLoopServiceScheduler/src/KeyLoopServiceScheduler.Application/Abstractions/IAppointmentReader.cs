using KeyLoopServiceScheduler.Application.Contracts;
namespace KeyLoopServiceScheduler.Application.Abstractions;

public interface IAppointmentReader
{
    Task<AppointmentProjection?> GetAsync(Guid id, CancellationToken cancellationToken = default);
}
