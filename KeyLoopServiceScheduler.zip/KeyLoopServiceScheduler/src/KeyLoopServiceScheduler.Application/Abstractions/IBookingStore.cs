using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Application.Abstractions;

/// <summary>Later booking adapter must be bound to the attempt's context/connection/transaction.</summary>
public interface IBookingStore
{
    Task<AppointmentProjection?> FindConfirmedAsync(long dealershipId, string requestKey, CancellationToken cancellationToken);
    Task<BookingReferences> ReadReferencesAsync(long customerId, long vehicleId, long dealershipId, long serviceTypeId, CancellationToken cancellationToken);
    Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken);
    Task AddAsync(Appointment appointment, CancellationToken cancellationToken);
}
