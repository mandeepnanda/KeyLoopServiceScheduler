using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.ValueObjects;
namespace KeyLoopServiceScheduler.Application.Abstractions;

public interface IAvailabilityReader
{
    Task<AvailabilityReferences> ReadReferencesAsync(long dealershipId, long serviceTypeId, CancellationToken cancellationToken = default);
    Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken = default);
}
