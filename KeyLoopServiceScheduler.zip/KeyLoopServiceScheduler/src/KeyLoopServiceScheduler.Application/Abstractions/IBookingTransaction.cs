namespace KeyLoopServiceScheduler.Application.Abstractions;

/// <summary>Only ports cross this boundary. SQL lifecycle and attempt creation remain Infrastructure concerns.</summary>
public interface IBookingTransaction
{
    Task<TResult> ExecuteAsync<TResult>(long dealershipId, Guid operationId,
        Func<IBookingAttempt, CancellationToken, Task<TResult>> work, CancellationToken cancellationToken);
}
public interface IBookingAttempt
{
    Guid OperationId { get; }
    IBookingStore Store { get; }
}
