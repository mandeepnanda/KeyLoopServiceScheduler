using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Application.Appointments;

public sealed record AppointmentResult(AppointmentProjection? Appointment, Failure? Failure);
public sealed class GetAppointment(IAppointmentReader reader)
{
    public async Task<AppointmentResult> ExecuteAsync(Guid id, CancellationToken token = default)
    {
        var appointment = await reader.GetAsync(id, token);
        return appointment is null ? new(null, new(FailureCode.APPOINTMENT_NOT_FOUND)) : new(appointment, null);
    }
}
