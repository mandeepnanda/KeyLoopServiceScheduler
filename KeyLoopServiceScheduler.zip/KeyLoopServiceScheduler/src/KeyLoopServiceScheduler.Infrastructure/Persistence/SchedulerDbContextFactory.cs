using KeyLoopServiceScheduler.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence;

/// <summary>Offline migration generation does not connect to SQL or bootstrap the HTTP application.</summary>
public sealed class SchedulerDbContextFactory : IDesignTimeDbContextFactory<SchedulerDbContext>
{
    public SchedulerDbContext CreateDbContext(string[] args)
    {
        var connection = Environment.GetEnvironmentVariable("ConnectionStrings__Scheduler") ??
            "Server=localhost;Database=KeyLoopScheduler;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=False;ConnectRetryCount=0;Connect Timeout=3";
        var options = SchedulerDatabaseOptions.Parse(connection);
        return new SchedulerDbContext(new DbContextOptionsBuilder<SchedulerDbContext>()
            .UseSqlServer(options.ConnectionString, sql => sql.UseCompatibilityLevel(160).CommandTimeout(SchedulerDatabaseOptions.CommandTimeoutSeconds)).Options);
    }
}
