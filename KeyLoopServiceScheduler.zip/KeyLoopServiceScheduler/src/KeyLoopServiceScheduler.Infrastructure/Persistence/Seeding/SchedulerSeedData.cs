using System.Text.Json;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;

/// <summary>Explicit, pre-serving fixtures. Refuses to merge or rewrite existing reference data.</summary>
public sealed class SchedulerSeedData
{
    public static readonly Guid HistoryId = Guid.Parse("11111111-1111-1111-1111-111111111111");
    public List<Customer> Customers { get; } = [new(1, "Sample customer one"), new(2, null)];
    public List<Vehicle> Vehicles { get; } = [new(1, 1, "Sample vehicle"), new(2, 2, null)];
    public List<Dealership> Dealerships { get; } = [new(1, "Kolkata", "Asia/Kolkata"), new(2, "New York", "America/New_York")];
    public List<ServiceType> Services { get; } = [new(1, "Oil service", 60), new(2, "Diagnostics", 30)];
    public List<Technician> Technicians { get; } = [new(1, 1, "Primary"), new(2, 1, null), new(3, 2, "Remote"), new(4, 2, null)];
    public List<TechnicianQualification> Qualifications { get; } = [new(1, 1), new(1, 2), new(2, 1), new(3, 1), new(3, 2)];
    public List<ServiceBay> Bays { get; } = [new(1, 1, "One"), new(2, 1, null), new(3, 2, "Three"), new(4, 2, null)];
    public List<DealershipOperatingWindow> DealerWindows { get; } = [];
    public List<TechnicianWorkingWindow> WorkingWindows { get; } = [];
    public Appointment History { get; }

    private SchedulerSeedData(DateOnly baseDate, TimeProvider clock)
    {
        var now = clock.GetUtcNow();
        if (baseDate <= DateOnly.FromDateTime(now.UtcDateTime) || baseDate > DateOnly.MaxValue.AddDays(-14))
            throw new ArgumentOutOfRangeException(nameof(baseDate), "Supply a future base date with room for 15 dated days.");
        long dealerWindowId = 1, workingWindowId = 1;
        for (var day = 0; day < 15; day++)
        {
            var date = baseDate.AddDays(day);
            var open = date.ToDateTime(new TimeOnly(9, 0), DateTimeKind.Unspecified);
            var close = date.ToDateTime(new TimeOnly(17, 0), DateTimeKind.Unspecified);
            foreach (var dealer in Dealerships) DealerWindows.Add(new(dealerWindowId++, dealer.Id, open, close));
            foreach (var technician in Technicians)
            {
                if (technician.Id == 1)
                {
                    WorkingWindows.Add(new(workingWindowId++, technician.Id, open, open.AddHours(3)));
                    WorkingWindows.Add(new(workingWindowId++, technician.Id, open.AddHours(4), close));
                }
                else WorkingWindows.Add(new(workingWindowId++, technician.Id, open, close));
            }
        }
        var zone = new TimeZoneResolver().Resolve(Dealerships[0].TimeZoneId);
        var start = new DateTimeOffset(TimeZoneInfo.ConvertTimeToUtc(
            baseDate.ToDateTime(new TimeOnly(10, 0), DateTimeKind.Unspecified), zone));
        History = new(HistoryId, 1, 1, 1, 1, 1, 1, start, 60, now, "seed-confirmed-001");
    }

    public static SchedulerSeedData Create(DateOnly baseDate, TimeProvider clock) => new(baseDate, clock);

    public static async Task ApplyAsync(SchedulerDbContext context, DateOnly baseDate, TimeProvider clock,
        CancellationToken cancellationToken = default)
    {
        var seed = Create(baseDate, clock);
        // This administrative transaction is confined to the seed-only process, never a serving instance.
        await using var transaction = await context.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, cancellationToken);
        var empty = await MatchesOrEmpty(context.Customers, seed.Customers, x => x.Id, cancellationToken);
        var states = new[]
        {
            empty,
            await MatchesOrEmpty(context.Vehicles, seed.Vehicles, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.Dealerships, seed.Dealerships, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.ServiceTypes, seed.Services, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.Technicians, seed.Technicians, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.TechnicianQualifications, seed.Qualifications, x => (x.TechnicianId, x.ServiceTypeId), cancellationToken),
            await MatchesOrEmpty(context.ServiceBays, seed.Bays, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.DealershipOperatingWindows, seed.DealerWindows, x => x.Id, cancellationToken),
            await MatchesOrEmpty(context.TechnicianWorkingWindows, seed.WorkingWindows, x => x.Id, cancellationToken)
        };
        if (states.Any(state => state != empty)) throw new InvalidOperationException("Partial seed or incompatible reference data; no changes applied.");
        var saved = await context.Appointments.AsNoTracking().SingleOrDefaultAsync(x => x.Id == HistoryId, cancellationToken);
        if (!empty)
        {
            // CreatedUtc is the original seed-run timestamp; repeat runs preserve it.
            if (saved is null || saved.CustomerId != seed.History.CustomerId || saved.VehicleId != seed.History.VehicleId ||
                saved.DealershipId != seed.History.DealershipId || saved.ServiceTypeId != seed.History.ServiceTypeId ||
                saved.TechnicianId != seed.History.TechnicianId || saved.ServiceBayId != seed.History.ServiceBayId ||
                saved.StartUtc != seed.History.StartUtc || saved.EndUtc != seed.History.EndUtc ||
                saved.DurationMinutes != seed.History.DurationMinutes || saved.Status != "Confirmed" || saved.RequestKey != seed.History.RequestKey)
                throw new InvalidOperationException("Existing seed history differs; no changes applied.");
            await transaction.CommitAsync(cancellationToken);
            return;
        }
        if (saved is not null || await context.Appointments.AnyAsync(cancellationToken))
            throw new InvalidOperationException("Seeding requires an empty appointment table when references are empty.");
        context.AddRange(seed.Customers); context.AddRange(seed.Vehicles); context.AddRange(seed.Dealerships);
        context.AddRange(seed.Services); context.AddRange(seed.Technicians); context.AddRange(seed.Qualifications);
        context.AddRange(seed.Bays); context.AddRange(seed.DealerWindows); context.AddRange(seed.WorkingWindows);
        context.Add(seed.History);
        await context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    private static async Task<bool> MatchesOrEmpty<T, TKey>(DbSet<T> table, IEnumerable<T> expected,
        Func<T, TKey> key, CancellationToken cancellationToken) where T : class
    {
        var rows = await table.AsNoTracking().ToListAsync(cancellationToken);
        if (rows.Count == 0) return true;
        if (JsonSerializer.Serialize(rows.OrderBy(key)) != JsonSerializer.Serialize(expected.OrderBy(key)))
            throw new InvalidOperationException($"Existing {typeof(T).Name} data differs; no changes applied.");
        return false;
    }
}
