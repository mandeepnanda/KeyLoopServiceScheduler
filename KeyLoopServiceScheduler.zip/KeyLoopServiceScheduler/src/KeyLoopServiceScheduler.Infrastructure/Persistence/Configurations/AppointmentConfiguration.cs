using KeyLoopServiceScheduler.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Configurations;

public sealed class AppointmentConfiguration : IEntityTypeConfiguration<Appointment>
{
    public void Configure(EntityTypeBuilder<Appointment> entity)
    {
        entity.ToTable("Appointment", table =>
        {
            table.HasCheckConstraint("CK_Appointment_Status", "[Status] COLLATE Latin1_General_100_BIN2 = 'Confirmed' AND DATALENGTH([Status]) = 9");
            table.HasCheckConstraint("CK_Appointment_Interval", "[EndUtc] > [StartUtc]");
            table.HasCheckConstraint("CK_Appointment_Duration", "[DurationMinutes] > 0");
            table.HasCheckConstraint("CK_Appointment_DurationEnd", "[EndUtc] = DATEADD(minute, [DurationMinutes], [StartUtc])");
            table.HasCheckConstraint("CK_Appointment_Utc",
                "DATEPART(TZOFFSET, [StartUtc]) = 0 AND DATEPART(TZOFFSET, [EndUtc]) = 0 AND DATEPART(TZOFFSET, [CreatedUtc]) = 0");
            table.HasCheckConstraint("CK_Appointment_RequestKey",
                "[RequestKey] IS NULL OR (DATALENGTH([RequestKey]) BETWEEN 1 AND 128 AND [RequestKey] NOT LIKE '%[^!-~]%')");
        });
        entity.HasKey(a => a.Id);
        entity.Property(a => a.Id).ValueGeneratedNever();
        entity.Property(a => a.CustomerId).IsRequired();
        entity.Property(a => a.VehicleId).IsRequired();
        entity.Property(a => a.DealershipId).IsRequired();
        entity.Property(a => a.ServiceTypeId).IsRequired();
        entity.Property(a => a.TechnicianId).IsRequired();
        entity.Property(a => a.ServiceBayId).IsRequired();
        entity.Property(a => a.StartUtc).HasColumnType("datetimeoffset(7)").HasPrecision(7).IsRequired();
        entity.Property(a => a.EndUtc).HasColumnType("datetimeoffset(7)").HasPrecision(7).IsRequired();
        entity.Property(a => a.CreatedUtc).HasColumnType("datetimeoffset(7)").HasPrecision(7).IsRequired();
        entity.Property(a => a.DurationMinutes).IsRequired();
        entity.Property(a => a.Status).IsUnicode(false).HasMaxLength(16).IsRequired();
        entity.Property(a => a.RequestKey).IsUnicode(false).HasMaxLength(128)
            .UseCollation("Latin1_General_100_BIN2").IsRequired(false);

        entity.HasOne<Customer>().WithMany().HasForeignKey(a => a.CustomerId).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<Dealership>().WithMany().HasForeignKey(a => a.DealershipId).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<ServiceType>().WithMany().HasForeignKey(a => a.ServiceTypeId).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<Vehicle>().WithMany().HasForeignKey(a => new { a.VehicleId, a.CustomerId })
            .HasPrincipalKey(v => new { v.Id, v.CustomerId }).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<Technician>().WithMany().HasForeignKey(a => new { a.TechnicianId, a.DealershipId })
            .HasPrincipalKey(t => new { t.Id, t.DealershipId }).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<ServiceBay>().WithMany().HasForeignKey(a => new { a.ServiceBayId, a.DealershipId })
            .HasPrincipalKey(b => new { b.Id, b.DealershipId }).OnDelete(DeleteBehavior.Restrict);
        entity.HasOne<TechnicianQualification>().WithMany().HasForeignKey(a => new { a.TechnicianId, a.ServiceTypeId })
            .HasPrincipalKey(q => new { q.TechnicianId, q.ServiceTypeId }).OnDelete(DeleteBehavior.Restrict);
    }
}
