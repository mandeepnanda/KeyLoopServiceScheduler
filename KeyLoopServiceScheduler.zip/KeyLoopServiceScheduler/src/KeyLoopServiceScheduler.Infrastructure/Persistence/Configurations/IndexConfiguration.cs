using KeyLoopServiceScheduler.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Configurations;

internal static class IndexConfiguration
{
    public static void Apply(ModelBuilder model)
    {
        model.Entity<Appointment>().HasIndex(a => new { a.DealershipId, a.RequestKey }).IsUnique()
            .HasFilter("[RequestKey] IS NOT NULL").HasDatabaseName("UX_Appointment_Dealer_RequestKey");
        model.Entity<Appointment>().HasIndex(a => new { a.TechnicianId, a.StartUtc })
            .IncludeProperties(a => new { a.EndUtc, a.Status }).HasFilter("[Status] = 'Confirmed'");
        model.Entity<Appointment>().HasIndex(a => new { a.ServiceBayId, a.StartUtc })
            .IncludeProperties(a => new { a.EndUtc, a.Status }).HasFilter("[Status] = 'Confirmed'");
        model.Entity<TechnicianQualification>().HasIndex(q => new { q.ServiceTypeId, q.TechnicianId });
        model.Entity<Technician>().HasIndex(t => new { t.DealershipId, t.Id });
        model.Entity<ServiceBay>().HasIndex(b => new { b.DealershipId, b.Id });
        model.Entity<DealershipOperatingWindow>().HasIndex(w => new { w.DealershipId, w.LocalStart }).IncludeProperties(w => w.LocalEnd);
        model.Entity<TechnicianWorkingWindow>().HasIndex(w => new { w.TechnicianId, w.LocalStart }).IncludeProperties(w => w.LocalEnd);
    }
}
