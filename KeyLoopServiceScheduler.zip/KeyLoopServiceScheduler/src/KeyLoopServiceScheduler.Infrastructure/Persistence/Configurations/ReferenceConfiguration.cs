using KeyLoopServiceScheduler.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Configurations;

internal static class ReferenceConfiguration
{
    private static EntityTypeBuilder<T> Reference<T>(ModelBuilder model, string table) where T : class
    {
        var entity = model.Entity<T>();
        entity.ToTable(table, t => t.HasCheckConstraint($"CK_{table}_Id_Positive", "[Id] > 0"));
        entity.HasKey("Id");
        entity.Property<long>("Id").ValueGeneratedNever();
        return entity;
    }

    public static void Apply(ModelBuilder model)
    {
        var customer = Reference<Customer>(model, "Customer");
        customer.Property(c => c.DisplayName).HasMaxLength(200).IsRequired(false);

        var vehicle = Reference<Vehicle>(model, "Vehicle");
        vehicle.Property(v => v.Description).HasMaxLength(200).IsRequired(false);
        vehicle.HasAlternateKey(v => new { v.Id, v.CustomerId });
        vehicle.HasOne<Customer>().WithMany().HasForeignKey(v => v.CustomerId).OnDelete(DeleteBehavior.Restrict);

        var dealer = Reference<Dealership>(model, "Dealership");
        dealer.Property(d => d.Name).HasMaxLength(200).IsRequired();
        dealer.Property(d => d.TimeZoneId).HasMaxLength(100).IsRequired();

        var service = Reference<ServiceType>(model, "ServiceType");
        service.Property(s => s.Name).HasMaxLength(100).IsRequired();
        service.Property(s => s.DurationMinutes).IsRequired();
        service.ToTable("ServiceType", t => t.HasCheckConstraint("CK_ServiceType_Duration_Positive", "[DurationMinutes] > 0"));

        var technician = Reference<Technician>(model, "Technician");
        technician.Property(t => t.DisplayName).HasMaxLength(200).IsRequired(false);
        technician.HasAlternateKey(t => new { t.Id, t.DealershipId });
        technician.HasOne<Dealership>().WithMany().HasForeignKey(t => t.DealershipId).OnDelete(DeleteBehavior.Restrict);

        var qualification = model.Entity<TechnicianQualification>();
        qualification.ToTable("TechnicianQualification");
        qualification.HasKey(q => new { q.TechnicianId, q.ServiceTypeId });
        qualification.HasOne<Technician>().WithMany().HasForeignKey(q => q.TechnicianId).OnDelete(DeleteBehavior.Restrict);
        qualification.HasOne<ServiceType>().WithMany().HasForeignKey(q => q.ServiceTypeId).OnDelete(DeleteBehavior.Restrict);

        var bay = Reference<ServiceBay>(model, "ServiceBay");
        bay.Property(b => b.Name).HasMaxLength(100).IsRequired(false);
        bay.HasAlternateKey(b => new { b.Id, b.DealershipId });
        bay.HasOne<Dealership>().WithMany().HasForeignKey(b => b.DealershipId).OnDelete(DeleteBehavior.Restrict);

        var operating = Reference<DealershipOperatingWindow>(model, "DealershipOperatingWindow");
        operating.Property(w => w.LocalStart).HasColumnType("datetime2(7)").HasPrecision(7).IsRequired();
        operating.Property(w => w.LocalEnd).HasColumnType("datetime2(7)").HasPrecision(7).IsRequired();
        operating.ToTable("DealershipOperatingWindow", t => t.HasCheckConstraint("CK_DealershipOperatingWindow_Bounds", "[LocalEnd] > [LocalStart]"));
        operating.HasOne<Dealership>().WithMany().HasForeignKey(w => w.DealershipId).OnDelete(DeleteBehavior.Restrict);

        var working = Reference<TechnicianWorkingWindow>(model, "TechnicianWorkingWindow");
        working.Property(w => w.LocalStart).HasColumnType("datetime2(7)").HasPrecision(7).IsRequired();
        working.Property(w => w.LocalEnd).HasColumnType("datetime2(7)").HasPrecision(7).IsRequired();
        working.ToTable("TechnicianWorkingWindow", t => t.HasCheckConstraint("CK_TechnicianWorkingWindow_Bounds", "[LocalEnd] > [LocalStart]"));
        working.HasOne<Technician>().WithMany().HasForeignKey(w => w.TechnicianId).OnDelete(DeleteBehavior.Restrict);
    }
}
