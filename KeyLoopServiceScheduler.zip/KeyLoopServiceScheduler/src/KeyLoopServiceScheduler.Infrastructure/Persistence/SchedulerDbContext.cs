using KeyLoopServiceScheduler.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Configurations;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence;

public sealed class SchedulerDbContext(DbContextOptions<SchedulerDbContext> options) : DbContext(options)
{
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    public DbSet<Dealership> Dealerships => Set<Dealership>();
    public DbSet<ServiceType> ServiceTypes => Set<ServiceType>();
    public DbSet<Technician> Technicians => Set<Technician>();
    public DbSet<TechnicianQualification> TechnicianQualifications => Set<TechnicianQualification>();
    public DbSet<ServiceBay> ServiceBays => Set<ServiceBay>();
    public DbSet<DealershipOperatingWindow> DealershipOperatingWindows => Set<DealershipOperatingWindow>();
    public DbSet<TechnicianWorkingWindow> TechnicianWorkingWindows => Set<TechnicianWorkingWindow>();
    public DbSet<Appointment> Appointments => Set<Appointment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ReferenceConfiguration.Apply(modelBuilder);
        modelBuilder.ApplyConfiguration(new AppointmentConfiguration());
        IndexConfiguration.Apply(modelBuilder);
    }
}
