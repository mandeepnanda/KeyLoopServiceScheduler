using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitialScheduler : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customer",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.Id);
                    table.CheckConstraint("CK_Customer_Id_Positive", "[Id] > 0");
                });

            migrationBuilder.CreateTable(
                name: "Dealership",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    TimeZoneId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dealership", x => x.Id);
                    table.CheckConstraint("CK_Dealership_Id_Positive", "[Id] > 0");
                });

            migrationBuilder.CreateTable(
                name: "ServiceType",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DurationMinutes = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServiceType", x => x.Id);
                    table.CheckConstraint("CK_ServiceType_Duration_Positive", "[DurationMinutes] > 0");
                    table.CheckConstraint("CK_ServiceType_Id_Positive", "[Id] > 0");
                });

            migrationBuilder.CreateTable(
                name: "Vehicle",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    CustomerId = table.Column<long>(type: "bigint", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicle", x => x.Id);
                    table.UniqueConstraint("AK_Vehicle_Id_CustomerId", x => new { x.Id, x.CustomerId });
                    table.CheckConstraint("CK_Vehicle_Id_Positive", "[Id] > 0");
                    table.ForeignKey(
                        name: "FK_Vehicle_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DealershipOperatingWindow",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    DealershipId = table.Column<long>(type: "bigint", nullable: false),
                    LocalStart = table.Column<DateTime>(type: "datetime2(7)", precision: 7, nullable: false),
                    LocalEnd = table.Column<DateTime>(type: "datetime2(7)", precision: 7, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DealershipOperatingWindow", x => x.Id);
                    table.CheckConstraint("CK_DealershipOperatingWindow_Bounds", "[LocalEnd] > [LocalStart]");
                    table.CheckConstraint("CK_DealershipOperatingWindow_Id_Positive", "[Id] > 0");
                    table.ForeignKey(
                        name: "FK_DealershipOperatingWindow_Dealership_DealershipId",
                        column: x => x.DealershipId,
                        principalTable: "Dealership",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ServiceBay",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    DealershipId = table.Column<long>(type: "bigint", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServiceBay", x => x.Id);
                    table.UniqueConstraint("AK_ServiceBay_Id_DealershipId", x => new { x.Id, x.DealershipId });
                    table.CheckConstraint("CK_ServiceBay_Id_Positive", "[Id] > 0");
                    table.ForeignKey(
                        name: "FK_ServiceBay_Dealership_DealershipId",
                        column: x => x.DealershipId,
                        principalTable: "Dealership",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Technician",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    DealershipId = table.Column<long>(type: "bigint", nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Technician", x => x.Id);
                    table.UniqueConstraint("AK_Technician_Id_DealershipId", x => new { x.Id, x.DealershipId });
                    table.CheckConstraint("CK_Technician_Id_Positive", "[Id] > 0");
                    table.ForeignKey(
                        name: "FK_Technician_Dealership_DealershipId",
                        column: x => x.DealershipId,
                        principalTable: "Dealership",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TechnicianQualification",
                columns: table => new
                {
                    TechnicianId = table.Column<long>(type: "bigint", nullable: false),
                    ServiceTypeId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TechnicianQualification", x => new { x.TechnicianId, x.ServiceTypeId });
                    table.ForeignKey(
                        name: "FK_TechnicianQualification_ServiceType_ServiceTypeId",
                        column: x => x.ServiceTypeId,
                        principalTable: "ServiceType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TechnicianQualification_Technician_TechnicianId",
                        column: x => x.TechnicianId,
                        principalTable: "Technician",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TechnicianWorkingWindow",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    TechnicianId = table.Column<long>(type: "bigint", nullable: false),
                    LocalStart = table.Column<DateTime>(type: "datetime2(7)", precision: 7, nullable: false),
                    LocalEnd = table.Column<DateTime>(type: "datetime2(7)", precision: 7, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TechnicianWorkingWindow", x => x.Id);
                    table.CheckConstraint("CK_TechnicianWorkingWindow_Bounds", "[LocalEnd] > [LocalStart]");
                    table.CheckConstraint("CK_TechnicianWorkingWindow_Id_Positive", "[Id] > 0");
                    table.ForeignKey(
                        name: "FK_TechnicianWorkingWindow_Technician_TechnicianId",
                        column: x => x.TechnicianId,
                        principalTable: "Technician",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Appointment",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CustomerId = table.Column<long>(type: "bigint", nullable: false),
                    VehicleId = table.Column<long>(type: "bigint", nullable: false),
                    DealershipId = table.Column<long>(type: "bigint", nullable: false),
                    ServiceTypeId = table.Column<long>(type: "bigint", nullable: false),
                    TechnicianId = table.Column<long>(type: "bigint", nullable: false),
                    ServiceBayId = table.Column<long>(type: "bigint", nullable: false),
                    StartUtc = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", precision: 7, nullable: false),
                    EndUtc = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", precision: 7, nullable: false),
                    DurationMinutes = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "varchar(16)", unicode: false, maxLength: 16, nullable: false),
                    RequestKey = table.Column<string>(type: "varchar(128)", unicode: false, maxLength: 128, nullable: true, collation: "Latin1_General_100_BIN2"),
                    CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", precision: 7, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Appointment", x => x.Id);
                    table.CheckConstraint("CK_Appointment_Duration", "[DurationMinutes] > 0");
                    table.CheckConstraint("CK_Appointment_DurationEnd", "[EndUtc] = DATEADD(minute, [DurationMinutes], [StartUtc])");
                    table.CheckConstraint("CK_Appointment_Interval", "[EndUtc] > [StartUtc]");
                    table.CheckConstraint("CK_Appointment_RequestKey", "[RequestKey] IS NULL OR (DATALENGTH([RequestKey]) BETWEEN 1 AND 128 AND [RequestKey] NOT LIKE '%[^!-~]%')");
                    table.CheckConstraint("CK_Appointment_Status", "[Status] COLLATE Latin1_General_100_BIN2 = 'Confirmed' AND DATALENGTH([Status]) = 9");
                    table.CheckConstraint("CK_Appointment_Utc", "DATEPART(TZOFFSET, [StartUtc]) = 0 AND DATEPART(TZOFFSET, [EndUtc]) = 0 AND DATEPART(TZOFFSET, [CreatedUtc]) = 0");
                    table.ForeignKey(
                        name: "FK_Appointment_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_Dealership_DealershipId",
                        column: x => x.DealershipId,
                        principalTable: "Dealership",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_ServiceBay_ServiceBayId_DealershipId",
                        columns: x => new { x.ServiceBayId, x.DealershipId },
                        principalTable: "ServiceBay",
                        principalColumns: new[] { "Id", "DealershipId" },
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_ServiceType_ServiceTypeId",
                        column: x => x.ServiceTypeId,
                        principalTable: "ServiceType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_TechnicianQualification_TechnicianId_ServiceTypeId",
                        columns: x => new { x.TechnicianId, x.ServiceTypeId },
                        principalTable: "TechnicianQualification",
                        principalColumns: new[] { "TechnicianId", "ServiceTypeId" },
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_Technician_TechnicianId_DealershipId",
                        columns: x => new { x.TechnicianId, x.DealershipId },
                        principalTable: "Technician",
                        principalColumns: new[] { "Id", "DealershipId" },
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Appointment_Vehicle_VehicleId_CustomerId",
                        columns: x => new { x.VehicleId, x.CustomerId },
                        principalTable: "Vehicle",
                        principalColumns: new[] { "Id", "CustomerId" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_CustomerId",
                table: "Appointment",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_ServiceBayId_DealershipId",
                table: "Appointment",
                columns: new[] { "ServiceBayId", "DealershipId" });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_ServiceBayId_StartUtc",
                table: "Appointment",
                columns: new[] { "ServiceBayId", "StartUtc" },
                filter: "[Status] = 'Confirmed'")
                .Annotation("SqlServer:Include", new[] { "EndUtc", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_ServiceTypeId",
                table: "Appointment",
                column: "ServiceTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_TechnicianId_DealershipId",
                table: "Appointment",
                columns: new[] { "TechnicianId", "DealershipId" });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_TechnicianId_ServiceTypeId",
                table: "Appointment",
                columns: new[] { "TechnicianId", "ServiceTypeId" });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_TechnicianId_StartUtc",
                table: "Appointment",
                columns: new[] { "TechnicianId", "StartUtc" },
                filter: "[Status] = 'Confirmed'")
                .Annotation("SqlServer:Include", new[] { "EndUtc", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_VehicleId_CustomerId",
                table: "Appointment",
                columns: new[] { "VehicleId", "CustomerId" });

            migrationBuilder.CreateIndex(
                name: "UX_Appointment_Dealer_RequestKey",
                table: "Appointment",
                columns: new[] { "DealershipId", "RequestKey" },
                unique: true,
                filter: "[RequestKey] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_DealershipOperatingWindow_DealershipId_LocalStart",
                table: "DealershipOperatingWindow",
                columns: new[] { "DealershipId", "LocalStart" })
                .Annotation("SqlServer:Include", new[] { "LocalEnd" });

            migrationBuilder.CreateIndex(
                name: "IX_ServiceBay_DealershipId_Id",
                table: "ServiceBay",
                columns: new[] { "DealershipId", "Id" });

            migrationBuilder.CreateIndex(
                name: "IX_Technician_DealershipId_Id",
                table: "Technician",
                columns: new[] { "DealershipId", "Id" });

            migrationBuilder.CreateIndex(
                name: "IX_TechnicianQualification_ServiceTypeId_TechnicianId",
                table: "TechnicianQualification",
                columns: new[] { "ServiceTypeId", "TechnicianId" });

            migrationBuilder.CreateIndex(
                name: "IX_TechnicianWorkingWindow_TechnicianId_LocalStart",
                table: "TechnicianWorkingWindow",
                columns: new[] { "TechnicianId", "LocalStart" })
                .Annotation("SqlServer:Include", new[] { "LocalEnd" });

            migrationBuilder.CreateIndex(
                name: "IX_Vehicle_CustomerId",
                table: "Vehicle",
                column: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Appointment");

            migrationBuilder.DropTable(
                name: "DealershipOperatingWindow");

            migrationBuilder.DropTable(
                name: "TechnicianWorkingWindow");

            migrationBuilder.DropTable(
                name: "ServiceBay");

            migrationBuilder.DropTable(
                name: "TechnicianQualification");

            migrationBuilder.DropTable(
                name: "Vehicle");

            migrationBuilder.DropTable(
                name: "ServiceType");

            migrationBuilder.DropTable(
                name: "Technician");

            migrationBuilder.DropTable(
                name: "Customer");

            migrationBuilder.DropTable(
                name: "Dealership");
        }
    }
}
