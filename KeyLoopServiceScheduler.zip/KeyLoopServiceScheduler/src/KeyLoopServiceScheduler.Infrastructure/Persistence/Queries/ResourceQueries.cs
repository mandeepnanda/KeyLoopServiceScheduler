using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;

/// <summary>Constant-size query batches. Availability is provisional; later booking must use its locked attempt context.</summary>
public sealed class ResourceQueries(SchedulerDbContext context)
{
    public async Task<ResourceSnapshot> ReadAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval,
        CancellationToken cancellationToken = default)
    {
        var zoneId = await context.Dealerships.AsNoTracking().Where(x => x.Id == dealershipId)
            .Select(x => x.TimeZoneId).SingleAsync(cancellationToken);
        var zone = new TimeZoneResolver().Resolve(zoneId);
        var firstDate = TimeZoneInfo.ConvertTime(interval.StartUtc, zone).Date;
        var lastDate = TimeZoneInfo.ConvertTime(interval.EndUtc, zone).Date;
        var afterLastDate = lastDate == DateTime.MaxValue.Date ? DateTime.MaxValue : lastDate.AddDays(1);
        // LocalEnd, rather than LocalStart, includes windows beginning on an earlier date.
        var dealerWindows = await context.DealershipOperatingWindows.AsNoTracking()
            .Where(x => x.DealershipId == dealershipId && x.LocalEnd > firstDate && x.LocalStart < afterLastDate)
            .OrderBy(x => x.LocalStart).Select(x => new LocalWindow(x.LocalStart, x.LocalEnd)).ToListAsync(cancellationToken);
        var technicians = await context.Technicians.AsNoTracking()
            .Where(x => x.DealershipId == dealershipId && context.TechnicianQualifications.Any(q => q.TechnicianId == x.Id && q.ServiceTypeId == serviceTypeId))
            .OrderBy(x => x.Id).Select(x => x.Id).ToListAsync(cancellationToken);
        var bays = await context.ServiceBays.AsNoTracking().Where(x => x.DealershipId == dealershipId)
            .OrderBy(x => x.Id).Select(x => x.Id).ToListAsync(cancellationToken);
        var workingWindows = await context.TechnicianWorkingWindows.AsNoTracking()
            .Where(x => technicians.Contains(x.TechnicianId) && x.LocalEnd > firstDate && x.LocalStart < afterLastDate)
            .OrderBy(x => x.LocalStart).ToListAsync(cancellationToken);
        var overlaps = await context.Appointments.AsNoTracking()
            .Where(x => x.Status == "Confirmed" && x.StartUtc < interval.EndUtc && x.EndUtc > interval.StartUtc &&
                (technicians.Contains(x.TechnicianId) || bays.Contains(x.ServiceBayId)))
            .Select(x => new { x.TechnicianId, x.ServiceBayId, x.StartUtc, x.EndUtc }).ToListAsync(cancellationToken);
        return new(dealerWindows,
            technicians.Select(id => new TechnicianCandidate(id, dealershipId, new HashSet<long> { serviceTypeId },
                workingWindows.Where(x => x.TechnicianId == id).Select(x => new LocalWindow(x.LocalStart, x.LocalEnd)).ToArray(),
                overlaps.Where(x => x.TechnicianId == id).Select(x => new AppointmentInterval(x.StartUtc, x.EndUtc)).ToArray())).ToArray(),
            bays.Select(id => new BayCandidate(id, dealershipId,
                overlaps.Where(x => x.ServiceBayId == id).Select(x => new AppointmentInterval(x.StartUtc, x.EndUtc)).ToArray())).ToArray());
    }
}
