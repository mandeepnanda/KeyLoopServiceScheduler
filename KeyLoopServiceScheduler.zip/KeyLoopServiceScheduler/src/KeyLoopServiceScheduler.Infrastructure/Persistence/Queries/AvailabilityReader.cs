using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;

public sealed class AvailabilityReader(SchedulerDbContext context, ResourceQueries queries) : IAvailabilityReader
{
    public async Task<AvailabilityReferences> ReadReferencesAsync(long dealershipId, long serviceTypeId, CancellationToken cancellationToken = default) =>
        new(await context.Dealerships.AsNoTracking().SingleOrDefaultAsync(x => x.Id == dealershipId, cancellationToken),
            await context.ServiceTypes.AsNoTracking().SingleOrDefaultAsync(x => x.Id == serviceTypeId, cancellationToken));

    public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval,
        CancellationToken cancellationToken = default) => queries.ReadAsync(dealershipId, serviceTypeId, interval, cancellationToken);
}
