using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;

public sealed class AppointmentReader(SchedulerDbContext context) : IAppointmentReader
{
    public Task<AppointmentProjection?> GetAsync(Guid id, CancellationToken cancellationToken = default) =>
        context.Appointments.AsNoTracking().Where(x => x.Id == id)
            .Select(x => new AppointmentProjection(x.Id, x.CustomerId, x.VehicleId, x.DealershipId, x.ServiceTypeId,
                x.TechnicianId, x.ServiceBayId, x.StartUtc, x.EndUtc, x.DurationMinutes, x.Status))
            .SingleOrDefaultAsync(cancellationToken);
}
