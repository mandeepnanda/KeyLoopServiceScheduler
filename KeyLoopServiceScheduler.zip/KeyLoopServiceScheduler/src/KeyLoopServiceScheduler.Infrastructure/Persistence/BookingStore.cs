using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using KeyLoopServiceScheduler.Infrastructure.Transactions;

namespace KeyLoopServiceScheduler.Infrastructure.Persistence;

/// <summary>Attempt-bound store. Construction is confined to an acquired dealership lock.</summary>
public sealed class BookingStore(SchedulerDbContext context, long lockedDealershipId, Guid operationId, Action writing, Action<Activity>? deferred = null) : IBookingStore
{
    private bool inserted;
    private void EnsureDealer(long dealershipId)
    {
        if (dealershipId != lockedDealershipId) throw new InvalidOperationException("The store is bound to its locked dealership.");
    }
    public async Task<AppointmentProjection?> FindConfirmedAsync(long dealershipId, string requestKey, CancellationToken cancellationToken)
    {
        EnsureDealer(dealershipId);
        using var span = new DeferredSpan("booking.db.replay", deferred);
        var saved = await context.Appointments.AsNoTracking().SingleOrDefaultAsync(x =>
            x.DealershipId == dealershipId && x.RequestKey == requestKey && x.Status == "Confirmed", cancellationToken);
        return saved is null ? null : AppointmentProjection.From(saved);
    }
    public async Task<BookingReferences> ReadReferencesAsync(long customerId, long vehicleId, long dealershipId, long serviceTypeId, CancellationToken cancellationToken)
    {
        EnsureDealer(dealershipId);
        using var span = new DeferredSpan("booking.db.references", deferred);
        return new(await context.Customers.AsNoTracking().SingleOrDefaultAsync(x => x.Id == customerId, cancellationToken),
            await context.Vehicles.AsNoTracking().SingleOrDefaultAsync(x => x.Id == vehicleId, cancellationToken),
            await context.Dealerships.AsNoTracking().SingleOrDefaultAsync(x => x.Id == dealershipId, cancellationToken),
            await context.ServiceTypes.AsNoTracking().SingleOrDefaultAsync(x => x.Id == serviceTypeId, cancellationToken));
    }
    public async Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken)
    {
        EnsureDealer(dealershipId);
        using var span = new DeferredSpan("booking.db.resources", deferred);
        return await new ResourceQueries(context).ReadAsync(dealershipId, serviceTypeId, interval, cancellationToken);
    }
    public async Task AddAsync(Appointment appointment, CancellationToken cancellationToken)
    {
        EnsureDealer(appointment.DealershipId);
        using var span = new DeferredSpan("booking.db.insert", deferred);
        if (inserted || appointment.Id != operationId) throw new InvalidOperationException("An attempt may insert only its one operation identity.");
        inserted = true;
        writing();
        context.Appointments.Add(appointment);
        await context.SaveChangesAsync(cancellationToken);
    }
}
