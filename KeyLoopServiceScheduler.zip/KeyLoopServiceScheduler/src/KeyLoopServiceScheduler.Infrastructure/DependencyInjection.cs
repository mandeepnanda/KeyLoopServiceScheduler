using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;
using KeyLoopServiceScheduler.Infrastructure.Transactions;
using KeyLoopServiceScheduler.Infrastructure.Mock;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace KeyLoopServiceScheduler.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddSchedulerStorage(this IServiceCollection services, IConfiguration configuration,
        Func<IServiceProvider, string> environment)
    {
        // Selection is lazy so final host configuration overrides are applied before resolving adapters.
        services.AddSchedulerPersistence(configuration);
        services.AddSingleton(provider => SchedulerStorageSettings.Parse(configuration, environment(provider)));
        services.AddSingleton(provider => new MockDatabase(provider.GetRequiredService<TimeProvider>(), provider.GetRequiredService<SchedulerStorageSettings>().MockBaseDate));
        services.AddScoped<MockBookingTransaction>();
        services.AddScoped<IAppointmentReader>(provider => IsMock(provider) ? new MockReader(provider.GetRequiredService<MockDatabase>())
            : new AppointmentReader(provider.GetRequiredService<SchedulerDbContext>()));
        services.AddScoped<IAvailabilityReader>(provider => IsMock(provider) ? new MockReader(provider.GetRequiredService<MockDatabase>())
            : new AvailabilityReader(provider.GetRequiredService<SchedulerDbContext>(), provider.GetRequiredService<ResourceQueries>()));
        services.AddScoped<IBookingTransaction>(provider => IsMock(provider) ? provider.GetRequiredService<MockBookingTransaction>()
            : new BookingTransactionCoordinator(provider.GetRequiredService<IBookingAttemptFactory>(), provider.GetRequiredService<ICommitOutcomeVerifier>(),
                provider.GetRequiredService<IBookingRetryPolicy>(), provider.GetRequiredService<TimeProvider>()));
        return services;
    }

    private static bool IsMock(IServiceProvider provider) => provider.GetRequiredService<SchedulerStorageSettings>().Mode == SchedulerStorageMode.Mock;

    public static IServiceCollection AddSchedulerPersistence(this IServiceCollection services, SchedulerDatabaseOptions database)
    {
        services.AddSingleton(database);
        return AddAdapters(services);
    }

    public static IServiceCollection AddSchedulerPersistence(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton(_ => SchedulerDatabaseOptions.Parse(configuration.GetConnectionString("Scheduler")));
        return AddAdapters(services);
    }

    private static IServiceCollection AddAdapters(IServiceCollection services)
    {
        services.AddDbContext<SchedulerDbContext>((provider, options) => options.UseSqlServer(
            provider.GetRequiredService<SchedulerDatabaseOptions>().ConnectionString,
            sql => sql.UseCompatibilityLevel(160).CommandTimeout(SchedulerDatabaseOptions.CommandTimeoutSeconds)));
        // EF/SqlClient retries are disabled; later booking coordinates whole-attempt retries explicitly.
        services.AddScoped<ResourceQueries>();
        services.AddScoped<IAppointmentReader, AppointmentReader>();
        services.AddScoped<IAvailabilityReader, AvailabilityReader>();
        services.TryAddSingleton(TimeProvider.System);
        services.TryAddSingleton<IZoneResolver, TimeZoneResolver>();
        services.AddScoped<QueryAvailability>();
        services.AddScoped<BookAppointment>();
        services.AddSingleton<IDealershipApplicationLock, DealershipApplicationLock>();
        services.AddSingleton<IBookingRetryPolicy, BookingRetryPolicy>();
        services.AddScoped<IBookingAttemptFactory, BookingAttemptFactory>();
        services.AddScoped<ICommitOutcomeVerifier, CommitOutcomeVerifier>();
        services.AddScoped<IBookingTransaction, BookingTransactionCoordinator>();
        return services;
    }
}
