using Microsoft.Data.SqlClient;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public interface IBookingRetryPolicy
{
    bool IsTransient(Exception exception);
    TimeSpan Jitter { get; }
}

public sealed class BookingRetryPolicy : IBookingRetryPolicy
{
    public TimeSpan Jitter => TimeSpan.FromMilliseconds(Random.Shared.Next(100, 251));
    public bool IsTransient(Exception exception) => exception is DealershipLockException { Result: -3 } ||
        FindSqlException(exception)?.Number is 1205 or 40197 or 40501 or 40613 or 10928 or 10929 or 10053 or 10054 or 10060 or 233 or 64 or 20;
    public static SqlException? FindSqlException(Exception exception) => exception is SqlException sql ? sql :
        exception.InnerException is null ? null : FindSqlException(exception.InnerException);
}
