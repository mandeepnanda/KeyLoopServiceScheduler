using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using System.Diagnostics;
using KeyLoopServiceScheduler.Application.Observability;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public sealed class BookingTransactionCoordinator(IBookingAttemptFactory factory, ICommitOutcomeVerifier verifier,
    IBookingRetryPolicy retry, TimeProvider clock) : IBookingTransaction
{
    public async Task<TResult> ExecuteAsync<TResult>(long dealershipId, Guid operationId,
        Func<IBookingAttempt, CancellationToken, Task<TResult>> work, CancellationToken cancellationToken)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(dealershipId);
        if (operationId == Guid.Empty) throw new ArgumentException("Operation identity is required.", nameof(operationId));
        using var deadline = new BookingDeadline(clock, cancellationToken);
        for (var attemptNumber = 0; attemptNumber < 2; attemptNumber++)
        {
            if (!deadline.CanStartWork) throw Error(FailureCode.REQUEST_TIMEOUT, true);
            using var activity = SchedulerTelemetry.Activities.StartActivity("booking.transaction");
            var watch = Stopwatch.StartNew();
            deadline.LastLockWaitMs = null;
            deadline.LastLockResult = null;
            IBookingAttemptUnit? unit = null;
            TResult? result = default;
            Exception? failure = null;
            var committed = false;
            var commitStarted = false;
            var knownNotCommitted = true;
            var disposed = true;
            try
            {
                unit = factory.Create(operationId);
                await unit.AcquireAsync(dealershipId, deadline);
                result = await work(unit, deadline.Token);
                deadline.Token.ThrowIfCancellationRequested();
                if (!deadline.CanStartWork) throw new OperationCanceledException(deadline.Token);
                if (unit.WriteAttempted)
                {
                    await unit.CommitAsync(deadline.Token);
                    committed = true;
                }
                else
                {
                    // Replays and business rejections are read-only: no commit uncertainty to recover.
                    using var cleanup = deadline.CleanupToken();
                    await unit.RollbackAsync(cleanup.Token);
                }
            }
            catch (Exception exception)
            {
                failure = exception;
                commitStarted = unit?.CommitStarted == true;
                knownNotCommitted = unit?.WriteAttempted != true;
                if (unit is not null && !commitStarted)
                {
                    using var cleanup = deadline.CleanupToken();
                    try { knownNotCommitted |= await unit.RollbackAsync(cleanup.Token); }
                    catch (Exception) { /* Failed cleanup never establishes rollback. */ }
                    knownNotCommitted |= BookingRetryPolicy.FindSqlException(exception)?.Number == 1205;
                }
            }
            finally
            {
                if (unit is not null)
                {
                    try { await unit.DisposeAsync(); }
                    catch (Exception exception)
                    {
                        disposed = false;
                        // Acknowledged commit remains successful even if client-side disposal fails.
                        if (!committed && unit.WriteAttempted) failure ??= exception;
                    }
                }
            }
            activity?.SetTag("lock.wait.ms", deadline.LastLockWaitMs);
            activity?.Dispose();
            SchedulerTelemetry.Attempt(watch.Elapsed.TotalMilliseconds, deadline.LastLockWaitMs, deadline.LastLockResult);
            if (failure is null) return result!;
            if (commitStarted)
            {
                // Old attempt is discarded before the single fresh-primary lookup. No delegate retry.
                if (disposed && deadline.CanStartWork)
                {
                    try
                    {
                        var saved = await verifier.FindAsync(operationId, deadline.Token);
                        if (saved is not null) throw new CommitRecoveredException(saved);
                    }
                    catch (CommitRecoveredException) { throw; }
                    catch (Exception) { /* Failure or absence cannot prove rollback. */ }
                }
                throw Error(FailureCode.BOOKING_OUTCOME_UNKNOWN, false);
            }
            if (!knownNotCommitted) throw Error(FailureCode.BOOKING_OUTCOME_UNKNOWN, false);
            var cannotRetry = failure is OperationCanceledException or DealershipLockException { Result: -1 or -2 or -999 };
            var jitter = retry.Jitter;
            if (attemptNumber == 0 && disposed && !cannotRetry && retry.IsTransient(failure) &&
                deadline.CanStartWork && deadline.Remaining > jitter + TimeSpan.FromSeconds(1))
            {
                try { await Task.Delay(jitter, clock, deadline.Token); }
                catch (OperationCanceledException) { throw Error(FailureCode.REQUEST_TIMEOUT, true); }
                continue;
            }
            var code = failure switch
            {
                DealershipLockException { Result: -1 } => FailureCode.BOOKING_BUSY,
                DealershipLockException { Result: -2 } or OperationCanceledException => FailureCode.REQUEST_TIMEOUT,
                DealershipLockException { Result: -999 } => FailureCode.INVALID_REFERENCE_CONFIGURATION,
                _ when !deadline.CanStartWork => FailureCode.REQUEST_TIMEOUT,
                DealershipLockException or System.Data.Common.DbException => FailureCode.DATABASE_UNAVAILABLE,
                _ when BookingRetryPolicy.FindSqlException(failure) is not null => FailureCode.DATABASE_UNAVAILABLE,
                _ when retry.IsTransient(failure) => FailureCode.DATABASE_UNAVAILABLE,
                _ => FailureCode.INTERNAL_ERROR
            };
            throw Error(code, true);
        }
        throw new InvalidOperationException("Unreachable retry state.");
    }

    private static BookingTransactionException Error(FailureCode code, bool knownNotCommitted) =>
        new(new(code, knownNotCommitted ? PersistenceOutcome.NotCommitted : PersistenceOutcome.Unknown));
}
