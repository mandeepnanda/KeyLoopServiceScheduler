using System.Data;
using System.Diagnostics;
using System.Globalization;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public interface IDealershipApplicationLock
{
    Task AcquireAsync(SchedulerDbContext context, long dealershipId, BookingDeadline deadline);
}

public sealed class DealershipLockException(int result) : Exception("Dealership lock acquisition failed")
{
    public int Result { get; } = result;
}

public sealed class DealershipApplicationLock : IDealershipApplicationLock
{
    public static string ResourceName(long dealershipId)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(dealershipId);
        return "scheduler:dealership:" + dealershipId.ToString(CultureInfo.InvariantCulture);
    }
    public async Task AcquireAsync(SchedulerDbContext context, long dealershipId, BookingDeadline deadline)
    {
        deadline.Token.ThrowIfCancellationRequested();
        var transaction = context.Database.CurrentTransaction ?? throw new InvalidOperationException("An explicit transaction is required.");
        await using var command = new SqlCommand("sys.sp_getapplock", (SqlConnection)context.Database.GetDbConnection(),
            (SqlTransaction)transaction.GetDbTransaction())
        { CommandType = CommandType.StoredProcedure, CommandTimeout = 5 };
        command.Parameters.Add(new("@Resource", SqlDbType.NVarChar, 255) { Value = ResourceName(dealershipId) });
        command.Parameters.Add(new("@LockMode", SqlDbType.VarChar, 32) { Value = "Exclusive" });
        command.Parameters.Add(new("@LockOwner", SqlDbType.VarChar, 32) { Value = "Transaction" });
        command.Parameters.Add(new("@LockTimeout", SqlDbType.Int) { Value = deadline.LockWaitMilliseconds });
        command.Parameters.Add(new("@DbPrincipal", SqlDbType.NVarChar, 128) { Value = "public" });
        var result = new SqlParameter("@RETURN_VALUE", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue };
        command.Parameters.Add(result);
        var watch = Stopwatch.StartNew();
        try { await command.ExecuteNonQueryAsync(deadline.Token); }
        finally { deadline.LastLockWaitMs = watch.Elapsed.TotalMilliseconds; }
        var code = (int)result.Value;
        deadline.LastLockResult = code;
        if (code < 0) throw new DealershipLockException(code);
    }
}
