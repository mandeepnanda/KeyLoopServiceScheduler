using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public interface IBookingAttemptFactory { IBookingAttemptUnit Create(Guid operationId); }

public sealed class BookingAttemptFactory(SchedulerDatabaseOptions database, IDealershipApplicationLock dealershipLock) : IBookingAttemptFactory
{
    internal static SchedulerDbContext CreateContext(SchedulerDatabaseOptions database) => new(new DbContextOptionsBuilder<SchedulerDbContext>()
        .UseSqlServer(database.ConnectionString, sql => sql.UseCompatibilityLevel(160).CommandTimeout(5)).Options);
    public IBookingAttemptUnit Create(Guid operationId) => new BookingAttempt(CreateContext(database), operationId, dealershipLock);
}
