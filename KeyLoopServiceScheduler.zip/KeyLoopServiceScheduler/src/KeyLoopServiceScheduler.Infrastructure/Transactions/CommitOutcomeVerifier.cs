using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Queries;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public interface ICommitOutcomeVerifier
{
    Task<AppointmentProjection?> FindAsync(Guid operationId, CancellationToken cancellationToken);
}

public sealed class CommitOutcomeVerifier(SchedulerDatabaseOptions database) : ICommitOutcomeVerifier
{
    public async Task<AppointmentProjection?> FindAsync(Guid operationId, CancellationToken cancellationToken)
    {
        await using var context = BookingAttemptFactory.CreateContext(database);
        return await new AppointmentReader(context).GetAsync(operationId, cancellationToken);
    }
}
