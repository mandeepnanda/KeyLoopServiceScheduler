using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Diagnostics;
using KeyLoopServiceScheduler.Application.Observability;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

public interface IBookingAttemptUnit : IBookingAttempt, IAsyncDisposable
{
    bool WriteAttempted { get; }
    bool CommitStarted { get; }
    Task AcquireAsync(long dealershipId, BookingDeadline deadline);
    Task CommitAsync(CancellationToken cancellationToken);
    Task<bool> RollbackAsync(CancellationToken cancellationToken);
}

public sealed class BookingAttempt(SchedulerDbContext context, Guid operationId, IDealershipApplicationLock dealershipLock) : IBookingAttemptUnit
{
    private IDbContextTransaction? transaction;
    private IBookingStore? store;
    private bool ended;
    private readonly List<Activity> observations = [];
    public Guid OperationId { get; } = operationId;
    public bool WriteAttempted { get; private set; }
    public bool CommitStarted { get; private set; }
    public IBookingStore Store => store ?? throw new InvalidOperationException("Acquire the dealership lock before reading or writing.");
    public async Task AcquireAsync(long dealershipId, BookingDeadline deadline)
    {
        if (transaction is not null) throw new InvalidOperationException("The attempt already owns a transaction.");
        await context.Database.OpenConnectionAsync(deadline.Token);
        transaction = await context.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadCommitted, deadline.Token);
        using (new DeferredSpan("booking.lock.wait", observations.Add)) await dealershipLock.AcquireAsync(context, dealershipId, deadline);
        store = new BookingStore(context, dealershipId, OperationId, () => WriteAttempted = true, observations.Add);
    }
    public async Task CommitAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (transaction is null || ended) throw new InvalidOperationException("No active attempt transaction.");
        CommitStarted = true;
        await transaction.CommitAsync(cancellationToken);
        ended = true;
    }
    public async Task<bool> RollbackAsync(CancellationToken cancellationToken)
    {
        if (transaction is null) return !WriteAttempted;
        if (ended) return false;
        try { await transaction.RollbackAsync(cancellationToken); ended = true; return true; }
        catch (Exception exception) when (exception is OperationCanceledException or System.Data.Common.DbException or InvalidOperationException or IOException) { return false; }
    }
    public async ValueTask DisposeAsync()
    {
        store = null;
        try { if (transaction is not null) await transaction.DisposeAsync(); }
        finally
        {
            try { await context.DisposeAsync(); }
            finally
            {
                foreach (var activity in observations) { try { activity.Stop(); } catch (Exception) { SchedulerTelemetry.Dropped(); } }
                observations.Clear();
            }
        }
    }
}
