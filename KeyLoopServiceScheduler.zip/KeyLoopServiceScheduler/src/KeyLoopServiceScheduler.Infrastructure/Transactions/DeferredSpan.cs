using System.Diagnostics;
using KeyLoopServiceScheduler.Application.Observability;

namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

// Finish timing in the critical section, but defer Activity.Stop/export until unit disposal.
internal sealed class DeferredSpan : IDisposable
{
    private readonly Activity? parent = Activity.Current;
    private readonly Activity? activity;
    private readonly Action<Activity>? deferred;
    public DeferredSpan(string name, Action<Activity>? deferred)
    {
        this.deferred = deferred;
        if (deferred is not null) activity = SchedulerTelemetry.Activities.StartActivity(name);
    }
    public void Dispose()
    {
        if (activity is null) return;
        activity.SetEndTime(DateTime.UtcNow);
        if (ReferenceEquals(Activity.Current, activity)) Activity.Current = parent;
        deferred!(activity);
    }
}
