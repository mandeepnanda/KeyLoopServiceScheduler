namespace KeyLoopServiceScheduler.Infrastructure.Transactions;

/// <summary>One monotonic response budget; rollback uses a separate bounded cleanup token.</summary>
public sealed class BookingDeadline : IDisposable
{
    public static readonly TimeSpan ResponseBudget = TimeSpan.FromSeconds(10);
    public static readonly TimeSpan CleanupBudget = TimeSpan.FromSeconds(1);
    private readonly TimeProvider clock;
    private readonly long started;
    private readonly CancellationTokenSource timer;
    private readonly CancellationTokenSource linked;
    public BookingDeadline(TimeProvider clock, CancellationToken caller)
    {
        this.clock = clock;
        started = clock.GetTimestamp();
        timer = new(ResponseBudget, clock);
        linked = CancellationTokenSource.CreateLinkedTokenSource(caller, timer.Token);
    }
    public CancellationToken Token => linked.Token;
    public double? LastLockWaitMs { get; internal set; }
    public int? LastLockResult { get; internal set; }
    public TimeSpan Remaining => TimeSpan.FromTicks(Math.Max(0, (ResponseBudget - clock.GetElapsedTime(started)).Ticks));
    public bool CanStartWork => !Token.IsCancellationRequested && Remaining > TimeSpan.Zero;
    public int LockWaitMilliseconds => (int)Math.Min(2000, Math.Max(0, Remaining.TotalMilliseconds));
    public CancellationTokenSource CleanupToken() => new(CleanupBudget, clock);
    public void Dispose() { linked.Dispose(); timer.Dispose(); }
}
