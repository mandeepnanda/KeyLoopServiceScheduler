using Microsoft.Extensions.Configuration;

namespace KeyLoopServiceScheduler.Infrastructure.Configuration;

public enum SchedulerStorageMode { SqlServer, Mock }
public sealed record SchedulerStorageSettings(SchedulerStorageMode Mode, DateOnly? MockBaseDate)
{
    public static SchedulerStorageSettings Parse(IConfiguration configuration, string environment)
    {
        var selected = configuration["Scheduler:StorageMode"] ?? "SqlServer";
        var mode = selected.Equals("SqlServer", StringComparison.OrdinalIgnoreCase) ? SchedulerStorageMode.SqlServer
            : selected.Equals("Mock", StringComparison.OrdinalIgnoreCase) ? SchedulerStorageMode.Mock
            : throw new InvalidOperationException("Scheduler:StorageMode must be SqlServer or Mock.");
        if (mode == SchedulerStorageMode.Mock && !environment.Equals("Development", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Mock storage is available only in Development.");
        DateOnly? baseDate = null;
        if (mode == SchedulerStorageMode.Mock && configuration["Scheduler:MockBaseDate"] is string date)
        {
            if (!DateOnly.TryParseExact(date, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out var parsed))
                throw new InvalidOperationException("Scheduler:MockBaseDate must be yyyy-MM-dd.");
            baseDate = parsed;
        }
        return new(mode, baseDate);
    }
}
