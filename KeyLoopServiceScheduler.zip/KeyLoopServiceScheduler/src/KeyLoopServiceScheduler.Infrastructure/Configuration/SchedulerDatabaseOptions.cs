using Microsoft.Data.SqlClient;

namespace KeyLoopServiceScheduler.Infrastructure.Configuration;

public sealed record SchedulerDatabaseOptions(string ConnectionString)
{
    public const int CommandTimeoutSeconds = 5;

    public static SchedulerDatabaseOptions Parse(string? connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new InvalidOperationException("Supply ConnectionStrings__Scheduler externally; no credentials are stored in the project.");

        var builder = new SqlConnectionStringBuilder(connectionString);
        if (builder.ApplicationIntent != ApplicationIntent.ReadWrite)
            throw new InvalidOperationException("The scheduler requires a primary read-write SQL connection.");
        if (builder.MultipleActiveResultSets)
            throw new InvalidOperationException("MARS must be disabled for scheduler transactions.");
        if (builder.ConnectRetryCount != 0)
            throw new InvalidOperationException("ConnectRetryCount must be zero; booking retry ownership belongs to the transaction coordinator.");
        if (builder.ConnectTimeout is <= 0 or > 3)
            throw new InvalidOperationException("Connection timeout must be between one and three seconds.");
        if (string.IsNullOrWhiteSpace(builder.DataSource) || string.IsNullOrWhiteSpace(builder.InitialCatalog))
            throw new InvalidOperationException("An explicit SQL Server and database are required.");
        return new SchedulerDatabaseOptions(builder.ConnectionString);
    }
}
