using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.ValueObjects;

namespace KeyLoopServiceScheduler.Infrastructure.Mock;

// Scoped readers borrow the host-owned database without transferring its disposal ownership.
internal sealed class MockReader(MockDatabase database) : IAppointmentReader, IAvailabilityReader
{
    public Task<AppointmentProjection?> GetAsync(Guid id, CancellationToken cancellationToken = default) => database.GetAsync(id, cancellationToken);
    public Task<AvailabilityReferences> ReadReferencesAsync(long dealershipId, long serviceTypeId, CancellationToken cancellationToken = default) => database.ReadReferencesAsync(dealershipId, serviceTypeId, cancellationToken);
    public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken = default) => database.ReadResourcesAsync(dealershipId, serviceTypeId, interval, cancellationToken);
}
