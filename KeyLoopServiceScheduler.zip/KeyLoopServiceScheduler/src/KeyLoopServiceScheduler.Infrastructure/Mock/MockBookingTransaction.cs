using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure.Transactions;

namespace KeyLoopServiceScheduler.Infrastructure.Mock;

/// <summary>Stages one row until the delegate completes. The process-local gate is for demonstration only.</summary>
public sealed class MockBookingTransaction(MockDatabase database, TimeProvider clock) : IBookingTransaction
{
    public async Task<TResult> ExecuteAsync<TResult>(long dealershipId, Guid operationId,
        Func<IBookingAttempt, CancellationToken, Task<TResult>> work, CancellationToken cancellationToken)
    {
        using var deadline = new BookingDeadline(clock, cancellationToken);
        var acquired = false;
        try
        {
            acquired = await database.BookingGate.WaitAsync(TimeSpan.FromMilliseconds(deadline.LockWaitMilliseconds), deadline.Token);
            if (!acquired) throw new BookingTransactionException(new(FailureCode.BOOKING_BUSY, PersistenceOutcome.NotCommitted));
            using var attempt = new Attempt(database, dealershipId, operationId);
            var result = await work(attempt, deadline.Token);
            deadline.Token.ThrowIfCancellationRequested();
            if (!deadline.CanStartWork) throw new OperationCanceledException(deadline.Token);
            database.Commit(attempt.Pending);
            return result;
        }
        catch (BookingTransactionException) { throw; }
        catch (OperationCanceledException) { throw new BookingTransactionException(new(FailureCode.REQUEST_TIMEOUT, PersistenceOutcome.NotCommitted)); }
        finally { if (acquired) database.BookingGate.Release(); }
    }
    private sealed class Attempt(MockDatabase database, long dealershipId, Guid operationId) : IBookingAttempt, IBookingStore, IDisposable
    {
        private bool disposed;
        public Guid OperationId => operationId;
        public IBookingStore Store => this;
        public Appointment? Pending { get; private set; }
        private void Check(long dealer, CancellationToken token)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            token.ThrowIfCancellationRequested();
            if (dealer != dealershipId) throw new InvalidOperationException("Mock store is bound to its attempted dealership.");
        }
        public Task<AppointmentProjection?> FindConfirmedAsync(long dealer, string key, CancellationToken token)
        { Check(dealer, token); return Task.FromResult(database.FindConfirmed(dealer, key)); }
        public Task<BookingReferences> ReadReferencesAsync(long customer, long vehicle, long dealer, long service, CancellationToken token)
        { Check(dealer, token); return Task.FromResult(database.References(customer, vehicle, dealer, service)); }
        public Task<ResourceSnapshot> ReadResourcesAsync(long dealer, long service, AppointmentInterval interval, CancellationToken token)
        { Check(dealer, token); return database.ReadResourcesAsync(dealer, service, interval, token); }
        public Task AddAsync(Appointment appointment, CancellationToken token)
        {
            Check(appointment.DealershipId, token);
            if (Pending is not null || appointment.Id != operationId) throw new InvalidOperationException("Only one operation identity may be staged.");
            Pending = appointment;
            return Task.CompletedTask;
        }
        public void Dispose() { disposed = true; Pending = null; }
    }
}
