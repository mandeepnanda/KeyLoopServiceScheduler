using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Domain.Entities;
using KeyLoopServiceScheduler.Domain.Scheduling;
using KeyLoopServiceScheduler.Domain.ValueObjects;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;

namespace KeyLoopServiceScheduler.Infrastructure.Mock;

/// <summary>One-host demonstration data. No EF provider, SQL emulation, durable storage or cross-process coordination.</summary>
public sealed class MockDatabase : IAppointmentReader, IAvailabilityReader, IDisposable
{
    private readonly object sync = new();
    private readonly Dictionary<Guid, Appointment> appointments = [];
    private readonly SchedulerSeedData seed;
    internal SemaphoreSlim BookingGate { get; } = new(1, 1);
    public DateOnly BaseDate { get; }
    public DateTimeOffset ExampleStart { get; }
    public MockDatabase(TimeProvider clock, DateOnly? baseDate = null)
    {
        BaseDate = baseDate ?? DateOnly.FromDateTime(clock.GetUtcNow().UtcDateTime).AddDays(1);
        seed = SchedulerSeedData.Create(BaseDate, clock);
        appointments.Add(seed.History.Id, seed.History);
        var zone = new TimeZoneResolver().Resolve("Asia/Kolkata");
        ExampleStart = new(TimeZoneInfo.ConvertTimeToUtc(BaseDate.ToDateTime(new TimeOnly(9, 0), DateTimeKind.Unspecified), zone));
    }
    public Task<AppointmentProjection?> GetAsync(Guid id, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (sync) return Task.FromResult(appointments.TryGetValue(id, out var row) ? AppointmentProjection.From(row) : null);
    }
    public Task<AvailabilityReferences> ReadReferencesAsync(long dealershipId, long serviceTypeId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(new AvailabilityReferences(seed.Dealerships.SingleOrDefault(x => x.Id == dealershipId), seed.Services.SingleOrDefault(x => x.Id == serviceTypeId)));
    }
    internal BookingReferences References(long customerId, long vehicleId, long dealershipId, long serviceTypeId) =>
        new(seed.Customers.SingleOrDefault(x => x.Id == customerId), seed.Vehicles.SingleOrDefault(x => x.Id == vehicleId),
            seed.Dealerships.SingleOrDefault(x => x.Id == dealershipId), seed.Services.SingleOrDefault(x => x.Id == serviceTypeId));
    internal AppointmentProjection? FindConfirmed(long dealershipId, string key)
    {
        lock (sync)
        {
            var row = appointments.Values.SingleOrDefault(x => x.DealershipId == dealershipId && string.Equals(x.RequestKey, key, StringComparison.Ordinal));
            return row is null ? null : AppointmentProjection.From(row);
        }
    }
    public Task<ResourceSnapshot> ReadResourcesAsync(long dealershipId, long serviceTypeId, AppointmentInterval interval, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (sync)
        {
            var rows = appointments.Values.Where(x => x.StartUtc < interval.EndUtc && x.EndUtc > interval.StartUtc).ToArray();
            var technicians = seed.Technicians.Where(x => x.DealershipId == dealershipId && seed.Qualifications.Any(q => q.TechnicianId == x.Id && q.ServiceTypeId == serviceTypeId))
                .OrderBy(x => x.Id).Select(x => new TechnicianCandidate(x.Id, x.DealershipId,
                    seed.Qualifications.Where(q => q.TechnicianId == x.Id).Select(q => q.ServiceTypeId).ToHashSet(),
                    seed.WorkingWindows.Where(w => w.TechnicianId == x.Id).Select(w => new LocalWindow(w.LocalStart, w.LocalEnd)).ToArray(),
                    rows.Where(a => a.TechnicianId == x.Id).Select(a => new AppointmentInterval(a.StartUtc, a.EndUtc)).ToArray())).ToArray();
            var bays = seed.Bays.Where(x => x.DealershipId == dealershipId).OrderBy(x => x.Id).Select(x => new BayCandidate(x.Id, x.DealershipId,
                rows.Where(a => a.ServiceBayId == x.Id).Select(a => new AppointmentInterval(a.StartUtc, a.EndUtc)).ToArray())).ToArray();
            return Task.FromResult(new ResourceSnapshot(seed.DealerWindows.Where(x => x.DealershipId == dealershipId)
                .Select(x => new LocalWindow(x.LocalStart, x.LocalEnd)).ToArray(), technicians, bays));
        }
    }
    internal void Commit(Appointment? pending)
    {
        if (pending is null) return;
        lock (sync)
        {
            if (appointments.ContainsKey(pending.Id) || (pending.RequestKey is not null && appointments.Values.Any(x =>
                x.DealershipId == pending.DealershipId && string.Equals(x.RequestKey, pending.RequestKey, StringComparison.Ordinal))))
                throw new InvalidOperationException("Duplicate mock confirmation.");
            appointments.Add(pending.Id, pending);
        }
    }
    public void Dispose() => BookingGate.Dispose();
}
