using KeyLoopServiceScheduler.Application.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace KeyLoopServiceScheduler.Api.Errors;

public static class ProblemDetailsMapper
{
    public static int Status(FailureCode code) => code switch
    {
        FailureCode.NO_QUALIFIED_TECHNICIAN or FailureCode.DEALERSHIP_CLOSED or FailureCode.TECHNICIAN_UNAVAILABLE or
            FailureCode.BAY_UNAVAILABLE or FailureCode.KEY_PAYLOAD_MISMATCH => 409,
        FailureCode.REQUEST_TIMEOUT or FailureCode.BOOKING_BUSY or FailureCode.DATABASE_UNAVAILABLE or FailureCode.BOOKING_OUTCOME_UNKNOWN => 503,
        FailureCode.INTERNAL_ERROR or FailureCode.INVALID_REFERENCE_CONFIGURATION => 500,
        FailureCode.APPOINTMENT_NOT_FOUND => 404,
        _ => 400
    };
    public static ProblemDetails Create(HttpContext context, Failure failure)
    {
        context.Items["reasonCode"] = failure.Code.ToString();
        var status = Status(failure.Code);
        var problem = new ProblemDetails
        {
            Type = "urn:keyloop:problem:" + failure.Code,
            Title = failure.Code.ToString().Replace('_', ' '),
            Status = status,
            Instance = context.Request.Path,
            Detail = status switch
            {
                503 => RetryGuidance(context, failure),
                500 => "The operation could not be completed.",
                404 => "The appointment was not found.",
                409 => "The request cannot be confirmed with the current booking state.",
                _ => "Correct the request and try again."
            }
        };
        problem.Extensions["code"] = failure.Code.ToString();
        problem.Extensions["correlationId"] = context.Items["correlationId"];
        if (failure.Outcome is not null) problem.Extensions["outcome"] = failure.Outcome == PersistenceOutcome.NotCommitted ? "not_committed" : "unknown";
        return problem;
    }
    private static string RetryGuidance(HttpContext context, Failure failure)
    {
        if (!HttpMethods.IsPost(context.Request.Method) || context.Request.Path != "/api/v1/appointments")
            return "The operation is temporarily unavailable. Try again later.";
        var keyed = context.Items["bookingHasRequestKey"] is true;
        if (failure.Outcome == PersistenceOutcome.NotCommitted)
            return keyed
                ? "The booking was not confirmed. Retry later using the original request key and unchanged booking details."
                : "The booking was not confirmed. You may retry later.";
        // Absence of a known noncommit is never evidence that insertion rolled back.
        return keyed
            ? "The booking may already be confirmed. Retry using the original request key and unchanged booking details to recover its confirmation."
            : "The booking may already be confirmed. Retrying can create a duplicate appointment; a new key cannot recover the original attempt. Verify the existing booking before submitting another request.";
    }
    public static ObjectResult Result(HttpContext context, Failure failure)
    {
        var result = new ObjectResult(Create(context, failure)) { StatusCode = Status(failure.Code) };
        result.ContentTypes.Add("application/problem+json");
        return result;
    }
    public static async Task Write(HttpContext context, Failure failure)
    {
        context.Response.StatusCode = Status(failure.Code);
        await context.Response.WriteAsJsonAsync(Create(context, failure), options: null, contentType: "application/problem+json", cancellationToken: context.RequestAborted);
    }
}
