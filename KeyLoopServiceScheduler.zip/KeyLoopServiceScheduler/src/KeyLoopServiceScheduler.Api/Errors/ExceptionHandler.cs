using System.Data.Common;
using KeyLoopServiceScheduler.Application.Contracts;

namespace KeyLoopServiceScheduler.Api.Errors;

public sealed class ExceptionHandler(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try { await next(context); }
        catch (Exception exception) when (!context.Response.HasStarted)
        {
            if (context.RequestAborted.IsCancellationRequested) return;
            var failure = exception switch
            {
                BookingTransactionException transaction => transaction.Failure,
                DbException => new Failure(FailureCode.DATABASE_UNAVAILABLE),
                OperationCanceledException => new Failure(FailureCode.REQUEST_TIMEOUT),
                BadHttpRequestException => new Failure(FailureCode.INVALID_REQUEST),
                _ => new Failure(FailureCode.INTERNAL_ERROR)
            };
            // Never log exception text, request bodies, keys, or SQL parameters.
            await ProblemDetailsMapper.Write(context, failure);
        }
    }
}
