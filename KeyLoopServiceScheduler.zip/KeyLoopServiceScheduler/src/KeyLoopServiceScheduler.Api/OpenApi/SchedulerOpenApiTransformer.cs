using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace KeyLoopServiceScheduler.Api.OpenApi;

// The approved schemas describe manually validated JSON, which ApiExplorer cannot infer.
// Preserve runtime route discovery and fail if a documented operation is missing.
public sealed class SchedulerOpenApiTransformer : IOpenApiDocumentTransformer
{
    public async Task TransformAsync(OpenApiDocument document, OpenApiDocumentTransformerContext context, CancellationToken token)
    {
        await using var stream = typeof(SchedulerOpenApiTransformer).Assembly.GetManifestResourceStream("Scheduler.Contract.json")
            ?? throw new InvalidOperationException("Approved API contract resource is missing.");
        var loaded = await OpenApiDocument.LoadAsync(stream, "json", cancellationToken: token);
        var contract = loaded.Document ?? throw new InvalidOperationException("Approved API contract cannot be parsed.");
        foreach (var (path, item) in contract.Paths)
        {
            if (!document.Paths.TryGetValue(path, out var discovered) || item.Operations!.Keys.Any(method => !discovered.Operations!.ContainsKey(method)))
                throw new InvalidOperationException("A documented API operation is not implemented: " + path);
        }
        document.Info = contract.Info;
        document.Info.Description = "Local service scheduler. Mock storage is available only in Development; SQL verification is reported separately.";
        document.Paths = contract.Paths;
        document.Components = contract.Components;
        document.Servers = contract.Servers;
    }
}
