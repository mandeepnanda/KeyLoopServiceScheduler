using System.Diagnostics;
using Serilog.Context;

namespace KeyLoopServiceScheduler.Api.Middleware;

public sealed class CorrelationMiddleware(RequestDelegate next)
{
    public static bool Valid(string? value) => value is { Length: >= 1 and <= 64 } && value.All(c => char.IsAsciiLetterOrDigit(c) || "!#$%&'*+-.^_`|~".Contains(c));
    public async Task InvokeAsync(HttpContext context)
    {
        var header = context.Request.Headers["X-Correlation-ID"];
        var correlation = header.Count == 1 && Valid(header[0]) ? header[0]! : Guid.NewGuid().ToString("N");
        context.Items["correlationId"] = correlation;
        context.Response.Headers["X-Correlation-ID"] = correlation;
        using var scope = LogContext.PushProperty("correlationId", correlation);
        using var trace = LogContext.PushProperty("traceId", Activity.Current?.TraceId.ToString());
        await next(context);
    }
}
