using System.Globalization;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using KeyLoopServiceScheduler.Infrastructure.Persistence.Seeding;

namespace KeyLoopServiceScheduler.Api.Bootstrap;

public sealed record SeedCommand(bool SeedOnly, DateOnly? BaseDate, string[] HostArguments)
{
    public static SeedCommand Parse(string[] args)
    {
        var seedOnly = false;
        DateOnly? baseDate = null;
        var hostArguments = new List<string>();
        for (var index = 0; index < args.Length; index++)
        {
            if (args[index] == "--seed-only")
            {
                if (seedOnly) throw new ArgumentException("Duplicate --seed-only.");
                seedOnly = true;
            }
            else if (args[index] == "--seed-base-date")
            {
                if (baseDate is not null || ++index >= args.Length ||
                    !DateOnly.TryParseExact(args[index], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed))
                    throw new ArgumentException("Supply one --seed-base-date yyyy-MM-dd.");
                baseDate = parsed;
            }
            else hostArguments.Add(args[index]);
        }
        if (seedOnly != (baseDate is not null)) throw new ArgumentException("Use --seed-only together with --seed-base-date yyyy-MM-dd.");
        return new(seedOnly, baseDate, hostArguments.ToArray());
    }

    public async Task ExecuteAsync(IServiceProvider services, CancellationToken cancellationToken = default)
    {
        if (!SeedOnly || BaseDate is null) throw new InvalidOperationException("This is not a seed-only command.");
        await using var scope = services.CreateAsyncScope();
        await SchedulerSeedData.ApplyAsync(scope.ServiceProvider.GetRequiredService<SchedulerDbContext>(), BaseDate.Value,
            scope.ServiceProvider.GetRequiredService<TimeProvider>(), cancellationToken);
    }
}
