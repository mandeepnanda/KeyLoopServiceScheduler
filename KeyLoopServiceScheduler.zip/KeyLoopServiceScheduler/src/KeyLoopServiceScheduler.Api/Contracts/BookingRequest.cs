namespace KeyLoopServiceScheduler.Api.Contracts;

public sealed record BookingRequest(long CustomerId, long VehicleId, long DealershipId, long ServiceTypeId, DateTimeOffset StartTime)
{
    public Application.Booking.BookingRequest ToApplication(string? key) => new(CustomerId, VehicleId, DealershipId, ServiceTypeId, StartTime, key);
}
