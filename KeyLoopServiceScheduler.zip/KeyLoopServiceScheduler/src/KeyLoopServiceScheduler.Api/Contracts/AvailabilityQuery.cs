namespace KeyLoopServiceScheduler.Api.Contracts;

public sealed record AvailabilityQuery(long DealershipId, long ServiceTypeId, DateTimeOffset StartTime)
{
    public Application.Availability.AvailabilityQuery ToApplication() => new(DealershipId, ServiceTypeId, StartTime);
}
