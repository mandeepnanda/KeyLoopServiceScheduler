using KeyLoopServiceScheduler.Api.Errors;
using KeyLoopServiceScheduler.Api.Validation;
using KeyLoopServiceScheduler.Application.Availability;
using Microsoft.AspNetCore.Mvc;

namespace KeyLoopServiceScheduler.Api.Controllers;

[ApiController, Route("api/v1/availability")]
public sealed class AvailabilityController(QueryAvailability availability) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken token)
    {
        var invalid = RequestValidation.Availability(Request.Query, out var request);
        if (invalid is not null) return ProblemDetailsMapper.Result(HttpContext, new(invalid.Value));
        HttpContext.Items["dealerId"] = request!.DealershipId;
        var result = await availability.ExecuteAsync(request.ToApplication(), token);
        if (result.Failure is not null) return ProblemDetailsMapper.Result(HttpContext, result.Failure);
        HttpContext.Items["reasonCode"] = result.Details!.ReasonCode;
        return Ok(result.Details);
    }
}
