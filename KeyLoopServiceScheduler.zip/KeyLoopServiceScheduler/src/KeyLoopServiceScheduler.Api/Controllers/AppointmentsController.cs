using System.Text.Json;
using KeyLoopServiceScheduler.Api.Errors;
using KeyLoopServiceScheduler.Api.Validation;
using KeyLoopServiceScheduler.Application.Appointments;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace KeyLoopServiceScheduler.Api.Controllers;

[ApiController, Route("api/v1/appointments")]
public sealed class AppointmentsController(BookAppointment booking, GetAppointment retrieval) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] JsonElement body, CancellationToken token)
    {
        var invalid = RequestValidation.Booking(body, Request.Headers, out var request);
        if (invalid is not null)
        {
            KeyLoopServiceScheduler.Application.Observability.SchedulerTelemetry.Booking(BookingResult.Rejected(invalid.Value));
            return ProblemDetailsMapper.Result(HttpContext, new(invalid.Value));
        }
        HttpContext.Items["dealerId"] = request!.DealershipId;
        RequestKeyValidator.TryRead(Request.Headers, out var key);
        // Preserve only key presence for safe recovery guidance, never the raw key.
        HttpContext.Items["bookingHasRequestKey"] = key is not null;
        var result = await booking.ExecuteAsync(request.ToApplication(key), token);
        if (result.Failure is not null) return ProblemDetailsMapper.Result(HttpContext, result.Failure);
        var location = "/api/v1/appointments/" + result.Appointment!.Id;
        Response.Headers.Location = location;
        HttpContext.Items["reasonCode"] = result.IsReplay ? "REPLAY" : "CONFIRMED";
        return result.IsReplay ? Ok(result.Appointment) : StatusCode(201, result.Appointment);
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id, CancellationToken token)
    {
        if (!Guid.TryParseExact(id, "D", out var guid)) return ProblemDetailsMapper.Result(HttpContext, new(FailureCode.INVALID_REQUEST));
        var result = await retrieval.ExecuteAsync(guid, token);
        return result.Failure is not null ? ProblemDetailsMapper.Result(HttpContext, result.Failure) : Ok(result.Appointment);
    }
}
