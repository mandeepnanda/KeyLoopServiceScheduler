using System.Globalization;
using KeyLoopServiceScheduler.Application.Abstractions;
using KeyLoopServiceScheduler.Application.Availability;
using KeyLoopServiceScheduler.Application.Booking;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Infrastructure.Mock;

namespace KeyLoopServiceScheduler.Api.Mock;

/// <summary>Development-only demo contract. Production /api/v1 HTTP binding remains separate work.</summary>
public static class MockDemoEndpoints
{
    public static void MapMockDemo(this WebApplication app)
    {
        object Manifest(MockDatabase database) => new
        {
            mode = "Mock",
            notice = "Local demonstration: data resets on restart and is not shared between processes.",
            baseDate = database.BaseDate,
            exampleBooking = new BookingRequest(1, 1, 1, 1, database.ExampleStart, "demo-001"),
            availabilityUrl = "/demo/availability?dealershipId=1&serviceTypeId=1&startTime=" + database.ExampleStart.UtcDateTime.ToString("O", CultureInfo.InvariantCulture),
            dealers = new[] { new { id = 1, timeZone = "Asia/Kolkata" }, new { id = 2, timeZone = "America/New_York" } },
            services = new[] { new { id = 1, durationMinutes = 60 }, new { id = 2, durationMinutes = 30 } }
        };
        app.MapGet("/", (MockDatabase database) => Manifest(database));
        app.MapGet("/demo", (MockDatabase database) => Manifest(database));
        app.MapGet("/demo/availability", async (long dealershipId, long serviceTypeId, DateTimeOffset startTime, QueryAvailability service, CancellationToken token) =>
        {
            var result = await service.ExecuteAsync(new(dealershipId, serviceTypeId, startTime), token);
            return result.Failure is not null ? Error(result.Failure) : Results.Ok(result.Details);
        });
        app.MapPost("/demo/appointments", async (BookingRequest request, BookAppointment service, CancellationToken token) =>
        {
            var result = await service.ExecuteAsync(request, token);
            if (result.Failure is not null) return Error(result.Failure);
            var location = "/demo/appointments/" + result.Appointment!.Id;
            if (result.IsReplay) return Results.Json(result.Appointment, statusCode: 200,
                contentType: "application/json");
            return Results.Created(location, result.Appointment);
        });
        app.MapGet("/demo/appointments/{id:guid}", async (Guid id, IAppointmentReader reader, CancellationToken token) =>
        {
            var appointment = await reader.GetAsync(id, token);
            return appointment is null ? Results.NotFound(new { code = "APPOINTMENT_NOT_FOUND", mode = "Mock" }) : Results.Ok(appointment);
        });
        // Every demo response identifies its ephemeral storage, including validation/conflict responses.
        app.Use(async (context, next) => { context.Response.Headers["X-Scheduler-Storage"] = "Mock"; await next(context); });
    }
    private static IResult Error(Failure failure)
    {
        var status = failure.Code switch
        {
            FailureCode.NO_QUALIFIED_TECHNICIAN or FailureCode.DEALERSHIP_CLOSED or FailureCode.TECHNICIAN_UNAVAILABLE or
                FailureCode.BAY_UNAVAILABLE or FailureCode.KEY_PAYLOAD_MISMATCH => 409,
            FailureCode.BOOKING_BUSY or FailureCode.REQUEST_TIMEOUT or FailureCode.DATABASE_UNAVAILABLE or FailureCode.BOOKING_OUTCOME_UNKNOWN => 503,
            FailureCode.INVALID_REFERENCE_CONFIGURATION or FailureCode.INTERNAL_ERROR => 500,
            _ => 400
        };
        return Results.Json(new { code = failure.Code.ToString(), mode = "Mock", outcome = failure.Outcome?.ToString() }, statusCode: status);
    }
}
