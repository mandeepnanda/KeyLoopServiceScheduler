using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure;
using KeyLoopServiceScheduler.Api.Bootstrap;
using KeyLoopServiceScheduler.Api.Mock;
using KeyLoopServiceScheduler.Infrastructure.Mock;
using KeyLoopServiceScheduler.Application.Appointments;
using KeyLoopServiceScheduler.Api.Errors;
using KeyLoopServiceScheduler.Api.Middleware;
using KeyLoopServiceScheduler.Api.Validation;
using KeyLoopServiceScheduler.Api.Health;
using Microsoft.AspNetCore.Mvc;
using KeyLoopServiceScheduler.Api.OpenApi;
using Microsoft.OpenApi;
using KeyLoopServiceScheduler.Api.Observability;

var command = SeedCommand.Parse(args);
var builder = WebApplication.CreateBuilder(command.HostArguments);
builder.AddSchedulerLogging();
builder.Services.AddSchedulerOpenTelemetry(builder.Configuration);
builder.Services.AddSchedulerStorage(builder.Configuration, provider => provider.GetRequiredService<IHostEnvironment>().EnvironmentName);
builder.Services.AddControllers(options => options.Filters.Add<RequestMediaTypeFilter>()).AddJsonOptions(options => options.JsonSerializerOptions.Converters.Add(new OffsetTimestampJsonConverter()));
builder.Services.Configure<ApiBehaviorOptions>(options => options.InvalidModelStateResponseFactory = context =>
{
    if (context.HttpContext.Request.Method == "POST") KeyLoopServiceScheduler.Application.Observability.SchedulerTelemetry.Booking(
        KeyLoopServiceScheduler.Application.Booking.BookingResult.Rejected(KeyLoopServiceScheduler.Application.Contracts.FailureCode.INVALID_REQUEST));
    return ProblemDetailsMapper.Result(context.HttpContext, new(KeyLoopServiceScheduler.Application.Contracts.FailureCode.INVALID_REQUEST));
});
builder.Services.AddScoped<GetAppointment>();
builder.Services.AddOpenApi(options =>
{
    options.OpenApiVersion = OpenApiSpecVersion.OpenApi3_0;
    options.ShouldInclude = description => description.RelativePath is string path && (path.StartsWith("api/v1/", StringComparison.Ordinal) || path.StartsWith("health/", StringComparison.Ordinal));
    options.AddDocumentTransformer<SchedulerOpenApiTransformer>();
});
builder.Services.ConfigureHttpJsonOptions(options => options.SerializerOptions.Converters.Add(new OffsetTimestampJsonConverter()));
builder.Services.AddSingleton(TimeProvider.System);
var app = builder.Build();
// Validate external configuration at startup, after host/test configuration overrides have been applied.
var storage = app.Services.GetRequiredService<SchedulerStorageSettings>();
if (storage.Mode == SchedulerStorageMode.SqlServer) _ = app.Services.GetRequiredService<SchedulerDatabaseOptions>();
else
{
    if (command.SeedOnly) throw new InvalidOperationException("Mock mode seeds automatically; --seed-only is for SQL Server.");
    _ = app.Services.GetRequiredService<MockDatabase>();
    app.Logger.LogWarning("Scheduler {operation}: {reasonCode}", "startup", "MOCK_STORAGE_EPHEMERAL");
    app.MapMockDemo();
}
if (command.SeedOnly)
{
    await command.ExecuteAsync(app.Services);
    await app.DisposeAsync();
    return;
}
app.UseMiddleware<CorrelationMiddleware>();
app.UseMiddleware<RequestLoggingMiddleware>();
app.UseMiddleware<KeyLoopServiceScheduler.Api.Errors.ExceptionHandler>();
app.MapControllers();
app.MapSchedulerHealth();
if (app.Environment.IsDevelopment()) app.MapOpenApi();
await app.RunAsync();

public partial class Program;
