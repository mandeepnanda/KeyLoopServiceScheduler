using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace KeyLoopServiceScheduler.Api.Validation;

public sealed partial class OffsetTimestampJsonConverter : JsonConverter<DateTimeOffset>
{
    [GeneratedRegex(@"\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,7})?(?:Z|[+-][0-9]{2}:[0-9]{2})\z", RegexOptions.CultureInvariant)]
    private static partial Regex Syntax();
    public static bool TryParse(string? value, out DateTimeOffset timestamp)
    {
        timestamp = default;
        return value is not null && Syntax().IsMatch(value) && DateTimeOffset.TryParse(value,
            CultureInfo.InvariantCulture, DateTimeStyles.None, out timestamp);
    }
    public override DateTimeOffset Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options) =>
        reader.TokenType == JsonTokenType.String && TryParse(reader.GetString(), out var timestamp) ? timestamp : throw new JsonException("Invalid explicit-offset timestamp.");
    public override void Write(Utf8JsonWriter writer, DateTimeOffset value, JsonSerializerOptions options) =>
        writer.WriteStringValue(value.UtcDateTime.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'", CultureInfo.InvariantCulture));
}
