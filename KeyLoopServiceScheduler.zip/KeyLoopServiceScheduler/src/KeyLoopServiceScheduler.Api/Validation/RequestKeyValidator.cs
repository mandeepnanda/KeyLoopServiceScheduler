using Microsoft.Extensions.Primitives;

namespace KeyLoopServiceScheduler.Api.Validation;

public static class RequestKeyValidator
{
    public static bool Valid(string? key) => key is null || key.Length is >= 1 and <= 128 && key.All(c => c is >= '!' and <= '~');
    public static bool TryRead(IHeaderDictionary headers, out string? key)
    {
        key = null;
        if (!headers.TryGetValue("Idempotency-Key", out StringValues values)) return true;
        if (values.Count != 1) return false;
        key = values[0] ?? "";
        return Valid(key);
    }
}
