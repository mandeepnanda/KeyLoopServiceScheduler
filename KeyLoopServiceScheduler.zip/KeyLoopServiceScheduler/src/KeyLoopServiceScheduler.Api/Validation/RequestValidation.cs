using System.Globalization;
using System.Text.Json;
using KeyLoopServiceScheduler.Application.Contracts;
using KeyLoopServiceScheduler.Api.Contracts;

namespace KeyLoopServiceScheduler.Api.Validation;

public static class RequestValidation
{
    private static readonly string[] BookingFields = ["customerId", "vehicleId", "dealershipId", "serviceTypeId", "startTime"];
    private static readonly string[] QueryFields = ["dealershipId", "serviceTypeId", "startTime"];
    public static FailureCode? Booking(JsonElement body, IHeaderDictionary headers, out BookingRequest? request)
    {
        request = null;
        if (body.ValueKind != JsonValueKind.Object) return FailureCode.INVALID_REQUEST;
        var fields = body.EnumerateObject().Select(p => p.Name).ToArray();
        if (fields.Length != 5 || fields.Distinct(StringComparer.Ordinal).Count() != 5 || fields.Any(name => !BookingFields.Contains(name)))
            return FailureCode.INVALID_REQUEST;
        if (!Id(body, "customerId", out var customer) || !Id(body, "vehicleId", out var vehicle) ||
            !Id(body, "dealershipId", out var dealer) || !Id(body, "serviceTypeId", out var service)) return FailureCode.INVALID_REQUEST;
        var start = body.GetProperty("startTime");
        if (start.ValueKind != JsonValueKind.String || !OffsetTimestampJsonConverter.TryParse(start.GetString(), out var time)) return FailureCode.INVALID_START_TIME;
        if (!RequestKeyValidator.TryRead(headers, out var key)) return FailureCode.INVALID_KEY;
        request = new(customer, vehicle, dealer, service, time);
        return null;
    }
    private static bool Id(JsonElement body, string name, out long id)
    {
        id = 0;
        return body.GetProperty(name).ValueKind == JsonValueKind.Number && body.GetProperty(name).TryGetInt64(out id) && id > 0;
    }
    public static FailureCode? Availability(IQueryCollection query, out AvailabilityQuery? request)
    {
        request = null;
        if (query.Count != 3 || query.Keys.Any(name => !QueryFields.Contains(name)) || query.Any(pair => pair.Value.Count != 1)) return FailureCode.INVALID_REQUEST;
        if (!long.TryParse(query["dealershipId"], NumberStyles.None, CultureInfo.InvariantCulture, out var dealer) || dealer <= 0 ||
            !long.TryParse(query["serviceTypeId"], NumberStyles.None, CultureInfo.InvariantCulture, out var service) || service <= 0) return FailureCode.INVALID_REQUEST;
        if (!OffsetTimestampJsonConverter.TryParse(query["startTime"], out var time)) return FailureCode.INVALID_START_TIME;
        request = new(dealer, service, time);
        return null;
    }
}
