using KeyLoopServiceScheduler.Api.Errors;
using KeyLoopServiceScheduler.Application.Contracts;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace KeyLoopServiceScheduler.Api.Validation;

public sealed class RequestMediaTypeFilter : IAlwaysRunResultFilter
{
    public void OnResultExecuting(ResultExecutingContext context)
    {
        if (context.Result is IStatusCodeActionResult { StatusCode: 415 })
        {
            Application.Observability.SchedulerTelemetry.Booking(Application.Booking.BookingResult.Rejected(FailureCode.INVALID_REQUEST));
            context.Result = ProblemDetailsMapper.Result(context.HttpContext, new(FailureCode.INVALID_REQUEST));
        }
    }
    public void OnResultExecuted(ResultExecutedContext context) { }
}
