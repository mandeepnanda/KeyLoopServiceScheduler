using KeyLoopServiceScheduler.Application.Observability;
using OpenTelemetry;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace KeyLoopServiceScheduler.Api.Observability;

public static class OpenTelemetryConfiguration
{
    public static void AddSchedulerOpenTelemetry(this IServiceCollection services, IConfiguration configuration)
    {
        var endpoint = configuration["Telemetry:OtlpEndpoint"];
        var telemetry = services.AddOpenTelemetry().ConfigureResource(resource => resource.AddService(SchedulerTelemetry.Name));
        services.ConfigureOpenTelemetryTracerProvider((provider, configured) =>
        {
            var capture = configuration["Telemetry:LoadCaptureFile"];
            if (string.IsNullOrWhiteSpace(capture)) return;
            if (!provider.GetRequiredService<IHostEnvironment>().IsDevelopment())
                throw new InvalidOperationException("Local load timing capture is Development-only.");
            configured.AddProcessor(new BatchActivityExportProcessor(new LoadTimingExporter(Path.GetFullPath(capture)),
                maxQueueSize: 8192, scheduledDelayMilliseconds: 200, exporterTimeoutMilliseconds: 1000, maxExportBatchSize: 512));
        });
        telemetry.WithTracing(tracing =>
        {
            tracing.AddSource(SchedulerTelemetry.Name).AddAspNetCoreInstrumentation(options =>
            {
                // HTTP route/status instrumentation only; no query strings, header values, or bodies.
                options.Filter = context => context.Request.Path.StartsWithSegments("/api/v1") || context.Request.Path.StartsWithSegments("/health");
                options.EnrichWithHttpRequest = (activity, _) => { activity.SetTag("url.query", null); activity.SetTag("url.path", null); };
                options.EnrichWithHttpResponse = (activity, _) => { activity.SetTag("url.query", null); activity.SetTag("url.path", null); activity.SetTag("url.full", null); };
            });
            if (!string.IsNullOrWhiteSpace(endpoint)) tracing.AddOtlpExporter(options =>
            {
                options.Endpoint = new Uri(endpoint); options.TimeoutMilliseconds = 1000; options.ExportProcessorType = ExportProcessorType.Batch;
                options.BatchExportProcessorOptions.MaxQueueSize = 1024; options.BatchExportProcessorOptions.MaxExportBatchSize = 128;
                options.BatchExportProcessorOptions.ExporterTimeoutMilliseconds = 1000;
            });
        });
        telemetry.WithMetrics(metrics =>
        {
            metrics.AddMeter(SchedulerTelemetry.Name).AddAspNetCoreInstrumentation();
            if (!string.IsNullOrWhiteSpace(endpoint)) metrics.AddOtlpExporter(options => { options.Endpoint = new Uri(endpoint); options.TimeoutMilliseconds = 1000; });
        });
    }
}
