using System.Text.Json;
using System.Threading.Channels;
using KeyLoopServiceScheduler.Application.Observability;
using Serilog.Core;
using Serilog.Events;

namespace KeyLoopServiceScheduler.Api.Observability;

public sealed class BoundedLogSink : ILogEventSink, IDisposable
{
    private static readonly string[] Fields = ["operation", "outcome", "reasonCode", "traceId", "correlationId", "dealerId", "elapsedMs"];
    private readonly Channel<LogEvent> queue;
    private readonly Task worker;
    private long dropped;
    public long Dropped => Interlocked.Read(ref dropped);
    public BoundedLogSink(int capacity = 1024, Action<string>? write = null)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(capacity);
        queue = Channel.CreateBounded<LogEvent>(new BoundedChannelOptions(capacity) { SingleReader = true, FullMode = BoundedChannelFullMode.Wait });
        write ??= Console.WriteLine;
        worker = Task.Run(async () =>
        {
            await foreach (var item in queue.Reader.ReadAllAsync())
            {
                try
                {
                    var safe = new Dictionary<string, object?> { ["timestamp"] = item.Timestamp, ["level"] = item.Level.ToString() };
                    foreach (var field in Fields) if (item.Properties.TryGetValue(field, out var value) && value is ScalarValue scalar) safe[field] = scalar.Value;
                    write(JsonSerializer.Serialize(safe));
                }
                catch (Exception) { Drop(); }
            }
        });
    }
    public void Emit(LogEvent logEvent) { if (!queue.Writer.TryWrite(logEvent)) Drop(); }
    private void Drop() { Interlocked.Increment(ref dropped); SchedulerTelemetry.Dropped(); }
    public async Task DrainAsync(TimeSpan timeout)
    {
        queue.Writer.TryComplete();
        try { await worker.WaitAsync(timeout); } catch (TimeoutException) { }
    }
    public void Dispose() => DrainAsync(TimeSpan.FromMilliseconds(500)).GetAwaiter().GetResult();
}
