using System.Diagnostics;
using Serilog;

namespace KeyLoopServiceScheduler.Api.Observability;

public static class LoggingConfiguration
{
    public static void AddSchedulerLogging(this WebApplicationBuilder builder)
    {
        builder.Logging.ClearProviders();
        builder.Services.AddSingleton<BoundedLogSink>();
        builder.Services.AddSerilog((provider, logger) => logger.MinimumLevel.Information().Enrich.FromLogContext()
            .Filter.ByIncludingOnly(record => record.Properties.ContainsKey("operation"))
            .WriteTo.Sink(provider.GetRequiredService<BoundedLogSink>()));
    }
}

public sealed class RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var watch = Stopwatch.StartNew();
        try { await next(context); }
        finally
        {
            var path = context.Request.Path.Value ?? "";
            var operation = path.StartsWith("/api/v1/appointments", StringComparison.Ordinal) ? (context.Request.Method == "POST" ? "booking" : "retrieval")
                : path == "/api/v1/availability" ? "availability" : path.StartsWith("/health/", StringComparison.Ordinal) ? "health" : "other";
            context.Items.TryGetValue("reasonCode", out var reason);
            context.Items.TryGetValue("dealerId", out var dealer);
            using var scope = logger.BeginScope(new Dictionary<string, object?>
            {
                ["operation"] = operation,
                ["outcome"] = context.RequestAborted.IsCancellationRequested ? "disconnected" : context.Response.StatusCode < 400 ? "success" : "rejected",
                ["reasonCode"] = reason,
                ["dealerId"] = dealer,
                ["elapsedMs"] = watch.Elapsed.TotalMilliseconds
            });
            logger.LogInformation("Scheduler operation completed");
        }
    }
}
