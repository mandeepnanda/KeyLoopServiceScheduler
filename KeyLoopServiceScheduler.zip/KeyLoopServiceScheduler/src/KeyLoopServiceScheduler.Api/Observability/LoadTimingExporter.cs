using System.Diagnostics;
using System.Text.Json;
using KeyLoopServiceScheduler.Application.Observability;
using OpenTelemetry;

namespace KeyLoopServiceScheduler.Api.Observability;

/// <summary>Opt-in Development load evidence. Called only by the bounded SDK batch worker.</summary>
public sealed class LoadTimingExporter(string path) : BaseExporter<Activity>
{
    private static readonly HashSet<string> Operations = ["booking", "availability", "booking.transaction", "booking.lock.wait",
        "booking.db.replay", "booking.db.references", "booking.db.resources", "booking.db.insert"];

    public override ExportResult Export(in Batch<Activity> batch)
    {
        try
        {
            using var writer = new StreamWriter(path, append: true);
            foreach (var activity in batch)
            {
                if (activity.Source.Name != SchedulerTelemetry.Name || !Operations.Contains(activity.OperationName)) continue;
                // Do not serialize tags, events, baggage, URLs, keys, payloads or database statements.
                writer.WriteLine(JsonSerializer.Serialize(new
                {
                    operation = activity.OperationName,
                    startUtc = activity.StartTimeUtc,
                    endUtc = activity.StartTimeUtc + activity.Duration,
                    durationMs = activity.Duration.TotalMilliseconds,
                    traceId = activity.TraceId.ToString()
                }));
            }
            return ExportResult.Success;
        }
        catch (Exception)
        {
            SchedulerTelemetry.Dropped();
            return ExportResult.Failure;
        }
    }
}
