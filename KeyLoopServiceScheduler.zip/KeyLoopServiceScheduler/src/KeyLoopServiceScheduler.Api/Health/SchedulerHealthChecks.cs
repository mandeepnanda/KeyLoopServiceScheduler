using KeyLoopServiceScheduler.Infrastructure.Configuration;
using KeyLoopServiceScheduler.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace KeyLoopServiceScheduler.Api.Health;

public static class SchedulerHealthChecks
{
    public static void MapSchedulerHealth(this WebApplication app)
    {
        app.MapGet("/health/live", () => Results.Ok(new { status = "alive" }));
        app.MapGet("/health/ready", async (IServiceProvider services, CancellationToken token) =>
        {
            var mode = services.GetRequiredService<SchedulerStorageSettings>().Mode;
            if (mode == SchedulerStorageMode.Mock) return Results.Ok(new { status = "ready", storage = "Mock" });
            try
            {
                var ready = await services.GetRequiredService<SchedulerDbContext>().Database.CanConnectAsync(token);
                return Results.Json(new { status = ready ? "ready" : "unavailable", storage = "SqlServer" }, statusCode: ready ? 200 : 503);
            }
            catch (Exception exception) when (exception is System.Data.Common.DbException or OperationCanceledException)
            { return Results.Json(new { status = "unavailable", storage = "SqlServer" }, statusCode: 503); }
        });
    }
}
